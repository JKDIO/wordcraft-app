# 티어 10 — 교체해야 할 슬롯 102개

아래 단어들은 **더 낮은 티어에서 이미 쓰였다**(팩 저작을 티어별로 병렬 진행해 생긴 충돌).
각 슬롯을 그 팩의 주제와 티어 난이도에 맞는 **새 단어**로 교체하라.

| pack_id | 주제 | 교체할 단어 |
|---|---|---|
| V10-01 | 추상 명사 1(개념) | method, structure, function, process, element, factor, aspect, pattern |
| V10-02 | 추상 명사 2(가치) | justice, freedom, duty, ambition |
| V10-03 | 고급 동사 1(사고) | interpret, evaluate, suspect, determine, reflect, distinguish, estimate |
| V10-04 | 고급 동사 2(행동) | replace, transform, expand, arrange |
| V10-05 | 고급 형용사 1 | obvious, essential, previous, reliable |
| V10-06 | 고급 형용사 2 | stubborn, humble |
| V10-07 | 접두사로 뜻 뒤집기 | impossible, unfair, disagree |
| V10-08 | 접미사로 품사 바꾸기 | kindness, careful, dangerous, creative, scientist, friendship |
| V10-09 | 자주 틀리는 짝 1 | affect, effect, accept, except, advice, borrow, lend, quiet, desert, dessert |
| V10-10 | 자주 틀리는 짝 2 | weather, hard, rise, raise, lie, whether, hardly, most, receipt, recipe |
| V10-11 | 구동사 1(기본) | give up, put off, get along, take off |
| V10-12 | 구동사 2(확장) | come up with |
| V10-13 | 관용 표현 1 | by the way, on purpose |
| V10-15 | 불규칙 동사 총정리 1 | begin, break, choose, speak, steal, freeze, hide, ring, shake, tear |
| V10-16 | 불규칙 동사 총정리 2 | build, keep, pay, sell, spend, feed, hurt, quit |
| V10-18 | 비교급·최상급 불규칙 | many, little, well, more, less |
| V10-19 | 시험 지시문 어휘 | select, describe, correct, paragraph, according to, match |
| V10-20 | 중학 졸업 관문 | require, produce, available, familiar, eventually, individual, accomplish, appreciate |

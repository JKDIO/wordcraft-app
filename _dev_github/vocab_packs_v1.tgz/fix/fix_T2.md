# 티어 2 — 교체해야 할 슬롯 29개

아래 단어들은 **더 낮은 티어에서 이미 쓰였다**(팩 저작을 티어별로 병렬 진행해 생긴 충돌).
각 슬롯을 그 팩의 주제와 티어 난이도에 맞는 **새 단어**로 교체하라.

| pack_id | 주제 | 교체할 단어 |
|---|---|---|
| V2-01 | 숫자 20~100과 순서 | eleven |
| V2-03 | 달과 계절 | week, weekend |
| V2-04 | 과일 | fruit |
| V2-06 | 고기와 생선 | meat, chicken |
| V2-07 | 동물 2 (야생) | rabbit |
| V2-09 | 새와 나무 | duck |
| V2-10 | 집 안 가구 | wall |
| V2-11 | 부엌 물건 | bottle |
| V2-12 | 욕실·청소 | dirty |
| V2-13 | 학교 장소 | garden |
| V2-14 | 학용품 2 | pencil, notebook, eraser, ruler, scissors, glue |
| V2-18 | 마을의 장소 | farm |
| V2-19 | 길과 교통 2 | train, taxi, truck, subway |
| V2-20 | 가족 확장 (사촌·조카) | sister, grandmother, grandfather, aunt, cousin, daughter |

# 티어 3 — 교체해야 할 슬롯 26개

아래 단어들은 **더 낮은 티어에서 이미 쓰였다**(팩 저작을 티어별로 병렬 진행해 생긴 충돌).
각 슬롯을 그 팩의 주제와 티어 난이도에 맞는 **새 단어**로 교체하라.

| pack_id | 주제 | 교체할 단어 |
|---|---|---|
| V3-01 | 있다·없다·가지다 | empty |
| V3-04 | 말하기 대작전 | question |
| V3-06 | 만들고 고치기 | build |
| V3-07 | 머릿속 생각 창고 | guess |
| V3-08 | 시작과 끝 | over, first |
| V3-09 | 많다 적다(수량) | half |
| V3-12 | 시간을 알려 주는 부사 | early |
| V3-14 | 장소 전치사 심화 | under, behind, between, inside, outside |
| V3-15 | 시간을 가리키는 말 | week, weekend, hour, minute, month |
| V3-17 | 의문사 완전정복 | when, why, which, whose |
| V3-19 | 맞다·아니다 | wrong |
| V3-20 | 대답하는 말 | goodbye, welcome, see you |

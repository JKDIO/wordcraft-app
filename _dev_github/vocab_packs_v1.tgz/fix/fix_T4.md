# 티어 4 — 교체해야 할 슬롯 56개

아래 단어들은 **더 낮은 티어에서 이미 쓰였다**(팩 저작을 티어별로 병렬 진행해 생긴 충돌).
각 슬롯을 그 팩의 주제와 티어 난이도에 맞는 **새 단어**로 교체하라.

| pack_id | 주제 | 교체할 단어 |
|---|---|---|
| V4-01 | 움직임 정밀(run/jog/rush) | slide, follow, chase, escape |
| V4-03 | 얼굴 표정과 소리 | stare, whisper |
| V4-05 | 외모 형용사 | short, young |
| V4-06 | 맛과 냄새 | smell, taste |
| V4-07 | 소리와 빛 | quiet, noise, loud, bright |
| V4-09 | 깨끗함과 더러움 | dirty, trash |
| V4-11 | 쉽다 어렵다 | possible |
| V4-12 | 싸다 비싸다 | borrow, lend, pay, spend, rich, cost |
| V4-13 | 옳고 그름 | wrong, lie, correct, promise |
| V4-14 | 일상 루틴 동사 | shower, exercise |
| V4-15 | 요리 동사 | fry |
| V4-16 | 고치고 만들기 | glue, break, build, fix, paint, tool |
| V4-17 | 입고 벗기 | dress, jacket, scarf |
| V4-18 | 사고 팔기 | sell, market, return, deliver |
| V4-19 | 돕고 나누기 | welcome, offer, share, gift, care, join, kind |
| V4-20 | 지키고 잃기 | hide, keep, own, appear, collect, miss |

# 티어 5 — 교체해야 할 슬롯 94개

아래 단어들은 **더 낮은 티어에서 이미 쓰였다**(팩 저작을 티어별로 병렬 진행해 생긴 충돌).
각 슬롯을 그 팩의 주제와 티어 난이도에 맞는 **새 단어**로 교체하라.

| pack_id | 주제 | 교체할 단어 |
|---|---|---|
| V5-01 | 학교 과목 | notebook, gym, library |
| V5-02 | 시험과 성적 | wrong, correct, score, fail, mistake |
| V5-03 | 숙제와 발표 | explain, finally, for example, prepare |
| V5-04 | 친구 사귀기 | share, trust, join, shy, friendly, forgive, apologize |
| V5-05 | 규칙과 약속 | promise, agree, honest, strict, warn, fair, rule |
| V5-06 | 시간표와 계획 | weekend, early, calendar, decide, daily, weekly |
| V5-07 | 돈과 값 | borrow, lend, pay, spend, cost, expensive, save, waste |
| V5-08 | 가게에서 | receipt, choose, instead, size, discount, customer, exchange, cash |
| V5-09 | 식당에서 | plate, napkin, taste, salty, spicy, fresh, order |
| V5-10 | 병원에서 | hurt, nurse, rest |
| V5-11 | 여행 준비 | towel, although |
| V5-12 | 공항과 역 | board, subway, gate, station, ticket |
| V5-13 | 전화와 문자 | ring, reply, silent |
| V5-14 | 인터넷과 앱 | search |
| V5-15 | 편지와 이메일 | receive |
| V5-16 | 방향 안내 | bridge, corner, sidewalk, exit, along, across, straight |
| V5-17 | 날짜와 기념일 | noon, midnight, season, month, holiday, birthday, until, since, ago |
| V5-18 | 축하와 파티 | balloon, invite, cheer |
| V5-19 | 취미 활동 | collect, draw, paint, enjoy |
| V5-20 | 음악과 악기 | stage |

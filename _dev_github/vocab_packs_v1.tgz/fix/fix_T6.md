# 티어 6 — 교체해야 할 슬롯 119개

아래 단어들은 **더 낮은 티어에서 이미 쓰였다**(팩 저작을 티어별로 병렬 진행해 생긴 충돌).
각 슬롯을 그 팩의 주제와 티어 난이도에 맞는 **새 단어**로 교체하라.

| pack_id | 주제 | 교체할 단어 |
|---|---|---|
| V6-01 | 감정 심화 1 | excited, bored, calm, curious, lonely |
| V6-02 | 성격 형용사 2 | honest, shy, gentle, selfish, strict, clever, patient |
| V6-03 | 가족 관계와 역할 | aunt, cousin, daughter, parent, twin, wife, husband, chore |
| V6-04 | 우정과 갈등 | hurt, joke, trust, blame, support, argue |
| V6-05 | 예의와 태도 | whisper, rude, rule, behave, guest |
| V6-06 | 도움과 배려 | borrow, lend, offer, share, care, rescue, protect, favor |
| V6-07 | 몸과 건강 | exercise, hospital, rest, habit, fever, headache, medicine |
| V6-08 | 운동 2와 경기 | team, coach, race, score, cheer, goal |
| V6-09 | 음식 문화 | dessert, dish, taste, salty, spicy, fresh, boil, bake, serve |
| V6-10 | 한국 소개하기 | history, introduce |
| V6-11 | 세계의 나라 | travel, abroad |
| V6-12 | 문화 차이 | exchange |
| V6-13 | 학교 행사 | stage, prepare, invite, announce, decorate, perform |
| V6-14 | 동아리와 봉사 | collect, join, effort, volunteer, club, member |
| V6-15 | 꿈과 장래희망 | become, plan, wish, dream, someday, succeed, challenge |
| V6-16 | 직업 2 | nurse, vet, firefighter, pilot, farmer, chef |
| V6-17 | 돈 관리 | receipt, pay, spend, cost, expensive, save, waste, discount, cash, wallet |
| V6-18 | 약속과 시간 지키기 | early, hurry, promise, miss, alarm, busy, cancel, appointment, delay |
| V6-19 | 감사와 사과 심화 | gift, mistake, forgive, apologize |
| V6-20 | 의견 말하기 1 | choose, explain, decide, actually, agree |

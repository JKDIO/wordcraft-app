# 티어 7 — 교체해야 할 슬롯 68개

아래 단어들은 **더 낮은 티어에서 이미 쓰였다**(팩 저작을 티어별로 병렬 진행해 생긴 충돌).
각 슬롯을 그 팩의 주제와 티어 난이도에 맞는 **새 단어**로 교체하라.

| pack_id | 주제 | 교체할 단어 |
|---|---|---|
| V7-01 | 자연과 환경 | desert, forest |
| V7-02 | 날씨와 기후 | freeze, melt |
| V7-03 | 재활용과 쓰레기 | trash, waste, package |
| V7-04 | 에너지와 자원 | battery, energy |
| V7-05 | 동식물 보호 | feed, nest, protect |
| V7-07 | 과학 실험 | scientist, result |
| V7-08 | 기계와 도구 | tool, hammer, nail, metal, button |
| V7-09 | 컴퓨터와 코딩 | folder, download, upload, password, click, screen |
| V7-11 | 교통과 안전 | sidewalk, crosswalk, speed, accident, passenger |
| V7-12 | 도시와 시골 | factory, population |
| V7-13 | 역사 속 인물 | century, palace, leader |
| V7-14 | 발명과 발견 | curious, mistake, discover |
| V7-15 | 미디어와 뉴스 | comment, audience, reporter |
| V7-16 | 광고와 소비 | discount, customer, popular |
| V7-17 | 봉사와 기부 | raise, collect, deliver, serve, volunteer, support, donate, community |
| V7-18 | 재난과 대비 | shake, escape, rescue, alarm, prepare |
| V7-19 | 직업 세계 3 | nurse, firefighter, pilot, dentist, engineer, lawyer |
| V7-20 | 진로 탐색 | skill, future, talent, ability, career |

# 티어 8 — 교체해야 할 슬롯 106개

아래 단어들은 **더 낮은 티어에서 이미 쓰였다**(팩 저작을 티어별로 병렬 진행해 생긴 충돌).
각 슬롯을 그 팩의 주제와 티어 난이도에 맞는 **새 단어**로 교체하라.

| pack_id | 주제 | 교체할 단어 |
|---|---|---|
| V8-01 | 원인과 결과 | result, reason |
| V8-02 | 비교와 대조 | match, instead, opposite, however, difference, similar, common, compare |
| V8-03 | 문제와 해결 | method, solve, handle |
| V8-04 | 변화와 성장 | replace, stage, recently, reduce, improve, develop |
| V8-05 | 선택과 결정 | accept, decide, regret, prefer |
| V8-06 | 계획과 목표 | expect, prepare, goal, task, organize |
| V8-07 | 성공과 실패 | give up, fail, mistake, effort |
| V8-08 | 도전과 용기 | escape, risk, challenge, survive |
| V8-09 | 습관과 태도 | stubborn, used to, rude, honest, lazy, careless, habit, routine, patient |
| V8-10 | 시간 관리 | spend, rush, waste, deadline, meanwhile, on time |
| V8-11 | 기억과 학습 | repeat, confuse, review, skill, remind |
| V8-12 | 상상과 창의 | wonder, curious, clever, design |
| V8-13 | 감정 심화 2(복합) | calm, lonely, nervous, proud, jealous, upset, relieved, embarrassed, disappointed, grateful |
| V8-14 | 관계의 거리 | get along, promise, trust, forgive, apologize, support, argue, ignore |
| V8-15 | 사회와 규칙 | rule, allow, obey, member, community |
| V8-16 | 권리와 책임 | duty, protect, blame, fault, admit |
| V8-17 | 공정과 평등 | unfair, fair, cheat |
| V8-18 | 협력과 경쟁 | disagree, join, agree, encourage, leader |
| V8-19 | 전통과 현대 | century, culture, festival, custom, ancient, modern |
| V8-20 | 예술과 표현 | appreciate, perform, audience, talent |

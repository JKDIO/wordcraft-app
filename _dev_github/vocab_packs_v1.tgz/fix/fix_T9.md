# 티어 9 — 교체해야 할 슬롯 76개

아래 단어들은 **더 낮은 티어에서 이미 쓰였다**(팩 저작을 티어별로 병렬 진행해 생긴 충돌).
각 슬롯을 그 팩의 주제와 티어 난이도에 맞는 **새 단어**로 교체하라.

| pack_id | 주제 | 교체할 단어 |
|---|---|---|
| V9-01 | 주장과 근거 | support, argue, reasonable |
| V9-02 | 동의와 반대 | admit, opponent |
| V9-03 | 가정과 조건 | whether, otherwise, depend on, pretend |
| V9-04 | 가능성과 확신 | definitely, risk, certain |
| V9-05 | 추측과 판단 | seem, expect, figure out, consider, predict, judge |
| V9-06 | 분석과 분류 | compare, separate |
| V9-07 | 증가와 감소 | reduce, increase |
| V9-08 | 전체와 부분 | total |
| V9-09 | 일반과 예외 | standard, regular, unique |
| V9-10 | 목적과 수단 | method, function, effort, purpose, strategy, in order to, attempt |
| V9-11 | 조건과 제한 | strict, deadline, allow, control, permission |
| V9-12 | 영향과 효과 | effect, result, improve, cause, lead to, due to, prevent |
| V9-13 | 증명과 사실 | false, truth |
| V9-14 | 의견과 사실 구분 | opinion, express |
| V9-15 | 요약과 정리 | arrange, review, topic, organize, detail |
| V9-16 | 연구와 조사 | collect, discover, explore, expert, source |
| V9-17 | 통계와 자료 | measure, data, average |
| V9-18 | 실험과 관찰 | notice, temperature, experiment, observe, mixture |
| V9-19 | 논리 연결어 | finally, while, although, instead, for example, however, unlike |
| V9-20 | 글쓰기 표현 | describe, audience |

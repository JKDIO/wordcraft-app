# 남은 중복 교체 목록 (2차) — 총 87슬롯

각 슬롯의 단어는 **더 낮은 티어(또는 앞선 팩)가 이미 가져갔다.** 해당 팩 파일에서 그 단어만 새 단어로 교체하라.
팩당 12단어는 유지하고, 새 단어는 그 팩의 티어·주제에 맞아야 한다.

| 티어 | pack_id | 주제 | 교체할 단어 |
|---|---|---|---|
| 5 | V5-01 | 학교 과목 | workbook |
| 5 | V5-04 | 친구 사귀기 | chat, partner, make friends |
| 5 | V5-05 | 규칙과 약속 | nod |
| 5 | V5-07 | 돈과 값 | afford, owe |
| 5 | V5-10 | 병원에서 | recover |
| 5 | V5-16 | 방향 안내 | next to |
| 5 | V5-17 | 날짜와 기념일 | sunset |
| 6 | V6-02 | 성격 형용사 2 | talkative |
| 6 | V6-05 | 예의와 태도 | nod, line up |
| 6 | V6-06 | 도움과 배려 | thoughtful, assist, cheer up |
| 6 | V6-07 | 몸과 건강 | recover |
| 6 | V6-09 | 음식 문화 | leftovers |
| 6 | V6-10 | 한국 소개하기 | souvenir |
| 6 | V6-13 | 학교 행사 | banner |
| 6 | V6-17 | 돈 관리 | sale, purchase, afford, owe, cashier, savings |
| 6 | V6-18 | 약속과 시간 지키기 | free time, postpone, weekday |
| 7 | V7-03 | 재활용과 쓰레기 | garbage |
| 7 | V7-14 | 발명과 발견 | sketch |
| 7 | V7-16 | 광고와 소비 | purchase |
| 7 | V7-17 | 봉사와 기부 | assist, participate, campaign |
| 7 | V7-19 | 직업 세계 3 | librarian |
| 7 | V7-20 | 진로 탐색 | mentor |
| 8 | V8-02 | 비교와 대조 | variety |
| 8 | V8-04 | 변화와 성장 | remain |
| 8 | V8-05 | 선택과 결정 | willing |
| 8 | V8-09 | 습관과 태도 | hardworking, energetic, loyal, eager, punctual |
| 8 | V8-12 | 상상과 창의 | sketch |
| 8 | V8-13 | 감정 심화 2(복합) | thrilled, amazed |
| 8 | V8-16 | 권리와 책임 | owe, confess |
| 8 | V8-18 | 협력과 경쟁 | partner, participate, contribute |
| 8 | V8-19 | 전통과 현대 | decade, ceremony |
| 9 | V9-01 | 주장과 근거 | argument |
| 9 | V9-02 | 동의와 반대 | confess |
| 9 | V9-03 | 가정과 조건 | rely on |
| 9 | V9-05 | 추측과 판단 | prediction |
| 9 | V9-06 | 분석과 분류 | similarity |
| 9 | V9-10 | 목적과 수단 | motive |
| 9 | V9-12 | 영향과 효과 | outcome |
| 9 | V9-13 | 증명과 사실 | myth |
| 9 | V9-15 | 요약과 정리 | sort out, leave out |
| 9 | V9-18 | 실험과 관찰 | lab |
| 9 | V9-19 | 논리 연결어 | lastly, whereas |
| 10 | V10-03 | 고급 동사 1(사고) | infer, regard, conclude |
| 10 | V10-04 | 고급 동사 2(행동) | transfer |
| 10 | V10-05 | 고급 형용사 1 | steady |
| 10 | V10-06 | 고급 형용사 2 | modest |
| 10 | V10-07 | 접두사로 뜻 뒤집기 | impatient |
| 10 | V10-09 | 자주 틀리는 짝 1 | peace, sale |
| 10 | V10-10 | 자주 틀리는 짝 2 | principal, steel |
| 10 | V10-15 | 불규칙 동사 총정리 1 | bite, bend |
| 10 | V10-19 | 시험 지시문 어휘 | summarize |
| 10 | V10-20 | 중학 졸업 관문 | reveal, recover, admire, specific, current |

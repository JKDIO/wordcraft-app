import json, sys, io

def load(pid):
    p = f"/home/claude/vocab/packs/{pid}.json"
    return p, json.load(open(p, encoding='utf-8'))

def patch(pid, changes):
    """changes: list of (word, field, newvalue)"""
    p, d = load(pid)
    for w, f, v in changes:
        hit = [x for x in d['words'] if x['w'] == w]
        if not hit:
            raise SystemExit(f"NOT FOUND {pid} {w}")
        assert f in hit[0], f"no field {f}"
        hit[0][f] = v
    with open(p, 'w', encoding='utf-8') as fh:
        json.dump(d, fh, ensure_ascii=False, indent=2)
    print("patched", pid, len(changes))

# 티어10 교차검수 상세 (V10-01 ~ V10-20, 20팩 240단어)

검수관: 독립 교차 검수 에이전트 / 일자: 2026-08-12
검수 항목: ko 뜻·pos 일치 / ipa(GA) / ex 문법·자연스러움 / ex_ko 자연스러움 / hint_ko 정답 누설 / distractors 3개 동일 품사·의미장 + "오답이 정답도 되는" 경우 / 부적절 내용

## 0. 구조 검증 (스크립트)
- 240단어 전수: 필드 누락 0, pos 값 이탈 0, distractors 3개 아님 0, 자기 자신이 오답 0, 대문자 표제어 0, 문장부호 누락 0, IPA 슬래시 0.
- V10 내부 중복 0 · V1~V9 표제어와 중복 0 · known_words.txt(623개) 중복 0.
- 예문 길이 티어10 상한(12단어) 초과 0.
- 예문에 굴절형만 든 항목 8건(deduced/contemplated/speculated/distributed/pulling/involves/managed/responded) → V1~V9에서도 123/2160(5.7%)로 이미 통용되는 패턴이라 결함으로 보지 않고 유지.
- `w`(표제어)는 지시대로 한 건도 변경하지 않음.

## 1. 심각(P0)으로 판단해 고친 것

### V10-15 sting ↔ shoot 뜻 충돌 (혼동쌍 성격의 치명적 결함)
- sting의 `ko`가 "쏘다, 찌르다"인데 **distractors에 `shoot`(쏘다)이 들어 있었다.** 한국어 뜻을 보고 고르는 문항에서 오답이 정답이 되는 구조.
- 조치: sting `ko` → "침으로 쏘다 (stung-stung)", distractors → ["bite","strike","kick"], hint 보강.
  shoot `ko` → "(총·활을) 쏘다 (shot-shot)". 두 단어의 한국어 뜻이 더는 겹치지 않는다.

### V10-16 spread hint_ko 발음 규칙 오설명
- 기존: "모양은 그대로인데 과거에서는 소리가 짧아지는 형" → **사실이 아니다.** spread는 세 형태 모두 /sprɛd/로 소리가 변하지 않는다(소리가 짧아지는 건 read/red 쪽).
- 조치: "세 형태가 모두 spread 로 똑같은 무리. read 와 달리 소리까지 그대로야."로 정정.

### V10-15 불규칙 변화형 누락 2건
- 팩의 나머지 10개는 `ko`에 (과거-과거분사)를 달고 있는데 **sting, spin만 누락**되어 있었다. 아이가 이 둘만 변화형 없이 외우게 된다.
- 조치: sting "(stung-stung)", spin "(spun-spun)" 추가. (hint에 적힌 i→u 규칙과 일치 확인)

### V10-17 terribly 뜻-예문 불일치
- `ko`는 "몹시"인데 예문은 "I did terribly on that quiz."(형편없이) — 뜻과 예문이 다른 의미였다.
- 조치: 예문 → "It was terribly hot inside the tent." / "텐트 안이 몹시 더웠어."

### V10-18 least 오답 모호성
- `ko`가 "가장 적은"이라 **distractor `fewest`도 정답이 될 수 있었다**(수 vs 양 구분 불가).
- 조치: `ko` → "(양이) 가장 적은". 같은 팩 fewer의 "(수가) 더 적은"과 짝을 이뤄 few/little 구분이 살아난다.

### V10-10 hole 오답 모호성
- distractor `pit`(구덩이)은 "구멍" 프롬프트에서 정답 취급될 여지가 있었다.
- 조치: ["hall","hill","heel"]로 교체(철자 유사·의미 명확히 상이).

## 2. 불규칙 동사 전수 대조 결과 (V10-15 / V10-16)
grow-grew-grown ✓ / blow-blew-blown ✓ / sting-stung-stung ✓(추가) / arise-arose-arisen ✓ / awake-awoke-awoken ✓ / sew-sewed-sewn ✓ / spin-spun-spun ✓(추가) / fight-fought-fought ✓ / flee-fled-fled ✓ / shoot-shot-shot ✓ / strike-struck-struck ✓ / kneel-knelt-knelt ✓
stick-stuck ✓ / seek-sought ✓ / creep-crept ✓ / burst-burst ✓ / bet-bet ✓ / fit-fit(미국식) ✓ / hit-hit ✓ / let-let ✓ / split-split ✓ / cast-cast ✓ / spread-spread ✓ / shut-shut ✓
→ **표기된 변화형 자체의 오류는 0건.** 결함은 누락 2건과 hint 오설명 1건이었다.

## 3. 혼동쌍 팩 전수 확인 (V10-09 / V10-10)
- sight/site, piece(peace), cloth/clothes, dairy/diary, angle/angel, sail(sale), advise(advice), quite(quiet) — 뜻·철자 구분 설명 모두 정확. 오답 선택지가 혼동을 굳히는 배치는 hole 1건 외 없음.
- allowed/aloud, thorough(through), weak(week), sweat(sweet), flour(flower), breath(breathe), beside/besides, waist(waste), lay, almost(most) — 설명 정확. lay는 "뒤에 목적어가 온다"까지 명시되어 lie와의 함정을 피함(변화형은 이 팩의 범위가 아님).
- dairy ex_ko가 "젖소에서 나온 먹거리"로 뜻을 흐려 "우유랑 치즈는 유제품이야."로 교정. sweat ex_ko에 '땀'이 빠져 보충.

## 4. 구동사·관용구 (V10-11 ~ V10-14)
- 24개 구동사 모두 관용적 의미가 예문에서 드러남(turn down=거절, give in=굴복, turn out=밝혀지다, put up with=참다 등). 문자 그대로 읽히는 예문 없음.
- 관용구 24개 모두 실제 쓰임과 일치. break the ice / a piece of cake / get cold feet / pull someone's leg 등 예문 자연스러움 확인.
- make up ex_ko만 어색해 다듬음("숙제 가지고 이야기 지어내지 마.").

## 5. 접두사·접미사 팩 (V10-07 / V10-08)
- 규칙 서술 정확: un-/in-/im-/il-/ir-/dis-/non-/mis-/re-/pre-/over-/under-, -ness/-ful/-less/-ous/-ish/-ment/-or/-ian/-ive/-en/-ist/-ship 전부 옳게 설명됨.
- immature만 규칙이 빠져 있어 "m 으로 시작하는 말 앞에서는 in- 이 im- 으로 변신해."를 보강(illegal·irregular의 서술과 형태 통일).
- 이 팩들은 hint에 규칙(어근+접사)을 밝히는 것이 과제 지시사항이므로 '정답 누설'로 보지 않음.

## 6. 시험 지시문 팩 (V10-19)
- 12개 모두 실제 수행평가·시험지 지시문 맥락(Read the passage…, Fill in each blank…, State your opinion…)으로 확인.
- blank 예문이 fill in 예문과 거의 같아 "Write one word in each blank."로 분리.
- refer to의 오답이 instead of/because of/in spite of(접속 어구)라 품사·기능이 달라 즉시 소거 가능 → ["point out","hand in","cross out"](동사구)로 교체.

## 7. 기타 품질 교정
- **V10-04 오답 쏠림**: 12개 중 7개의 오답에 `destroy`가 들어 있어 "destroy는 늘 오답"이라는 패턴이 학습될 수 있었다. construct(정반대 짝)만 남기고 6개 팩 항목의 오답을 분산.
- **IPA 표기 통일/정정**: deduce dɪˈduːs→dɪˈdus, contemplate ˈkɑːntəmpleɪt→ˈkɑntəmpleɪt, speculate ˈspekjuleɪt→ˈspɛkjəleɪt, distribute dɪˈstrɪbjuːt→dɪˈstrɪbjut, relevant ˈreləvənt→ˈrɛləvənt, acquire əˈkwaɪər→əˈkwaɪɚ, respond rɪˈspɑːnd→rɪˈspɑnd, stable ˈsteɪbl→ˈsteɪbəl. (팩 전체가 쓰는 GA 표기 체계에 맞춤)
- ex_ko 정확도: basis "근거가 하나도 없어", gratitude "진심 어린 감사", angrily "화를 내며"(ko도 '화가 나서'→'화를 내며'로 부사답게).
- V10-15 sew 예문 "sew a hole"은 영어로 어색(구멍은 sew up/mend) → "sew a button back on"으로 교체.
- V10-15 awake 예문 "I awake early on game days."는 현대 구어에서 부자연(=wake up) → 판타지 맥락 "The dragon will awake when you touch the egg."로 교체.

## 8. 부적절 내용 점검
- 폭력·혐오·PII·상표 노출·유행 지난 밈 없음. 이름은 Mia/Leo/Sam 등 중립.
- 처벌형·비교형 문구 없음. arrogant/get cold feet 등 부정적 형용사도 인물 비난이 아닌 상황 서술로 처리됨.

## 9. 검증하지 못한 것 (정직 보고)
- 실제 앱 화면에서의 렌더링·TTS 발음, 문항 생성 로직(프롬프트가 ko인지 ex 빈칸인지)은 확인하지 못했다. distractor 판정은 "ko를 보고 단어를 고른다"는 가정 아래 내렸다.
- 예문의 원어민 감수는 받지 못했다(검수관 판단).
- 최종 판정은 Dio님 몫이다.

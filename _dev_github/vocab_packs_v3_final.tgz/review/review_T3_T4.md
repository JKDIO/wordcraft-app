# 티어3·4 교차검수 상세

## V3-01 (있다·없다·가지다) — 수정 0
- 12항목 ko/pos/ipa/예문 모두 이상 없음. `have got`은 GIU Basic 표기 방식으로 유지.

## V3-02 (가다·오다) — 수정 0
- 이상 없음. 예문 전부 6단어 이내(T3 규격) 준수.

## V3-03 (보고 듣고 느끼기) — 수정 4
- peek: "I peek through the small hole."(일회성 동작에 현재시제 부자연) → "Don't peek at my cards!"
- appear: 예문이 굴절형 appears만 포함 → "Ghosts appear at midnight."(표제어 원형 포함)
- taste: 굴절형 tastes만 포함 → "Does this taste weird?"
- clear: ko "잘 보이는, 뚜렷한"이 예문(물이 맑다)과 어긋남 → "맑은, 뚜렷한"

## V3-04 (말하기 대작전) — 수정 1
- whisper: 굴절형 whispers + 습관 현재시제 부자연 → "You can whisper the answer."

## V3-05 (주고받기) — 수정 1
- offer: ko "제안하다, 권하다"가 예문(무료 제공) 의미와 어긋남 → "제공하다, 권하다"

## V3-06 (만들고 고치기) — 수정 2
- work: 굴절형 works만 포함 → "Does your mom work at home?"
- plan: "We plan a big party."(단순현재 부자연) → "Let's plan a big party."

## V3-07 (머릿속 생각 창고) — 수정 1
- care: hint가 matter의 hint("'상관없어'라고 할 때 ... 뒤에 오는 말")와 사실상 동일 → 혼동 유발. care hint 재작성

## V3-08 (시작과 끝) — 수정 3
- begin/end: 굴절형(begins/ends)만 포함 → 원형 포함 예문으로 교체
- at first: distractors가 phr이 아닌 단어(final/next/later) → ["at last","in the end","after that"]로 품사 일치

## V3-09 (많다 적다) — 수정 0
- 수량 한정사 12개 ko/pos/ipa 정확. many↔much, few↔little 대조가 ko에 명시되어 있어 기능어 요건 충족.

## V3-10 (이것저것 가리키기) — 수정 1
- somewhere: "My key is somewhere here."(비문 수준의 어색함) → "My key is somewhere in here."

## V3-11 (사람 대명사) — 수정 1
- anyone: ko "누구든지, 아무도"의 "아무도"가 같은 팩 nobody("아무도 ~않다")와 충돌 → "누구든지, 누구라도"

## V3-12 (시간 부사) — 수정 0
- already/still/yet/anymore 모두 문장 내 위치가 예문에 드러남(기능어 요건 충족).

## V3-13 (빈도 부사) — 수정 0
- always~twice 빈도 스펙트럼 일관. hardly는 rarely와 ko가 구별됨.

## V3-14 (장소 전치사 심화) — 수정 0
- T3 기능어 특별점검 통과: 12개 전부 예문에서 "전치사 + 명사" 자리가 드러남(above the door / among the trees / onto my bed 등).

## V3-15 (시간 전치사) — 수정 0
- until vs by 대조가 hint에 명시("그 시간을 넘기면 안 되는 마감! until과 헷갈리지 마") — 한국어 화자 최다 오류 지점 정확히 처리됨.

## V3-16 (접속사 기초) — 수정 0
- 접속사·연결부사·연결구 모두 문두/문중 위치가 예문에 드러남.

## V3-17 (의문사 완전정복) — 수정 1
- why not: ko "~하는 게 어때?"가 같은 팩 how about("~는 어때?")과 사실상 동일 → "~하지 그래?"

## V3-18 (조동사 기초) — 수정 1
- would like: ex_ko "물 좀 주시겠어요?"(상대에게 요청하는 뜻)가 영어 원문(I would like)과 주어가 어긋남 → "저 물 좀 마시고 싶어요."
- 참고: have to의 ipa를 "ˈhæf tə"로 둔 것은 실제 발음 반영으로 올바름(유지).

## V3-19 (맞다·아니다) — 수정 1
- not at all: 예문 "I'm not sleepy at all."에서 표제어가 분리되어 나타남(not ... at all) → 앱의 빈칸/하이라이트에서 표제어를 못 찾음. "Not at all, I'm fine."으로 교체하고 hint 동기화

## V3-20 (대답하는 말) — 수정 1
- me too: ex_ko "나도 좀 줘"가 영어 "I want some"과 어긋남 → "Me too, I love pizza."로 교체
- 미수정 보고: congratulations는 한 단어인데 pos가 "phr". SPEC의 pos 목록에 감탄사가 없어 phr 유지가 최선으로 판단(변경 시 n이 되어 오히려 오해 소지). 규격 개정 시 재검토 권고.

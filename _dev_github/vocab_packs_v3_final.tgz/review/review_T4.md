# 티어4 (V4-01 ~ V4-20) 교차검수 상세

검수 범위: 20팩 240단어. 확인 항목 = ko/pos 일치 · IPA(GA) · 예문 문법·자연스러움 · ex_ko 한국어 자연스러움 · hint 정답 노출 여부 · distractors 3개의 품사/의미장/오답 안전성 · 부적절 내용 · **티어4 특별점검(같은 팩 안 유의어의 의미 차이가 예문·힌트에서 실제로 드러나는가)**.
`w`(표제어)는 전 팩 무변경. 총 수정 16건.

## V4-01 움직임 정밀 — 수정 1
- jog: hint "공원에서 아침마다 어른들이 하는 그 운동"이 오답 `walk`에도 그대로 들어맞음(오답이 정답이 되는 케이스) → "마라톤 선수가 준비운동으로 공원을 천천히 한 바퀴 도는 그것!"으로 교체.
- 티어4 점검 통과: jog/dash/rush/march/sneak/wander/crawl/limp가 예문에서 서로 대체 불가(일요일 조깅 / 결승선 / 지각 / 입장 행진 / 좀비 옆 / 골목 산책 / 아기 / 무릎 부상).

## V4-02 손으로 하는 동작 — 수정 0
- 12개 전부 목적어가 달라(버튼·레몬·손·문·페이지·옷·신발끈·식탁·소파·상자·병) 동작 구별이 예문만으로 성립. IPA·distractors 이상 없음.

## V4-03 얼굴 표정과 소리 — 수정 2
- yell: ko "고함치다"가 같은 팩 shout "소리치다"와 한국어로 사실상 구별 불가 → ko "버럭 고함치다", hint에 "shout보다 더 화난 상태!" 명시(shout=멀리 부르기, scream=공포, yell=분노로 3분할 완성).
- sigh: "I sigh when homework never ends."가 원어민 어법상 어색 → "I sigh every time I see more homework." / ex_ko 동기화.

## V4-04 성격 형용사 1 — 수정 0
- polite(예의)와 gentle(다루는 태도)이 예문에서 명확히 분리됨("polite to every teacher" vs "Be gentle with the baby rabbit"). 12개 IPA 정확.

## V4-05 외모 형용사 — 수정 1
- curly: ex_ko "긴 곱슬머리를 가졌어"가 have 직역투 → "미아는 머리가 길고 곱슬곱슬해."
- 보고(미수정): ugly/skinny/chubby/bald는 외모 평가어라 민감하나, 예문이 각각 게임 몬스터·"말랐지만 힘은 세"·아기 볼·"벗겨졌지만 멋져"로 완충되어 있어 그대로 둠. 실사용 중 예한이 반응 관찰 권고.

## V4-06 맛과 냄새 — 수정 1
- sniff: "before you drink."에 목적어 누락 → "Sniff this milk before you drink it."
- sweet/sour/bitter/salty/spicy 5미 + fresh/rotten + crispy/juicy/chewy 식감 3종이 서로 다른 음식에 붙어 있어 교차 대체 불가.

## V4-07 소리와 빛 — 수정 2
- dim: **"Turn the lights dim for the movie."는 비문 수준의 어색함**(native는 turn the lights down / dim the lights) → "The room is too dim to read." / ex_ko "방이 너무 어두워서 책을 못 읽겠어."
- squeak: hint의 "안 닦은 문경첩"이 한국어 연어 오류 → "쥐나 기름칠 안 한 문이 내는 가느다란 소리."

## V4-08 빠르기·무게·길이 — 수정 1
- shallow: ex는 swim인데 ex_ko가 "놀아"로 의미 이탈 → "어린아이들은 얕은 물에서 헤엄쳐."
- speed/weight/length/size 4개 측정 명사의 hint가 각각 다른 도구(속도계·저울·줄자·사이즈표)를 가리켜 구별됨.

## V4-09 깨끗함과 더러움 — 수정 1
- tidy(v): "Tidy your desk"는 영국식 색채가 강함 → GA 자연어인 "Tidy up your desk before dinner."
- sweep(빗자루)/scrub(수세미)/wipe·spill이 도구·상황으로 갈려 있어 대체 불가. dust/mud/stain/garbage도 발생 장소가 전부 다름.

## V4-10 위험과 안전 — 수정 2
- warn: "Please warn me before the test."가 warn의 '위험 예고' 뜻과 겉돎 → "Warn me if the boss is coming!" / ex_ko "보스 오면 나한테 미리 알려 줘!"(위험 테마와도 일치).
- risk: hint "잘못될 수도 있는 가능성"이 오답 `chance`(가능성)에도 완전히 들어맞음 → distractor를 ['safety','luck','warning']으로 교체.

## V4-11 쉽다 어렵다 — 수정 0
- fail("Don't worry if you fail the first time.")과 effort("Your effort matters more than the score.")가 프로젝트 헌법의 성장 마인드셋 원칙과 정확히 일치. 처벌·비교 문구 없음.
- difficult vs complicated는 서로의 distractor에 들어있지 않아 충돌 없음(hint로도 분리: '해도 안 됨' vs '얽혀서 머리 아픔').

## V4-12 싸다 비싸다 — 수정 1
- fee: "ten dollars monthly"가 딱딱함 → "ten dollars a month."
- expensive/wealthy/poor/bargain/discount/worth/afford/owe가 모두 다른 상황(스킨 가격·왕·기사·자켓·가게·카드·게임·누나 빚)에 놓여 대체 불가.

## V4-13 옳고 그름 — 수정 0
- IPA 12개 정확(θif, ɪnəsənt, əpɑlədʒaɪz 포함). confess/blame/forgive/apologize의 행위 주체가 예문에서 전부 다름.
- cheat의 ex_ko "커닝"은 초6에게 가장 자연스러운 표현이라 유지.

## V4-14 일상 루틴 동사 — 수정 0
- iron의 IPA "aɪərn"(오답 다발 지점) 정확. brush/floss, rest/relax, chore/habit 세 쌍 모두 예문에서 구별됨.

## V4-15 요리 동사 — 수정 2
- peel: "before you eat." 목적어 누락 → "before you eat it."
- serve: ex_ko "피자 뜨거울 때 내놔"의 '내놔'는 한국어로 '달라'는 뜻이 강해 의미 왜곡 → "피자 뜨거울 때 바로 상에 올려."
- chop(양파, 잘게) vs slice(빵, 얇게), mix(두 재료) vs stir(숟가락으로 젓기) 대비가 예문에서 성립.

## V4-16 고치고 만들기 — 수정 1
- metal: "Metal swords last longer than wood."는 비교 대상이 어긋난 문장(swords ↔ wood) → "Metal lasts longer than wood." / ex_ko "금속은 나무보다 오래 버텨."
- 보고(미수정): hammer·drill의 distractor에 상위어 'tool'이 들어가 변별력이 약하나 오답으로서 틀린 건 아니라 유지.

## V4-17 입고 벗기 — 수정 0
- put on / take off의 phr 표기·IPA·distractors(모두 phr) 일관. tight/loose 대조가 예문에서 성립.

## V4-18 사고 팔기 — 수정 0
- receipt "rɪsit"(묵음 p), cashier "kæʃɪr" 정확. browse(사기 전 구경) vs choose(하나 결정) vs order(주문)가 예문에서 분리됨.

## V4-19 돕고 나누기 — 수정 1
- **support: ko "응원하다, 지지하다"가 같은 팩 cheer "응원하다, 환호하다"와 첫 뜻이 완전 동일 — 같은 팩 안에서 정답이 둘이 되는 구조적 결함.** → support를 ko "지지하다, 편들어 주다" / ex "My friends support me when I feel sad." / ex_ko "친구들은 내가 힘들 때 내 편이 되어 줘."로 교체해 cheer(경기장 함성)와 완전 분리.

## V4-20 지키고 잃기 — 수정 0
- snatch(확 낚아챔) vs steal(몰래) vs recover(되찾음) vs gather(모음)가 예문에서 구별됨. recover는 '회복하다' 뜻을 빼고 단일 의미 유지(SPEC 규칙 6 준수).

---

## 전체 자동 검증 결과 (수정 후 재실행)
240단어 / 표제어 원본과 100% 일치(무변경) / 필수 필드 누락 0 / distractors 정확히 3개·중복 0·자기자신 포함 0 / pos 값 전부 유효 / 예문에 표제어 원형 포함 100% / 문장부호 정상 / **예문 길이 전부 9단어 이내(티어4 규격)** / IPA 슬래시 미포함 / V4 내 표제어 중복 0.

## 미해결·판단 보류
- 앱의 출제 형식이 '뜻→단어'인지 '빈칸 채우기'인지 확인하지 못했다. 빈칸 채우기라면 handsome↔skinny, lock↔close처럼 **문장만 놓고 보면 오답도 성립하는 조합**이 일부 남아 있다(뜻 기준으로는 전부 안전). 출제 형식이 빈칸형이면 재점검이 필요하다.
- 외모 팩(V4-05)의 신체 평가 어휘는 예문으로 완충했으나 최종 노출 판단은 Dio님 몫이다.

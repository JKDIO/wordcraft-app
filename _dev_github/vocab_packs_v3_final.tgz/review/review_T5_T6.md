# 티어5·6 교차검수 상세

## V5-01 (학교 과목) — 수정 0
- 12항목 ko/pos/ipa/예문 이상 없음. distractors 전부 동일 품사·의미장.

## V5-02 (시험과 성적) — 수정 1
- therefore: ex_ko "열심히 공부했다, 그러므로 통과했지"(문체 혼용) → "나는 열심히 공부했다. 그러므로 시험에 통과했다."
- 연결어 therefore 예문은 두 절(원인→결과) 구조 이미 충족.

## V5-03 (숙제와 발표) — 수정 2
- in addition: 단문이라 '추가' 관계가 안 보임 → "I wrote the report; in addition, I made slides."(9단어)
- as a result: 단문이라 인과가 안 보임 → "We watered it daily; as a result, it grew."(9단어)

## V5-04 (친구 사귀기) — 수정 1
- small talk: IPA에 장음기호(ˌsmɔːl ˈtɔːk)가 섞여 다른 항목과 불일치 → "ˌsmɔl ˈtɔk"(GA 표기 통일)

## V5-05 (규칙과 약속) — 수정 4
- dress code: ban(티어 초과 어휘) → "Our dress code says no flip-flops."
- deal: ex_ko "너가"(비표준) → "네가"
- truthful: ex_ko "제발 진실한 답을 줘"(직역투) → "제발 솔직하게 대답해 줘."
- behave: "Behave nicely"(부자연) → "Behave well at your friend's house."

## V5-06 (시간표와 계획) — 수정 2
- schedule: ko "일정, 시간표"가 같은 팩의 timetable(시간표)과 뜻 충돌 → ko "일정"으로 축소, hint 조정
- cancel: "They canceled soccer."(목적어 부자연) → "They canceled soccer practice because of rain."
- meanwhile 연결어 예문은 두 절 동시성 구조 충족.

## V5-07 (돈과 값) — 수정 2
- pay for / pocket money: IPA 장음기호(ː) 혼입 → GA 표기로 통일

## V5-08 (가게에서) — 수정 3
- checkout(계산대) 오답에 "counter"가 있어 오답도 정답이 됨 → "exit"으로 교체 [중요]
- aisle 오답 "basket"(장소 아님) → "entrance"
- sold out: "The last one was sold out."(의미 어긋남) → "The new game was already sold out."

## V5-09 (식당에서) — 수정 2
- starving: "I'm starving, let's order..."(comma splice) → "I'm starving! Let's order right now."
- greasy: ex_ko "손가락이 기름졌어"(비문에 가까움) → "치킨 먹었더니 손가락이 번들거려."

## V5-10 (병원에서) — 수정 0
- ko/pos/ipa/예문 이상 없음. 증상 어휘 distractors 모두 동일 의미장.

## V5-11 (여행 준비) — 수정 0
- 이상 없음.

## V5-12 (공항과 역) — 수정 0
- 이상 없음. departure/arrival 상호 오답 배치 적절.

## V5-13 (전화와 문자) — 수정 2
- hang up: comma splice → "Don't hang up! I'm almost done."
- speaker: "so we hear"(비문) → "so we can hear"

## V5-14 (인터넷과 앱) — 수정 1
- update: ex_ko "하기 전에 앱을 업데이트해"(주어 없음) → "게임 하기 전에 앱을 업데이트해."

## V5-15 (편지와 이메일) — 수정 1
- address(명사 '주소'): IPA əˈdres(동사 발음) → 명사 GA "ˈædres"
- however / besides 연결어 예문 모두 두 절 구조 충족.

## V5-16 (방향 안내) — 수정 1
- across from: IPA 장음기호 혼입 → "əˈkrɔs frəm"

## V5-17 (날짜와 기념일) — 수정 2
- national holiday: IPA 장음기호 혼입 → "ˌnæʃnəl ˈhɑlədeɪ"
- national holiday 오답 "countdown"(날 종류가 아님) → "weekend"

## V5-18 (축하와 파티) — 수정 1
- make a wish: "before you blow"(목적어 없어 부자연) → "before you blow out the candles."

## V5-19 (취미 활동) — 수정 0
- 이상 없음.

## V5-20 (음악과 악기) — 수정 1
- microphone: "The microphone squeaked when he spoke."(squeak은 쥐 소리 쪽, 부자연) → "He tapped the microphone before speaking."

## V6-01 (감정 심화 1) — 수정 1
- IPA 장음기호(ː) 4곳 혼입(nervous/worried/confused/relieved) → GA 표기로 정리
- ko/예문/오답 이상 없음. 예문 소재(성적표·캠프·월드 삭제)가 초6 눈높이에 적합.

### [전 팩 공통 조치] T6 20팩 IPA 장음기호 87곳 일괄 제거
- 같은 팩 안에서도 "ˈɑːrɡjumənt"와 "ɪnˈsʌlt"처럼 표기가 뒤섞여 있었음 → GA 무장음 표기로 통일.
- 참고: T1·T2 등 다른 티어에도 동일한 혼용이 남아 있음(담당 범위 밖, 별도 보고).

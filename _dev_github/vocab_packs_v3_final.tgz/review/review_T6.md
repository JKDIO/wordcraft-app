# 티어6 교차검수 상세 (V6-02 ~ V6-20, 19팩 228단어)

- 티어5 전체와 V6-01의 상세 기록은 `review_T5_T6.md`에 있다. 이 문서는 그 이어지는 범위다.
- 검수 항목: ko 정확성·pos 일치 / ipa(GA) / ex 문법·자연스러움 / ex_ko 자연스러움 / hint_ko가 정답을 말하지 않는가 / distractors 3개의 품사·의미장·복수정답 위험 / 부적절 내용·아재 밈.
- 구조 자동검증 통과: 19팩 × 12단어 = 228, 예문 전부 9단어 이하, IPA 장음기호(ː) 0곳, 오답 3개·중복 없음·자기 자신 미포함, pos 전부 허용값.

## 수정 총계 15건 (팩 9개), 심각(복수정답) 결함 3건

### V6-02 성격 형용사 2 — 수정 1
- cheerful: ex_ko "비 오는 날도 낫게 만들어"(직역투 + '병이 낫다'로 오독 가능) → "그 애의 밝은 목소리를 들으면 비 오는 날도 기분이 좋아져."

### V6-03 가족 관계와 역할 — 수정 3
- **raise [복수정답 위험]** ko "기르다, 키우다"인데 오답에 `keep`이 있었다. keep도 "(반려동물을) 기르다"로 정답이 된다 → 오답을 `['feed','train','protect']`로 교체.
- raise: ex "They raise three dogs and one cat."는 raise를 반려동물에 쓴 부자연스러운 용법(원어민은 have/keep) → "It's not easy to raise three kids." / "아이 셋을 키우는 건 쉽지 않아."
- grandparent: ex_ko "할아버지 할머니 각각 우리 그림을 받으셨어"(비문에 가까움) → "할아버지, 할머니 두 분 다 우리가 그린 그림을 받으셨어."

### V6-04 우정과 갈등 — 수정 0
- argument/insult/gossip 등 갈등 어휘가 초6 눈높이. "메시지를 씹다" 같은 표현도 비속어가 아니라 자연스러운 또래 말투로 판단.

### V6-05 예의와 태도 — 수정 0
- manners / table manners / wait one's turn / shake hands가 한 팩에 있으나 ko 표기가 서로 달라 복수정답 위험 없음.
- 참고(수정 안 함): table manners의 오답 `respect`는 이 팩에서 동사로 가르치는 단어다. respect는 명사로도 쓰이므로 품사 위반은 아니라고 판단해 두었다.

### V6-06 도움과 배려 — 수정 3
- **considerate [복수정답 위험]** 오답이 `helpful / unselfish / willing`으로 전부 같은 팩의 긍정 성격 형용사였다. 특히 "배려심 있는"과 unselfish("자기만 챙기지 않는")는 힌트("남이 어떨지 먼저 생각해 주는 마음")까지 겹쳐 둘 다 정답으로 보인다 → `['careless','rude','greedy']`(명확한 반대편)로 교체.
- **reach out [복수정답 위험]** ko가 "먼저 다가가다, 손을 내밀다"인데 오답에 `give a hand`(같은 팩, 힌트가 "손을 하나 빌려준다")가 있었다 → ko를 "먼저 다가가다"로 좁히고 오답을 `['look away','walk away','show up']`로 교체.
- unselfish: ex_ko "자기를 내려놓은 그 선택"(초6에게 추상적·어른스러움) → "자기 욕심을 버린 그 선택이 팀을 살렸어."

### V6-07 몸과 건강 — 수정 1
- heal: ex "My knee healed after two quiet weeks."의 "two quiet weeks"가 부자연스럽고, ex_ko "무릎이 조용히 지낸 2주 만에"는 비문 → "My knee healed in about two weeks." / "내 무릎은 2주쯤 지나니까 다 나았어."
- 철자 힌트(disease의 s 두 개, stomach의 ch=k, blood의 oo=ə, muscle의 묵음 c)는 전부 사실 확인 완료.

### V6-08 운동 2와 경기 — 수정 2
- **stadium ↔ court [복수정답 위험]** stadium의 ko가 "경기장"인데 오답에 `court`가 있었고, court의 ko도 "코트, 경기장 바닥"이었다. "경기장"만 보고는 둘 다 정답 → court의 ko를 "(농구·테니스) 코트"로 한정하고, stadium의 오답 `court`를 `gym`으로 교체.
- trophy ↔ medal 상호 오답은 ko(트로피/메달)가 확연히 달라 유지.

### V6-09 음식 문화 — 수정 0
- recipe의 오답 `receipt`는 초6이 실제로 헷갈리는 최고의 오답. 유지.

### V6-10 한국 소개하기 — 수정 2
- national: ex_ko "우리나라 국화는 여름에 펴."에서 '국화'를 초6은 國花가 아니라 菊花(꽃 이름)로 읽는다 → "우리나라를 대표하는 꽃은 여름에 핀다."
- pottery: 오답이 `palace / temple / landmark`(전부 건물)로 의미장이 어긋남 → `['painting','basket','statue']`(공예·미술품)로 교체.

### V6-11 세계의 나라 — 수정 0
- desert의 "s가 하나뿐이다"(dessert 대비), foreign의 묵음 g 힌트 모두 정확.

### V6-12 문화 차이 — 수정 1
- difference: ex "Can you find the difference in these pictures?"는 전치사가 어색(틀린그림찾기는 between) → "Can you find the difference between these pictures?" / "이 그림들 사이에서 다른 점을 찾을 수 있어?"
- similar의 오답 `equal`은 한국어 뜻이 "비슷한"과 "같은"으로 분명히 갈려 유지.

### V6-13 학교 행사 — 수정 0
- ceremony / assembly / rehearsal / exhibition이 서로 오답이지만 ko가 전부 달라 안전.

### V6-14 동아리와 봉사 — 수정 0
- leader ↔ mentor 상호 오답은 ko가 "리더, 지도자" / "멘토, 조언자"로 외래어가 붙어 있어 구분 가능.

### V6-15 꿈과 장래희망 — 수정 0
- achieve / passion / eager / ability 전부 중1 수준. 설교조 문장 없음(예: "Never give up on the last level.").

### V6-16 직업 2 — 수정 0
- 12개 직업명의 IPA·철자 전수 확인. designer의 묵음 g, lawyer=law 힌트 정확.

### V6-17 돈 관리 — 수정 1
- thrifty: 오답 `valuable`은 성격이 아니라 물건의 성질이라 의미장이 어긋남 → `['greedy','careless','generous']`(성격 형용사)로 교체.
- expense의 ex "Game skins are my biggest expense each month."는 과금을 권하는 문장이 아니라 이 팩(cut down on / thrifty / piggy bank)의 절약 흐름 안에서 자기 지출을 자각시키는 예문이라 유지.

### V6-18 약속과 시간 지키기 — 수정 0
- due / last minute / spare time 등 표현 정확. right away의 ex_ko("숙제 지금 바로 해, 제발.")는 잔소리 톤이 살짝 있으나 12개 중 하나뿐이고 농담 어조라 유지.

### V6-19 감사와 사과 심화 — 수정 1
- repay: ex_ko "언젠가 이 은혜를 어떻게 갚지?"의 '은혜'가 초6에게 과하게 어른스러운 어휘 → "언젠가 내가 어떻게 보답할 수 있을까?"

### V6-20 의견 말하기 1 — 수정 0
- agree with / disagree / to be honest / personally 전부 정확. 밈·유행어 없음.

## 수정하지 않았지만 기록해 두는 관찰
1. **조어(morphology) 힌트가 사실상 정답을 준다** — hardworking("hard와 working이 합쳐졌다"), teammate, babysit, impolite, unselfish, kindly, kindness, friendship, misunderstanding, reschedule, repay, disagree, unusual, ability, national, lawyer, hairdresser, tasty 등 18곳. 다만 hint_ko는 3단계 힌트의 **마지막** 단계이고, 단어 만들기(접두사·접미사) 원리를 가르치는 효과가 있어 결함으로 판정하지 않았다. 만약 hint를 1~2단계에서도 노출하는 설계라면 이 18곳은 전부 재작성 대상이다 — Dio님 판단 필요.
2. **cross-pack 유의어** — contest(V6-13, "대회")와 competition(V6-08, "대회, 경쟁")은 팩이 달라 같은 문제에 함께 나오진 않지만, 복습 단계에서 섞이면 헷갈릴 수 있다. w는 변경 금지 지시라 손대지 않았다.
3. 부적절한 내용·유행 지난 밈은 19팩 전체에서 발견되지 않았다. 게임 소재는 마인크래프트(레드스톤·성 짓기)와 게임 스킨 정도로 절제되어 있다.

## 검증하지 못한 것
- IPA는 GA 기준으로 표기 일관성과 명백한 오류만 확인했다. 실제 TTS(WebView 네이티브)로 읽혔을 때의 청취 검증은 하지 못했다.
- 예한이의 실제 반응·정답률 데이터에 근거한 난이도 검증은 하지 못했다(앱 노출 전이므로).
- `w`(표제어)의 전역 중복 여부는 이번 검수 범위 밖(사전 검증 완료로 전달받음).

# 티어 8 교차 검수 기록 (V8-04 ~ V8-20)

## V8-04 변화와 성장
- increase: ex "The zombies increase after the sun goes down." → 주어가 복수 가산명사라 증가 의미가 어색. "The number of zombies increases after the sun goes down."로 교체(ex_ko 동반 수정).
- 나머지 11항목: ko/pos/ipa/오답 이상 없음.

## V8-05 선택과 결정
- reluctant: ex가 같은 팩 refuse의 예문("his last cookie")과 장면이 겹쳐 변별이 흐려짐 → "Sam was reluctant to jump into the cold pool."로 교체.
- 나머지 이상 없음.

## V8-06 계획과 목표
- in order to: hint_ko가 뜻("~하려고")을 그대로 말해 정답 노출 → 이유·목적을 밝히는 자리 설명으로 교체.
- 나머지 이상 없음.

## V8-07 성공과 실패
- 수정 없음. success/failure가 같은 "cake" 장면으로 대비되는 것은 의도된 대조로 판단해 유지.

## V8-08 도전과 용기
- 수정 없음. 12항목 모두 장면이 구체적이고 오답 중복 없음.

## V8-09 습관과 태도
- persistent: ex "A persistent learner tries again after every mistake."가 추상적 일반론 → "Mia is persistent; she tried that jump twenty times."로 장면화.
- diligent/dedicated/persistent가 한 팩에 있으나 서로를 오답으로 쓰지 않아 정답 중복 위험 없음(확인함).

## V8-10 시간 관리
- immediately: ex "Answer Mom immediately or lose the phone."가 처벌(폰 압수) 뉘앙스 → "The bell rang, so we left the classroom immediately."로 교체.

## V8-11 기억과 학습
- come across: ex "You will come across new words every day."가 장면 없는 일반론 → "I came across an old photo in Dad's drawer."로 장면화.

## V8-12 상상과 창의
- original: ex 뒷부분 "I heard it."이 끊긴 느낌 → "I heard it last week."로 자연스럽게 보완.

## V8-13 감정 심화 2  ★정답 중복 사고 1건
- overjoyed(매우 기뻐하는)의 오답에 같은 팩 단어 delighted(아주 기뻐하는)가 들어 있어 **정답이 둘이 되는 상태**였음.
  → overjoyed ko를 "뛸 듯이 기쁜"으로 분화하고, 오답을 ['miserable','annoyed','ashamed']로 교체.
- ashamed: ko "부끄러운"이 한국어에서 수줍음(shy)과 혼동될 수 있어 "창피한, 부끄러운"으로 명확화.

## V8-14 관계의 거리
- relationship: ex가 같은 팩 bond의 예문("after the long trip")과 거의 동일해 두 단어 변별이 무너짐 → "I have a good relationship with my new teacher."로 교체.

## V8-15 사회와 규칙
- 수정 없음. 추상 개념 팩이지만 예문이 모두 학교·마을 장면으로 구체화되어 있음.

## V8-16 권리와 책임
- accuse: ex_ko "상자부터 확인하고 나를 의심해."가 영문(Don't accuse me without checking)의 뜻을 반대로 전달 → "상자부터 확인해 보지도 않고 나를 범인 취급하지 마."로 수정.

## V8-17 공정과 평등
- reasonable: ex "Ten minutes of break sounds reasonable."가 비문법적 어색함 → "A ten-minute break sounds reasonable to me."

## V8-18 협력과 경쟁
- unite / join forces가 예문 장면("Two small teams…")과 hint_ko 문구까지 거의 같아 변별 불가 → unite를 교실 응원 장면으로 교체하고 hint도 분화.

## V8-19 전통과 현대
- ritual: ko "의식, 늘 하는 절차"가 오답 custom(관습)·habit(습관)과 의미가 겹쳐 정답이 둘이 될 수 있었음 → ko "의식, 의례" + 오답 ['heritage','festival','costume']로 교체.
- era: 오답에 같은 팩 단어 generation(세대)이 들어 있어 "시대"와 혼동 소지 → ['century','moment','season']로 교체.

## V8-20 예술과 표현
- emotion: ex "That song brings strong emotions to me."가 어색한 결합 → "That song brings back strong emotions every time."

---

## 총평 (V8-04 ~ V8-20, 17팩 204단어)
- 수정 항목 16개. 유형별: 정답 중복 위험 3 / 예문 장면 중복·추상 일반론 5 / 영어 비문법·어색 4 / 한국어 오역 1 / hint 정답 노출 1 / 처벌 뉘앙스 1 / ko 뜻 명확화 1.
- 심각(아이에게 그대로 나가면 안 되는) 결함 2건: V8-13 overjoyed(정답이 둘), V8-16 accuse(ex_ko 뜻 반대).
- 구조 검증(스크립트): 17팩 모두 12단어, 필드 누락 0, 오답 3개·자기중복 0, 예문에 표제어 포함, 예문 12단어 이내, 전 팩 표제어 중복 0, known_words 충돌 0.
- 부적절 내용 없음. 티어 8 추상어 팩이지만 예문 장면은 대부분 학교·게임·가족으로 구체화되어 있어 티어 8 특유의 "튕겨 나감" 위험은 낮다고 판단.
- 검수하지 못한 것: 실제 TTS 발음 청취 테스트, 예한이의 실제 반응.

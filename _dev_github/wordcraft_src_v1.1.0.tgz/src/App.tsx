import { useCallback, useEffect, useState } from 'react'
import { WorldMap } from './screens/WorldMap'
import { ModuleSession } from './screens/ModuleSession'
import { DiagnosticRun } from './screens/DiagnosticRun'
import { ReviewMine } from './screens/ReviewMine'
import { Profile } from './screens/Profile'
import { AdminPage } from './screens/AdminPage'
import { AppInfo } from './screens/AppInfo'
import { Splash } from './screens/Splash'
import {
  loadLocal, saveLocal, initLearner, startSession, endSession, heartbeatSession, resumeSession, touchStreak,
  recordAnswer, recordXp, recordProgress, recordBadge, enqueue, type LocalState,
} from './lib/store'
import { db } from './lib/supabase'
import { DIAG_ORDER, MODULE_ORDER, WORLDS, loadModule } from './lib/content'
import { todayStr } from './lib/leitner'
import { APP_VERSION, isNewer, type VersionInfo } from './lib/version'
import type { StepEvent } from './engine/StepRunner'

function useHashRoute(): [string, (h: string) => void] {
  const [route, setRoute] = useState(() => location.hash.replace(/^#/, '') || '/')
  useEffect(() => {
    const on = () => setRoute(location.hash.replace(/^#/, '') || '/')
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  return [route, (h: string) => { location.hash = h }]
}

export default function App() {
  const [route, nav] = useHashRoute()
  const [state, setState] = useState<LocalState>(() => loadLocal())
  const [dueCount, setDueCount] = useState(0)
  const [backsMap, setBacksMap] = useState<Record<string, { back: string; tts?: string | null }>>({})
  // 스플래시 — 접속 화면에 따라 learner/admin 2종, 매 실행 1회
  const [splash, setSplash] = useState(true)
  const [splashVariant] = useState<'learner' | 'admin'>(() =>
    (location.hash.replace(/^#/, '') || '/').startsWith('/admin') ? 'admin' : 'learner')
  // 원격 업데이트 체크 — 서버 /version.json vs APP_VERSION
  const [latest, setLatest] = useState<VersionInfo | null>(null)
  const [checking, setChecking] = useState(true)
  const [rechecking, setRechecking] = useState(false)
  const checkVersion = useCallback(async () => {
    try {
      const res = await fetch(`/version.json?t=${Date.now()}`, { cache: 'no-store' })
      if (res.ok) setLatest(await res.json() as VersionInfo)
    } catch { /* 오프라인 — 확인 불가 표시 */ }
    setChecking(false)
    setRechecking(false)
  }, [])
  useEffect(() => { void checkVersion() }, [checkVersion])
  const updateAvailable = !!latest && isNewer(latest.version, APP_VERSION)

  // 초기화: 서버 병합 → 세션 시작 + 사용시간 기록(하트비트)
  useEffect(() => {
    // 관제실(아빠 앱)에서는 학습 세션을 만들지 않는다 — 아빠 열람 시간이 예한이 학습시간으로 잡히지 않도록
    if (location.hash.replace(/^#/, '').startsWith('/admin')) return
    let mounted = true
    ;(async () => {
      let s = await initLearner(state)
      s = await startSession(s)
      if (mounted) setState(s)
      if (s.learnerId) {
        db.select('review_cards', `learner_id=eq.${s.learnerId}&due_date=lte.${todayStr()}&select=id`)
          .then(rows => mounted && setDueCount(rows.length)).catch(() => {})
      }
    })()
    // 사용시간: 모바일 WebView는 pagehide가 거의 안 떠서 하트비트(30초) + 백그라운드 전환 시 확정 기록
    const hb = window.setInterval(() => heartbeatSession(), 30000)
    const onEnd = () => endSession()
    const onVis = () => { if (document.hidden) endSession(); else resumeSession() }
    window.addEventListener('pagehide', onEnd)
    document.addEventListener('visibilitychange', onVis)
    return () => {
      mounted = false
      clearInterval(hb)
      window.removeEventListener('pagehide', onEnd)
      document.removeEventListener('visibilitychange', onVis)
    }
  }, [])

  // 복습 카드 뒷면 맵 (콘텐츠에서 수집)
  useEffect(() => {
    MODULE_ORDER.forEach(id => {
      loadModule(id).then(m => {
        setBacksMap(prev => {
          const nx = { ...prev }
          for (const c of m.review_cards || []) nx[c.card_id] = { back: c.back, tts: c.tts }
          return nx
        })
      }).catch(() => {})
    })
  }, [])

  // ── 이벤트 핸들러 ──
  function onModuleEvent(moduleId: string) {
    return (e: StepEvent) => {
      recordAnswer(state, {
        module_id: moduleId, activity_type: e.activity_type, question_id: e.question_id,
        question_text: e.question_text, given_answer: e.given_answer, correct_answer: e.correct_answer,
        is_correct: e.is_correct, response_ms: e.response_ms,
      })
      if (e.xp > 0) setState(prev => recordXp(prev, e.xp, e.activity_type, moduleId))
    }
  }

  function onModuleComplete(moduleId: string) {
    return (sum: { score: number; xpGained: number; durationSec: number }) => {
      setState(prev => {
        let s = recordProgress(prev, moduleId, { status: 'completed', best_score: sum.score, completed: true, total_time_seconds: sum.durationSec })
        s = recordXp(s, 50, 'module_clear', moduleId) // 모듈 클리어 보너스 (문항 XP는 이미 반영)
        // 뱃지
        const done = MODULE_ORDER.filter(id => { const p = s.progress[id]; return p && (p.status === 'completed' || p.status === 'mastered') })
        if (done.length === 1) recordBadge(s, 'first_module')
        if (sum.score >= 100) recordBadge(s, 'perfect_module')
        for (const w of WORLDS) {
          if (w.modules.length && w.modules.every(id => done.includes(id))) recordBadge(s, `world${w.world}_clear`)
        }
        if (s.streak_days >= 3) recordBadge(s, 'streak_3')
        if (s.streak_days >= 7) recordBadge(s, 'streak_7')
        return s
      })
      // 복습 카드 시드 (내일부터 리젠)
      loadModule(moduleId).then(m => {
        if (!m.review_cards?.length || !state.learnerId) return
        const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 1)
        const rows = m.review_cards.map(c => ({
          learner_id: state.learnerId, card_id: c.card_id, card_front: c.front,
          box: 1, due_date: tomorrow.toISOString().slice(0, 10),
        }))
        enqueue({ kind: 'upsert', table: 'review_cards', payload: rows, conflict: 'learner_id,card_id' })
      }).catch(() => {})
      nav('/')
    }
  }

  function onDiagEvent(diagId: string) {
    return (e: { question_id: string; question_text?: string; given_answer?: string; correct_answer?: string; is_correct: boolean; response_ms?: number }) => {
      recordAnswer(state, { module_id: diagId, activity_type: 'diagnostic', ...e })
    }
  }

  function onDiagComplete(r: { diagId: string; pct: number; band: { label_ko: string; start_module: string } }) {
    setState(prev => {
      const diagDone = prev.diagDone.includes(r.diagId) ? prev.diagDone : [...prev.diagDone, r.diagId]
      // 배정 규칙 (A-006 v2): 시작점은 D1 밴드가 단일 축. 유일한 보정 = D4 정답률 60% 미만 시 월드1(최대 A3)로 하향.
      let placement = prev.placement
      if (r.diagId === 'D1') placement = r.band.start_module
      if (r.diagId === 'D4' && r.pct < 60 && placement === 'C0') placement = 'A3'
      let s: LocalState = { ...prev, diagDone, placement }
      saveLocal(s)
      s = recordProgress(s, `DIAG-${r.diagId}`, { status: 'completed', best_score: r.pct, completed: true })
      s = recordXp(s, 30, 'diagnostic_done', r.diagId)
      if (diagDone.length >= 4) recordBadge(s, 'diag_all')
      return s
    })
    const next = DIAG_ORDER.find(d => !state.diagDone.includes(d) && d !== r.diagId)
    nav(next ? `/diag/${next}` : '/')
  }

  // ── 라우팅 ──
  let screen: React.ReactNode
  if (route.startsWith('/admin')) screen = <AdminPage />
  else if (route.startsWith('/module/')) {
    const id = route.split('/')[2]
    screen = <ModuleSession moduleId={id} onEvent={onModuleEvent(id)} onComplete={onModuleComplete(id)} onExit={() => nav('/')} />
  } else if (route.startsWith('/diag')) {
    const id = route.split('/')[2] || DIAG_ORDER.find(d => !state.diagDone.includes(d)) || 'D1'
    screen = <DiagnosticRun diagId={id} onEvent={onDiagEvent(id)} onComplete={onDiagComplete} onExit={() => nav('/')} />
  } else if (route.startsWith('/re
// 전역 상태 + 로컬 우선 기록 + Supabase 비동기 동기화 큐 (오프라인 내성)
import { db, fetchLearner, type Learner } from './supabase'
import { levelForXp } from './xp'
import { todayStr } from './leitner'

export interface ProgressEntry {
  module_id: string
  status: 'locked' | 'available' | 'in_progress' | 'completed' | 'mastered'
  best_score: number | null
  attempts: number
}

export interface LocalState {
  learnerId: string | null
  nickname: string
  xp: number
  level: number
  streak_days: number
  last_active_date: string | null
  attendance: string[]
  diagDone: string[]
  placement: string | null
  progress: Record<string, ProgressEntry>
  sessionId: number | null
  sessionStart: number | null
}

const LS_KEY = 'wordcraft_state_v1'
const QUEUE_KEY = 'wordcraft_queue_v1'

export function loadLocal(): LocalState {
  try {
    const raw = localStorage.getItem(LS_KEY)
    if (raw) return JSON.parse(raw) as LocalState
  } catch { /* 첫 실행 */ }
  return {
    learnerId: null, nickname: '예한', xp: 0, level: 1, streak_days: 0,
    last_active_date: null, attendance: [], diagDone: [], placement: null, progress: {},
    sessionId: null, sessionStart: null,
  }
}

export function saveLocal(s: LocalState) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(s)) } catch { /* 저장 불가 무시 */ }
}

// ---------- 동기화 큐 (네트워크 실패 시 로컬 보존 → 재시도) ----------
interface QueueItem { kind: 'insert' | 'upsert' | 'update'; table: string; payload: unknown; conflict?: string; query?: string }

function loadQueue(): QueueItem[] {
  try { return JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]') } catch { return [] }
}
function saveQueue(q: QueueItem[]) {
  try { localStorage.setItem(QUEUE_KEY, JSON.stringify(q.slice(-500))) } catch { /* */ }
}

let flushing = false
export async function flushQueue() {
  if (flushing) return
  flushing = true
  try {
    // 한 번에 하나씩 — 매 반복마다 localStorage에서 큐를 다시 읽는다.
    // 전송 await 도중 enqueue된 항목을, 옆 메모리 스냅샷을 saveQueue로 저장하며 덮어써
    // 유실하던 레이스를 봉합(XP·배지·복습카드가 전부 사라지던 근본 원인).
    while (true) {
      const head = loadQueue()[0]
      if (!head) break
      try {
        if (head.kind === 'insert') await db.insert(head.table, head.payload as Record<string, unknown>)
        else if (head.kind === 'upsert') await db.upsert(head.table, head.payload as Record<string, unknown>, head.conflict || '')
        else await db.update(head.table, head.query || '', head.payload as Record<string, unknown>)
      } catch (e) {
        if (!String(e).includes('supabase 4')) break // 네트워크 등 — 맨 앞 항목 유지, 다음 기회 재시도
        // 4xx = 재시도 무의미 → 아래에서 제거하고 계속
      }
      const q = loadQueue() // await 이후 최신 큐를 다시 읽기 (그 사이 enqueue된 항목 보존)
      q.shift()             // 방금 처리한 맨 앞 1건만 제거
      saveQueue(q)
    }
  } finally { flushing = false }
}

export function enqueue(item: QueueItem) {
  const q = loadQueue()
  q.push(item)
  saveQueue(q)
  void flushQueue()
}

if (typeof window !== 'undefined') {
  window.addEventListener('online', () => void flushQueue())
  setInterval(() => void flushQueue(), 15000)
}

// ---------- 기록 헬퍼 (로컬 즉시 반영 + 큐 동기화) ----------
export function recordAnswer(s: LocalState, p: {
  module_id: string; activity_type: string; question_id: string
  question_text?: string; given_answer?: string; correct_answer?: string
  is_correct: boolean; response_ms?: number
}) {
  // 응답시간 상한 120초 절사 (A-019 — 탭 이탈 등 비정상 값이 통계를 오염시키지 않도록)
  const clamped = { ...p, response_ms: p.response_ms != null ? Math.min(p.response_ms, 120000) : undefined }
  enqueue({ kind: 'insert', table: 'answer_events', payload: { learner_id: s.learnerId, session_id: s.sessionId, ...clamped } })
}

export function recordXp(s: LocalState, amount: number, reason: string, module_id?: string): LocalState {
  // 스트릭은 "학습 이벤트 발생" 시에만 갱신 (R-10 봉합: 앱 열기만으로 출석 처리 금지)
  const touched = touchStreak(s)
  const xp = touched.xp + amount
  const level = levelForXp(xp)
  enqueue({ kind: 'insert', table: 'xp_events', payload: { learner_id: touched.learnerId, amount, reason, module_id: module_id || null } })
  enqueue({ kind: 'update', table: 'learners', query: `id=eq.${touched.learnerId}`, payload: { xp, level, last_active_date: todayStr(), streak_days: touched.streak_days } })
  const ns = { ...touched, xp, level }
  saveLocal(ns)
  return ns
}

export function recordProgress(s: LocalState, module_id: string, patch: Partial<ProgressEntry> & { total_time_seconds?: number; completed?: boolean }): LocalState {
  const prev = s.progress[module_id] || { module_id, status: 'available' as const, best_score: null, attempts: 0 }
  const entry: ProgressEntry = {
    module_id,
    status: patch.status || prev.status,
    best_score: patch.best_score != null ? Math.max(patch.best_score, prev.best_score ?? 0) : prev.best_score,
    attempts: prev.attempts + (patch.completed ? 1 : 0),
  }
  const payload: Record<string, unknown> = {
    learner_id: s.learnerId, module_id, status: entry.status, best_score: entry.best_score,
    attempts: entry.attempts, updated_at: new Date().toISOString(),
  }
  if (patch.completed) payload.completed_at = new Date().toISOString()
  if (patch.total_time_seconds) payload.total_time_seconds = patch.total_time_seconds
  enqueue({ kind: 'upsert', table: 'module_progress', payload, conflict: 'learner_id,module_id' })
  const ns = { ...s, progress: { ...s.progress, [module_id]: entry } }
  saveLocal(ns)
  return ns
}

export function recordBadge(s: LocalState, badge_id: string) {
  enqueue({ kind: 'upsert', table: 'badges', payload: { learner_id: s.learnerId, badge_id }, conflict: 'learner_id,badge_id' })
}

// ---------- 세션 (사용시간 기록) ----------
// 모바일 WebView는 pagehide/beforeunload가 거의 발생하지 않아, 종료 1회 기록에만 의존하면
// duration_seconds가 null로 남는다(관제실 "오늘 학습 시간" 0분 원인). → 30초 하트비트로 주기
// 갱신 + 백그라운드 전환(visibilitychange) 시 확정 기록. 시간은 "활성 구간"만 누적해, 화면
// 잠금/백그라운드로 얼어붙은 시간이 과대 집계되지 않도록 한다.
let _activeMs = 0 // 이번 세션 누적 활성 시간(ms) — 모듈 스코프(리로드=새 세션이라 초기화 정상)
let _lastTick = 0 // 마지막 틱 시각(ms)

export async function startSession(s: LocalState): Promise<LocalState> {
  const start = Date.now()
  let sessionId: number | null = null
  try {
    const rows = await db.insert('sessions', { learner_id: s.learnerId, device: navigator.userAgent.includes('Mobile') ? 'mobile' : 'desktop' })
    sessionId = (rows[0] as { id?: number })?.id ?? null
  } catch { /* 오프라인 — 세션 없이 진행, answer_events는 session_id null */ }
  _activeMs = 0
  _lastTick = start
  const ns = { ...s, sessionId, sessionStart: start }
  saveLocal(ns)
  return ns
}

// 활성 시간 누적 후 서버 duration 반영. end=true면 종료 확정(ended_at + 신뢰 큐 전송).
function tickSession(end: boolean) {
  const s = loadLocal()
  if (!s.sessionId) return
  const now = Date.now()
  const delta = now - _lastTick
  // 정상 경과(0~2분)만 누적 — 그 이상은 백그라운드/절전으로 얼어붙은 것이라 학습시간 아님
  if (delta > 0 && delta < 120000) _activeMs += delta
  _lastTick = now
  const dur = Math.round(_activeMs / 1000)
  if (dur <= 0 && !end) return
  const payload: Record<string, unknown> = { duration_seconds: dur }
  if (end) {
    payload.ended_at = new Date().toISOString()
    enqueue({ kind: 'update', table: 'sessions', query: `id=eq.${s.sessionId}`, payload }) // 오프라인 내성
  } else {
    db.update('sessions', `id=eq.${s.sessionId}`, payload).catch(() => {}) // 하트비트 — best-effort
  }
}

// 30초 주기 하트비트(App의 setInterval에서 호출)
export function heartbeatSession() { tickSession(false) }
// 백그라운드 전환/페이지 종료 — 사용시간 확정 기록
export function endSession() { tickSession(true) }
// 포그라운드 복귀 — 그 사이 얼어붙은 시간은 학습 아님, 구간만 리셋(누적 제외)
export function resumeSession() { _lastTick = Date.now() }

// ---------- 스트릭 ----------
export function touchStreak(s: LocalState): LocalState {
  const today = todayStr()
  if (s.last_active_date === today) return s
  const y = new Date(); y.setDate(y.getDate() - 1)
  const yesterday = y.toISOString().slice(0, 10)
  const streak = s.last_active_date === yesterday ? s.streak_days + 1 : 1
  // 주간 출석 칩용 기록 (시안 07): KST 날짜 push, 최근 14일 유지
  const att = s.attendance || []
  const attendance = att[att.length - 1] === today ? att : [...att, today].slice(-14)
  const ns = { ...s, streak_days: streak, last_active_date: today, attendance }
  saveLocal(ns)
  return ns
}

// ---------- 초기화 (서버 상태 병합) ----------
export async function initLearner(s: LocalState): Promise<LocalState> {
  try {
    const learner: Learner = await fetchLearner()
    const rows = await db.select('module_progress', `learner_id=eq.${learner.id}`)
    const progress: Record<string, ProgressEntry> = { ...s.progress }
    for (const r of rows as unknown as (ProgressEntry & { learner_id: string })[]) {
      progress[r.module_id] = { module_id: r.module_id, status: r.status, best_score: r.best_score, attempts: r.attempts }
    }
    const ns: LocalState = {
      ...s,
      learnerId: learner.id,
      nickname: learner.nickname,
      xp: Math.max(s.xp, learner.xp),
      level: Math.max(s.level, learner.level),
      streak_days: Math.max(s.streak_days, learner.streak_days),
      last_active_date: s.last_active_date || learner.last_active_date,
      progress,
    }
    saveLocal(ns)
    return ns
  } catch {
    return s // 오프라인 — 로컬 상태로 진행
  }
}

// 경량 Supabase REST 클라이언트 (PostgREST) — 외부 의존성 0
// 보안: publishable(anon) key만 사용 — 설계상 클라이언트 공개 가능. service key 없음.
const URL_BASE = 'https://gbynvzxgbpmoqdsriowz.supabase.co/rest/v1'
const ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdieW52enhnYnBtb3Fkc3Jpb3d6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM3NzE5NTksImV4cCI6MjA5OTM0Nzk1OX0.tMtlmdyHgq_AURSNe_D5JdHqORZ60C4I_fh1lJ19T8U'

export const FAMILY_CODE = 'wc-yehan-7351'

type Row = Record<string, unknown>

async function req(path: string, init: RequestInit = {}): Promise<Row[]> {
  const res = await fetch(`${URL_BASE}${path}`, {
    ...init,
    headers: {
      apikey: ANON_KEY,
      Authorization: `Bearer ${ANON_KEY}`,
      'Content-Type': 'application/json',
      Prefer: 'return=representation',
      ...(init.headers || {}),
    },
  })
  if (!res.ok) throw new Error(`supabase ${res.status}: ${await res.text()}`)
  const text = await res.text()
  return text ? JSON.parse(text) : []
}

export const db = {
  select: (table: string, query: string) => req(`/${table}?${query}`),
  insert: (table: string, rows: Row | Row[]) =>
    req(`/${table}`, { method: 'POST', body: JSON.stringify(rows) }),
  upsert: (table: string, rows: Row | Row[], onConflict: string) =>
    req(`/${table}?on_conflict=${onConflict}`, {
      method: 'POST',
      body: JSON.stringify(rows),
      headers: { Prefer: 'resolution=merge-duplicates,return=representation' },
    }),
  update: (table: string, query: string, patch: Row) =>
    req(`/${table}?${query}`, { method: 'PATCH', body: JSON.stringify(patch) }),
}

export interface Learner {
  id: string
  family_code: string
  nickname: string
  admin_pin: string
  xp: number
  level: number
  streak_days: number
  last_active_date: string | null
}

export async function fetchLearner(): Promise<Learner> {
  const rows = await db.select('learners', `family_code=eq.${FAMILY_CODE}&limit=1`)
  if (!rows.length) throw new Error('learner not found')
  return rows[0] as unknown as Learner
}

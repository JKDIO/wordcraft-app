// 이중화 TTS (영구교훈 L8) — APK(안드로이드 WebView)는 speechSynthesis 보이스가 비어
// 조용히 실패하므로, 네이티브면 Capacitor TextToSpeech 플러그인, 브라우저면 Web Speech API.
let voice: SpeechSynthesisVoice | null = null

function pickVoice() {
  const vs = window.speechSynthesis?.getVoices() ?? []
  voice =
    vs.find(v => v.lang === 'en-US' && /Google/i.test(v.name)) ||
    vs.find(v => v.lang === 'en-US') ||
    vs.find(v => v.lang.startsWith('en')) ||
    null
}

if (typeof window !== 'undefined' && window.speechSynthesis) {
  pickVoice()
  window.speechSynthesis.onvoiceschanged = pickVoice
}

// Capacitor 네이티브 TTS — 런타임 주입 window.Capacitor 글로벌로 직접 호출 (번들 의존성 0)
interface NativeTts { speak(opts: Record<string, unknown>): Promise<void> | void; stop?: () => void }
let nativePlugin: NativeTts | null = null
let nativeChecked = false

function nativeTts(): NativeTts | null {
  if (nativeChecked) retur
// XP 규칙 — CONTENT_SPEC §6 (콘텐츠·엔진 계약)
export const XP = {
  correct: 10,
  gameClear: 15,
  speak: 10,
  moduleClear: 50,
  bossClear: 100,
  reviewCorrect: 5,
} as const

/** 레벨업 필요 누적 XP = 300 × 현재 레벨 (누진) */
export function levelForXp(totalXp: number): number {
  let level = 1
  let need = 300
  let acc = totalXp
  while (acc >= need) {
    acc -= need
    level += 1
    need = 300 * level
  }
  return level
}

export function levelProgress(totalXp: number): { level: number; cur: number; need: number } {
  let level = 1
  let need = 300
  let acc = totalXp
  while (acc >= need) {
    acc -= need
    level += 1
    need = 300 * level
  }
  return { level, cur: acc, need }
}

export const LEVEL_TITLES = [
  '', '워드 탐험가', '사운드 마스터', '문장 건축가', '그래머 기사', '대화의 용사',
  '광산의 지배자', '언어 연금술사', '전설의 크래프터',
]
export function levelTitle(level: number): string {
  return LEVEL_TITLES[Math.min(level, LEVEL_TITLES.length - 1)] || '전설의 크래프터'
}

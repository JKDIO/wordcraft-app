import { useEffect, useState } from 'react'
import type { LocalState } from '../lib/store'
import { db } from '../lib/supabase'
import { levelProgress, levelTitle } from '../lib/xp'
import { MODULE_ORDER } from '../lib/content'
import { todayStr } from '../lib/leitner'

const BADGE_DEFS: Record<string, { emoji: string; name: string; desc: string }> = {
  first_module: { emoji: '🥇', name: '첫 채굴', desc: '첫 모듈 클리어' },
  world1_clear: { emoji: '⛏️', name: '소리 광산 정복', desc: '월드 1 전체 클리어' },
  world2_clear: { emoji: '🏰', name: '문법 성 정복', desc: '월드 2 전체 클리어' },
  world3_clear: { emoji: '🏹', name: '사냥의 달인', desc: '월드 3 전체 클리어' },
  world4_clear: { emoji: '🏕️', name: '생존왕', desc: '월드 4 전체 클리어' },
  streak_3: { emoji: '🔥', name: '3일 연속', desc: '3일 연속 출석' },
  streak_7: { emoji: '🌋', name: '일주일 불꽃', desc: '7일 연속 출석' },
  perfect_module: { emoji: '💯', name: '퍼펙트!', desc: '정확도 100% 클리어' },
  boss_slayer: { emoji: '⚔️', name: '보스 사냥꾼', desc: '보스전 5회 승리' },
  diag_all: { emoji: '📡', name: '풀 스캔', desc: '진단 4종 완료' },
  review_50: { emoji: '💎', name: '다이아 채굴자', desc: '복습 카드 50개 정답' },
}

const DOW = ['월', '화', '수', '목', '금', '토', '일']

export function Profile(props: { state: LocalState }) {
  const s = props.state
  const lp = levelProgress(s.xp)
  const onSeg = Math.min(10, Math.round((lp.cur / lp.need) * 10))
  const [badges, setBadges] = useState<string[]>([])

  useEffect(() => {
    if (!s.learnerId) return
    db.select('badges', `learner_id=eq.${s.learnerId}&select=badge_id`)
      .then(rows => setBadges((rows as { badge_id: string }[]).map(r => r.badge_id)))
      .catch(() => {})
  }, [s.learnerId])

  const completed = MODULE_ORDER.filter(id => {
    const p = s.progress[id]
    return p && (p.status === 'completed' || p.status === 'mastered')
  }).length

  // 이번 주(월~일) 출석 칩 (시안 07) — KST 날짜 기준
  const todayS = todayStr()
  const base = new Date(todayS + 'T12:00:00Z')
  const mondayOffset = (base.getUTCDay() + 6) % 7
  const week = Array.from({ length: 7 }, (_, k) => {
    const d = new Date(base)
    d.setUTCDate(base.getUTCDate() - mondayOffset + k)
    return d.toISOString().slice(0, 10)
  })
  const attendance = s.attendance || []

  return (
    <div className="profile">
      {/* 레벨 카드 (시안 05): 72×72 골드 블록 + 세그먼트 바 + 다음 레벨 안내문 */}
      <div className="wc-lv-card">
        <div className="wc-lv-big">LV.{lp.level}</div>
        <h3>{s.nickname}</h3>
        <p className="wc-lv-title">{levelTitle(lp.level)}</p>
        <div className="xpbar-seg">
          {Array.from({ length: 10 }, (_, k) => <i key={k} className={k < onSeg ? 'on' : ''} />)}
        </div>
        <div className="xp-meta"><span>{lp.cur} / {lp.need} XP</span><span>다음 레벨 -{lp.need - lp.cur}</span></div>
        <p className="note wc-lv-note">{lp.need - lp.cur} XP만 더 캐면 레벨 {lp.level + 1}! 계속 파보자 ⛏️</p>
      </div>

      {/* 스트릭 히어로 (시안 07): 골드 테두리 + 불꽃 + 밈 문구 */}
      <div className="wc-streak-hero">
        <span className="wc-flame">🔥</span>
        <h3>{s.streak_days}일 연속!</h3>
        <p className="note">{s.streak_days > 0 ? `오늘 한 판만 하면 ${s.streak_days + 1}일 — 최고 기록 경신 각 🔥` : '오늘 첫 채굴로 불꽃을 지펴보자! 🔥'}</p>
      </div>
      <div className="wc-week">
        {week.map((d, k) => {
          const done = attendance.includes(d)
          const isToday = d === todayS
          const future = d > todayS
          const cls = done ? 'is-done' : isToday ? 'is-today' : future ? 'is-future' : ''
          const mark = done ? '✓' : isToday ? '!' : '·'
          return <div key={d} className={`wc-day ${cls}`}>{DOW[k]}<b>{mark}</b></div>
        })}
      </div>

      <div className="stat-row">
        <div className="stat-tile"><b>⭐ {s.xp}</b><span>총 XP</span></div>
        <div className="stat-tile"><b>🔥 {s.streak_days}</b><span>연속 출석</span></div>
        <div className="stat-tile"><b>🗺️ {completed}/{MODULE_ORDER.length}</b><span>클리어</span></div>
      </div>

      {/* 뱃지 도감 (시안 08): 도감 카운트 + 미획득 실루엣/??? */}
      <h3 className="section-title wc-dex-head">🏆 뱃지 도감 <span className="wc-dex-count">{badges.length}/{Object.keys(BADGE_DEFS).length}</span></h3>
      <div className="badge-grid">
        {Object.entries(BADGE_DEFS).map(([id, b]) => {
          const got = badges.includes(id)
          return (
            <div key={id} className={`badge-card ${got ? 'got' : 'silhouette'}`}>
              <span className="badge-emoji">{b.emoji}</span>
              <b>{got ? b.name : '???'}</b>
              {got && <span className="badge-desc">{b.desc}</span>}
            </div>
          )
        })}
      </div>
    </div>
  )
}

export { BADGE_DEFS }

import { useEffect, useMemo, useState } from 'react'
import { db } from '../lib/supabase'
import { nextDue, todayStr } from '../lib/leitner'
import { speak } from '../lib/tts'
import type { LocalState } from '../lib/store'
import { enqueue, recordXp } from '../lib/store'
import { XP } from '../lib/xp'

interface Card { id: number; card_id: string; card_front: string; box: number; due_date: string }

// 라이트너 5층 (시안 09): 흙→돌→청금석→금→다이아
const LAYERS = [
  { name: '흙 층', cycle: '매일', desc: '새 카드·틀린 카드가 리스폰하는 곳' },
  { name: '돌 층', cycle: '2일마다', desc: '한 번 맞힌 카드' },
  { name: '청금석 층', cycle: '4일마다', desc: '제법 단단해진 기억' },
  { name: '금 층', cycle: '7일마다', desc: '거의 내 것' },
  { name: '다이아 층', cycle: '14일마다', desc: '완전 정복! 반짝반짝' },
]
const LAYER_NAMES = ['', '흙 층', '돌 층', '청금석 층', '금 층', '다이아 층']

/** 복습 광산 — 라이트너: 입구(5층 현황) → 채굴(플래시카드) */
export function ReviewMine(props: { state: LocalState; onXp: (s: LocalState) => void; backsMap: Record<string, { back: string; tts?: string | null }> }) {
  const [all, setAll] = useState<Card[] | null>(null)
  const [phase, setPhase] = useState<'entrance' | 'mining'>('entrance')
  const [i, setI] = useState(0)
  const [flipped, setFlipped] = useState(false)
  const [doneCount, setDoneCount] = useState(0)
  const [floatXp, setFloatXp] = useState(false)

  useEffect(() => {
    if (!props.state.learnerId) { setAll([]); return }
    db.select('review_cards', `learner_id=eq.${props.state.learnerId}&select=id,card_id,card_front,box,due_date&limit=500`)
      .then(rows => setAll(rows as unknown as Card[]))
      .catch(() => setAll([]))
  }, [])

  const today = todayStr()
  const dueCards = useMemo(
    () => (all || []).filter(c => c.due_date <= today).sort((a, b) => a.box - b.box),
    [all],
  )
  // 층별(박스별) 총량·오늘 due 집계
  const layers = useMemo(() => {
    const acc = [0, 0, 0, 0, 0, 0].map(() => ({ total: 0, due: 0 }))
    for (const c of all || []) {
      const b = Math.min(Math.max(c.box, 1), 5)
      acc[b].total++
      if (c.due_date <= today) acc[b].due++
    }
    return acc
  }, [all])

  if (all === null) return <div className="center-box"><p className="loading-msg">⛏️ 광산 탐색 중…</p></div>

  // ── 광산 입구 (5층 현황) ──
  if (phase === 'entrance') {
    return (
      <div className="reviewmine">
        <div className="mine-head">
          <h2>복습 광산 ⛏️</h2>
          <span className="due">오늘 캘 카드 {dueCards.length}</span>
        </div>
        {LAYERS.map((L, idx) => {
          const box = idx + 1
          const lay = layers[box]
          return (
            <div key={box} className={`wc-layer l${box} ${lay.due > 0 ? 'has-due' : ''}`}>
              <span className="ore">{box}</span>
              <span className="txt"><b>{L.name} — {L.cycle}</b><em>{L.desc}</em></span>
              <span className="cnt">{lay.total}장{lay.due > 0 ? ` · 오늘 ${lay.due}` : ''}</span>
            </div>
          )
        })}
        <button className="wc-go" disabled={dueCards.length === 0} onClick={() => { setPhase('mining'); setI(0); setDoneCount(0) }}>
          채굴 시작! ({dueCards.length}장) ⛏️
        </button>
        {dueCards.length === 0 && (
          <p className="tap-hint">오늘 캘 카드가 없어. 모듈을 클리어하면 광산에 카드가 쌓여! 내일 다시 와봐 🌙</p>
        )}
      </div>
    )
  }

  // ── 채굴 완료 ──
  if (i >= dueCards.length) {
    return (
      <div className="center-box">
        <div className="diag-big">{doneCount > 0 ? '💎' : '🌙'}</div>
        <h2>{doneCount > 0 ? `${doneCount}개 캐냈다!` : '오늘 캘 카드가 없어'}</h2>
        <p>{doneCount > 0 ? `+${doneCount * XP.reviewCorrect} XP 안팎 획득! 내일 또 리젠돼.` : '모듈을 클리어하면 복습 카드가 광산에 쌓여! 내일 다시 와봐 ⛏️'}</p>
        <button className="btn secondary wide" onClick={() => setPhase('entrance')}>광산 입구로 ⛏️</button>
      </div>
    )
  }

  const c = dueCards[i]
  const meta = props.backsMap[c.card_id]
  const back = meta?.back || '(뒷면 정보 없음 — 모듈에서 다시 배워보자!)'

  function grade(correct: boolean) {
    const { box, due_date } = nextDue(c.box, correct)
    enqueue({
      kind: 'update', table: 'review_cards', query: `id=eq.${c.id}`,
      payload: { box, due_date, last_result: correct, review_count: undefined, updated_at: new Date().toISOString() },
    })
    if (correct) {
      props.onXp(recordXp(props.state, XP.reviewCorrect, 'review_correct'))
      setDoneCount(d => d + 1)
      setFloatXp(true)
      setTimeout(() => setFloatXp(false), 1400)
    }
    setFlipped(false)
    setI(i + 1)
  }

  return (
    <div className="reviewmine">
      <p className="review-progress">⛏️ {i + 1} / {dueCards.length} <span className="box-chip">박스 {c.box} · {LAYER_NAMES[c.box]} · {c.card_id}</span></p>
      <button className={`flashcard ${flipped ? 'flipped' : ''}`} onClick={() => { setFlipped(true); if (meta?.tts) speak(meta.tts!) }}>
        {!flipped ? (
          <><p className="flash-front">{c.card_front}</p><p className="tap-hint">카드를 탭해서 뒤집기 👆</p></>
        ) : (
          <p className="flash-back">{back}</p>
        )}
        {floatXp && <span className="float-xp">+{XP.reviewCorrect} XP</span>}
      </button>
      {flipped && (
        <div className="grade-row">
          <button className="btn correct-btn" onClick={() => grade(true)}>알아! 😎</button>
          <button className="btn wrong-btn" onClick={() => grade(false)}>헷갈려 🤔</button>
        </div>
      )}
    </div>
  )
}

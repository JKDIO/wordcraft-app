import { useCallback, useEffect, useState } from 'react'
import { WorldMap } from './screens/WorldMap'
import { ModuleSession } from './screens/ModuleSession'
import { DiagnosticRun } from './screens/DiagnosticRun'
import { ReviewMine } from './screens/ReviewMine'
import { Profile } from './screens/Profile'
import { AdminPage } from './screens/AdminPage'
import { AppInfo } from './screens/AppInfo'
import { Splash } from './screens/Splash'
import {
  loadLocal, saveLocal, initLearner, startSession, endSession, heartbeatSession, resumeSession, touchStreak,
  recordAnswer, recordXp, recordProgress, recordBadge, enqueue, type LocalState,
} from './lib/store'
import { db } from './lib/supabase'
import { DIAG_ORDER, MODULE_ORDER, loadModule } from './lib/content'
import { computeEarnedBadges } from './lib/badges'
import { todayStr } from './lib/leitner'
import { APP_VERSION, isNewer, type VersionInfo } from './lib/version'
import type { StepEvent } from './engine/StepRunner'

// 오답 → 복습 카드로 들어가는 활동 유형 (진단·짝맞추기·말하기 제외 — "월드에서 틀린 모든 문제" 원칙)
const WRONG_TO_REVIEW = new Set(['quiz', 'boss', 'game_choice', 'game_listen_choice', 'game_order'])

function useHashRoute(): [string, (h: string) => void] {
  const [route, setRoute] = useState(() => location.hash.replace(/^#/, '') || '/')
  useEffect(() => {
    const on = () => setRoute(location.hash.replace(/^#/, '') || '/')
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  return [route, (h: string) => { location.hash = h }]
}

export default function App() {
  const [route, nav] = useHashRoute()
  const [state, setState] = useState<LocalState>(() => loadLocal())
  const [dueCount, setDueCount] = useState(0)
  const [backsMap, setBacksMap] = useState<Record<string, { back: string; tts?: string | null }>>({})
  // 스플래시 — 접속 화면에 따라 learner/admin 2종, 매 실행 1회
  const [splash, setSplash] = useState(true)
  const [splashVariant] = useState<'learner' | 'admin'>(() =>
    (location.hash.replace(/^#/, '') || '/').startsWith('/admin') ? 'admin' : 'learner')
  // 원격 업데이트 체크 — 서버 /version.json vs APP_VERSION
  const [latest, setLatest] = useState<VersionInfo | null>(null)
  const [checking, setChecking] = useState(true)
  const [rechecking, setRechecking] = useState(false)
  const checkVersion = useCallback(async () => {
    try {
      const res = await fetch(`/version.json?t=${Date.now()}`, { cache: 'no-store' })
      if (res.ok) setLatest(await res.json() as VersionInfo)
    } catch { /* 오프라인 — 확인 불가 표시 */ }
    setChecking(false)
    setRechecking(false)
  }, [])
  useEffect(() => { void checkVersion() }, [checkVersion])
  const updateAvailable = !!latest && isNewer(latest.version, APP_VERSION)

  // 뱃지 동기화 — 현재 상태로 획득 가능한 뱃지를 전부 판정해 놓친 것 소급 지급 (upsert라 중복 무해)
  const sessionRecorded = useState(() => new Set<string>())[0]
  const syncBadges = useCallback((s: LocalState) => {
    for (const id of computeEarnedBadges(s)) {
      if (sessionRecorded.has(id)) continue
      sessionRecorded.add(id)
      recordBadge(s, id)
    }
  }, [sessionRecorded])

  const refreshDueCount = useCallback((learnerId: string | null) => {
    if (!learnerId) return
    db.select('review_cards', `learner_id=eq.${learnerId}&due_date=lte.${todayStr()}&select=id`)
      .then(rows => setDueCount(rows.length)).catch(() => {})
  }, [])

  // 초기화: 서버 병합 → 세션 시작 + 사용시간 기록(하트비트)
  useEffect(() => {
    // 관제실(아빠 앱)에서는 학습 세션을 만들지 않는다 — 아빠 열람 시간이 예한이 학습시간으로 잡히지 않도록
    if (location.hash.replace(/^#/, '').startsWith('/admin')) return
    let mounted = true
    ;(async () => {
      let s = await initLearner(state)
      s = await startSession(s)
      // 보스전 승리 이력 서버 복원 (boss_slayer 뱃지 정확 판정 — 로컬 초기화에도 안전)
      if (s.learnerId) {
        try {
          const rows = await db.select('answer_events', `learner_id=eq.${s.learnerId}&activity_type=eq.boss&is_correct=eq.true&select=module_id&limit=2000`)
          const wins = Array.from(new Set([...(s.bossWins || []), ...(rows as { module_id: string }[]).map(r => r.module_id)]))
          s = { ...s, bossWins: wins }
          saveLocal(s)
        } catch { /* 오프라인 — 로컬 값 유지 */ }
      }
      if (mounted) setState(s)
      syncBadges(s) // 시작 시 소급 지급 (풀 스캔 등 유실 뱃지 복구)
      refreshDueCount(s.learnerId)
    })()
    // 사용시간: 모바일 WebView는 pagehide가 거의 안 떠서 하트비트(30초) + 백그라운드 전환 시 확정 기록
    const hb = window.setInterval(() => heartbeatSession(), 30000)
    const onEnd = () => endSession()
    const onVis = () => { if (document.hidden) endSession(); else resumeSession() }
    window.addEventListener('pagehide', onEnd)
    document.addEventListener('visibilitychange', onVis)
    return () => {
      mounted = false
      clearInterval(hb)
      window.removeEventListener('pagehide', onEnd)
      document.removeEventListener('visibilitychange', onVis)
    }
  }, [])

  // 복습 카드 뒷면 맵 (콘텐츠에서 수집)
  useEffect(() => {
    MODULE_ORDER.forEach(id => {
      loadModule(id).then(m => {
        setBacksMap(prev => {
          const nx = { ...prev }
          for (const c of m.review_cards || []) nx[c.card_id] = { back: c.back, tts: c.tts }
          return nx
        })
      }).catch(() => {})
    })
  }, [])

  // ── 이벤트 핸들러 ──
  function onModuleEvent(moduleId: string) {
    return (e: StepEvent) => {
      recordAnswer(state, {
        module_id: moduleId, activity_type: e.activity_type, question_id: e.question_id,
        question_text: e.question_text, given_answer: e.given_answer, correct_answer: e.correct_answer,
        is_correct: e.is_correct, response_ms: e.response_ms,
      })
      setState(prev => {
        let s = prev
        // 오답 → 즉시 복습 광산에 리스폰 (박스1, 오늘부터 due — "틀린 모든 문제는 복습으로")
        if (!e.is_correct && WRONG_TO_REVIEW.has(e.activity_type) && s.learnerId) {
          enqueue({
            kind: 'upsert', table: 'review_cards', conflict: 'learner_id,card_id',
            payload: {
              learner_id: s.learnerId, card_id: `W:${moduleId}:${e.question_id}`,
              card_front: e.question_text || e.question_id,
              card_back: e.correct_answer || '(모듈에서 다시 확인해보자!)',
              box: 1, due_date: todayStr(),
            },
          })
        }
        // 보스전 승리 기록 (boss_slayer)
        if (e.activity_type === 'boss' && e.is_correct && !(s.bossWins || []).includes(moduleId)) {
          s = { ...s, bossWins: [...(s.bossWins || []), moduleId] }
          saveLocal(s)
        }
        if (e.xp > 0) s = recordXp(s, e.xp, e.activity_type, moduleId)
        return s
      })
    }
  }

  function onModuleComplete(moduleId: string) {
    return (sum: { score: number; xpGained: number; durationSec: number }) => {
      setState(prev => {
        let s = recordProgress(prev, moduleId, { status: 'completed', best_score: sum.score, completed: true, total_time_seconds: sum.durationSec })
        s = recordXp(s, 50, 'module_clear', moduleId) // 모듈 클리어 보너스 (문항 XP는 이미 반영)
        syncBadges(s) // 뱃지 전수 판정 (첫 채굴·월드 정복·퍼펙트·스트릭·보스 사냥꾼 등)
        return s
      })
      // 복습 카드 시드 (내일부터 리젠)
      loadModule(moduleId).then(m => {
        if (!m.review_cards?.length || !state.learnerId) return
        const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 1)
        const rows = m.review_cards.map(c => ({
          learner_id: state.learnerId, card_id: c.card_id, card_front: c.front, card_back: c.back,
          box: 1, due_date: tomorrow.toISOString().slice(0, 10),
        }))
        // ignore=true: 이미 광산에 있는 카드는 박스·일정 보존 (재플레이가 라이트너 성취를 리셋하지 않도록)
        enqueue({ kind: 'upsert', table: 'review_cards', payload: rows, conflict: 'learner_id,card_id', ignore: true })
      }).catch(() => {})
      refreshDueCount(state.learnerId) // 오답 리스폰 반영
      nav('/')
    }
  }

  function onDiagEvent(diagId: string) {
    return (e: { question_id: string; question_text?: string; given_answer?: string; correct_answer?: string; is_correct: boolean; response_ms?: number }) => {
      recordAnswer(state, { module_id: diagId, activity_type: 'diagnostic', ...e })
    }
  }

  function onDiagComplete(r: { diagId: string; pct: number; band: { label_ko: string; start_module: string } }) {
    setState(prev => {
      const diagDone = prev.diagDone.includes(r.diagId) ? prev.diagDone : [...prev.diagDone, r.diagId]
      // 배정 규칙 (A-006 v2): 시작점은 D1 밴드가 단일 축. 유일한 보정 = D4 정답률 60% 미만 시 월드1(최대 A3)로 하향.
      let placement = prev.placement
      if (r.diagId === 'D1') placement = r.band.start_module
      if (r.diagId === 'D4' && r.pct < 60 && placement === 'C0') placement = 'A3'
      let s: LocalState = { ...prev, diagDone, placement }
      saveLocal(s)
      s = recordProgress(s, `DIAG-${r.diagId}`, { status: 'completed', best_score: r.pct, completed: true })
      s = recordXp(s, 30, 'diagnostic_done', r.diagId)
      syncBadges(s) // 풀 스캔 포함 전수 판정 (서버 병합된 진단 이력까지 반영 — 유실 봉합)
      return s
    })
    const next = DIAG_ORDER.find(d => !state.diagDone.includes(d) && d !== r.diagId)
    nav(next ? `/diag/${next}` : '/')
  }

  // ── 라우팅 ──
  let screen: React.ReactNode
  if (route.startsWith('/admin')) screen = <AdminPage />
  else if (route.startsWith('/module/')) {
    const id = route.split('/')[2]
    screen = <ModuleSession moduleId={id} onEvent={onModuleEvent(id)} onComplete={onModuleComplete(id)} onExit={() => nav('/')} />
  } else if (route.startsWith('/diag')) {
    const id = route.split('/')[2] || DIAG_ORDER.find(d => !state.diagDone.includes(d)) || 'D1'
    screen = <DiagnosticRun diagId={id} onEvent={onDiagEvent(id)} onComplete={onDiagComplete} onExit={() => nav('/')} />
  } else if (route.startsWith('/review')) {
    screen = <ReviewMine state={state} onXp={s => { setState(s); syncBadges(s) }} backsMap={backsMap}
      onFinished={() => refreshDueCount(state.learnerId)} />
  } else if (route.startsWith('/profile')) {
    screen = <Profile state={state} />
  } else if (route.startsWith('/info')) {
    screen = <AppInfo latest={latest} checking={checking} rechecking={rechecking} updateAvailable={updateAvailable}
      onUpdate={() => location.reload()} onRecheck={() => { setRechecking(true); void checkVersion() }} />
  } else {
    screen = <WorldMap state={state} dueCount={dueCount} onOpenModule={id => nav(`/module/${id}`)} onOpenDiag={() => nav('/diag')} />
  }

  const inSession = route.startsWith('/module/') || route.startsWith('/diag')
  const isAdmin = route.startsWith('/admin')

  return (
    <>
      {splash && <Splash variant={splashVariant} onDone={() => setSplash(false)} />}
      <div className="app">
        <main className="app-main">{screen}</main>
        {!inSession && !isAdmin && (
          <nav className="bottomnav">
            <button className={route === '/' ? 'on' : ''} onClick={() => nav('/')}><span>🗺️</span>월드맵</button>
            <button className={route.startsWith('/review') ? 'on' : ''} onClick={() => nav('/review')}>
              <span>⛏️</span>복습 광산{dueCount > 0 && <em className="nav-badge">{dueCount}</em>}
            </button>
            <button className={route.startsWith('/profile') ? 'on' : ''} onClick={() => nav('/profile')}><span>🧑‍🚀</span>내 정보</button>
            <button className={route.startsWith('/info') ? 'on' : ''} onClick={() => nav('/info')}>
              <span>ℹ️</span>정보{updateAvailable && <em className="nav-badge alert">!</em>}
            </button>
          </nav>
        )}
      </div>
    </>
  )
}

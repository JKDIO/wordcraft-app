// 콘텐츠 로더 — CONTENT_SPEC v1.0 계약 타입
// 배포본은 단일 /content.json (7/14 평탄화 — 모듈·진단 JSON을 1회 fetch 후 메모리 인덱싱)
export interface TtsText { tts?: string | null }

export interface StoryLine { speaker: string; emoji?: string; text_ko: string; text_en?: string | null }
export interface LearnExample extends TtsText { en: string; ko: string }
export interface LearnCard { title_ko: string; rule_ko: string; examples: LearnExample[]; tip_ko?: string }
export interface ChoiceItem extends TtsText {
  id: string; q_ko: string; choices: string[]; answer_idx: number; explain_ko: string
  meme_correct?: string; meme_wrong?: string
}
export interface MatchPair extends TtsText { left: string; right: string }
export interface OrderItem extends TtsText { id: string; prompt_ko: string; tokens: string[]; answer: string; ko?: string }

export type Step =
  | { type: 'story'; lines: StoryLine[] }
  | { type: 'learn'; card: LearnCard }
  | { type: 'game'; kind: 'choice' | 'listen_choice'; prompt_ko?: string; items: ChoiceItem[] }
  | { type: 'game'; kind: 'match'; prompt_ko?: string; items: { pairs: MatchPair[] }[] | { pairs: MatchPair[] } }
  | { type: 'game'; kind: 'order'; prompt_ko?: string; items: OrderItem[] }
  | { type: 'quiz'; questions: ChoiceItem[] }
  | { type: 'speak'; mission_ko: string; target_en: string; tts: string }

export interface ReviewCardDef extends TtsText { card_id: string; front: string; back: string }
export interface ModuleDef {
  module_id: string; world: number; order: number
  title_ko: string; subtitle_ko?: string; emoji: string
  xp_module_clear: number; estimated_minutes: number
  steps: Step[]; review_cards: ReviewCardDef[]
  boss: { title_ko: string; intro_ko?: string; questions: ChoiceItem[] }
}

export interface DiagQuestion extends ChoiceItem { kind?: 'choice' | 'listen_choice' | 'order'; tokens?: string[]; answer?: string; prompt_ko?: string }
export interface DiagDef {
  diag_id: string; title_ko: string; emoji: string; intro_ko: string
  questions: DiagQuestion[]
  scoring: { bands: { min_pct: number; label_ko: string; start_module: string }[] }
}

// v1.2.0 확장: 문법 성 +C7, 동사 사냥터 +B22a/B22b, 생존 캠프 +D2S/D3S, 월드5 시제 시간여행 오픈
export const WORLDS = [
  { world: 1, name_ko: '소리 광산', emoji: '⛏️', modules: ['A1', 'A2', 'A3', 'A4'] },
  { world: 2, name_ko: '문법 성', emoji: '🏰', modules: ['C0', 'C5', 'C6', 'C7'] },
  { world: 3, name_ko: '동사 사냥터', emoji: '🏹', modules: ['B21a', 'B21b', 'B22a', 'B22b'] },
  { world: 4, name_ko: '생존 캠프', emoji: '🏕️', modules: ['D1S', 'D2S', 'D3S'] },
  { world: 5, name_ko: '시제 시간여행', emoji: '⏳', modules: ['T1', 'T2', 'T3'] },
  { world: 6, name_ko: '??? (곧 열림)', emoji: '🔒', modules: [] },
]
export const MODULE_ORDER = ['A1', 'A2', 'A3', 'A4', 'C0', 'C5', 'C6', 'C7', 'B21a', 'B21b', 'B22a', 'B22b', 'D1S', 'D2S', 'D3S', 'T1', 'T2', 'T3']
export const DIAG_ORDER = ['D1', 'D2', 'D3', 'D4']

interface ContentBundle { modules: Record<string, ModuleDef>; diagnostics: Record<string, DiagDef> }

let bundlePromise: Promise<ContentBundle> | null = null

/** 단일 content.json 1회 fetch — 이후 모든 모듈/진단은 메모리에서 반환 */
function loadContent(): Promise<ContentBundle> {
  if (!bundlePromise) {
    bundlePromise = fetch('/content.json').then(res => {
      if (!res.ok) throw new Error(`콘텐츠를 불러오지 못했어 (${res.status})`)
      return res.json() as Promise<ContentBundle>
    })
  }
  return bundlePromise
}

export const loadModule = (id: string) =>
  loadContent().then(c => {
    const m = c.modules[id]
    if (!m) throw new Error(`모듈 ${id}을(를) 찾지 못했어`)
    return m
  })

export const loadDiag = (id: string) =>
  loadContent().then(c => {
    const d = c.diagnostics[id]
    if (!d) throw new Error(`진단 ${id}을(를) 찾지 못했어`)
    return d
  })

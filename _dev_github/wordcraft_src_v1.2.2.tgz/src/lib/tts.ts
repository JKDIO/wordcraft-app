// 이중화 TTS (영구교훈 L8) — APK(안드로이드 WebView)는 speechSynthesis 보이스가 비어
// 조용히 실패하므로, 네이티브면 Capacitor TextToSpeech 플러그인, 브라우저면 Web Speech API.
let voice: SpeechSynthesisVoice | null = null

function pickVoice() {
  const vs = window.speechSynthesis?.getVoices() ?? []
  voice =
    vs.find(v => v.lang === 'en-US' && /Google/i.test(v.name)) ||
    vs.find(v => v.lang === 'en-US') ||
    vs.find(v => v.lang.startsWith('en')) ||
    null
}

if (typeof window !== 'undefined' && window.speechSynthesis) {
  pickVoice()
  window.speechSynthesis.onvoiceschanged = pickVoice
}

// Capacitor 네이티브 TTS — 런타임 주입 window.Capacitor 글로벌로 직접 호출 (번들 의존성 0)
interface NativeTts { speak(opts: Record<string, unknown>): Promise<void> | void; stop?: () => void }
let nativePlugin: NativeTts | null = null
let nativeChecked = false

function nativeTts(): NativeTts | null {
  if (nativeChecked) return nativePlugin
  nativeChecked = true
  try {
    const Cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean; isNative?: boolean; Plugins?: Record<string, NativeTts>; registerPlugin?: (n: string) => NativeTts } }).Capacitor
    if (!Cap || !(Cap.isNativePlatform?.() ?? Cap.isNative)) return (nativePlugin = null)
    nativePlugin = Cap.Plugins?.TextToSpeech || (Cap.registerPlugin ? Cap.registerPlugin('TextToSpeech') : null)
  } catch { nativePlugin = null }
  return nativePlugin
}

function speakWeb(text: string, rate: number) {
  try {
    const synth = window.speechSynthesis
    if (!synth) return
    synth.cancel()
    const u = new SpeechSynthesisUtterance(text)
    u.lang = 'en-US'
    if (voice) u.voice = voice
    u.rate = rate
    synth.speak(u)
  } catch { /* TTS 불가 기기 — 소리 없이도 학습 가능하게 설계됨 */ }
}

export function speak(text: string, rate = 0.85) {
  const n = nativeTts()
  if (n && typeof n.speak === 'function') {
    try {
      try { n.stop?.() } catch { /* */ }
      const p = n.speak({ text, lang: 'en-US', rate, pitch: 1, volume: 1, category: 'ambient' })
      if (p && typeof (p as Promise<void>).catch === 'function') (p as Promise<void>).catch(() => speakWeb(text, rate))
      return
    } catch { /* 네이티브 실패 → 웹 폴백 */ }
  }
  speakWeb(text, rate)
}

export function ttsAvailable(): boolean {
  if (typeof window === 'undefined') return false
  if (nativeTts()) return true
  return 'speechSynthesis' in window
}

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { db, fetchLearner, type Learner } from '../lib/supabase'
import { MODULE_ORDER, WORLDS } from '../lib/content'
import { XP, levelProgress, levelTitle } from '../lib/xp'
import { BADGE_DEFS } from '../lib/badges'
import { APP_VERSION, isNewer, type VersionInfo } from '../lib/version'

/* ─────────────────────────────────────────────
   아빠 전용 관제실 v2 — 심층 학습관리 대시보드 (모바일 우선)
   - PIN 게이트 → 탭 메뉴(개요/활동/복습/분석/진행/보상)
   - 집계는 answer_events·module_progress 기반(앱 동기화 상태와 무관하게 정확)
   - XP는 앱 실제 규칙(StepRunner)과 동일 산식 → 오늘 XP와 누적 XP가 같은 날 일치
──────────────────────────────────────────────*/

interface AnswerEvent {
  id: number; module_id: string; activity_type: string; question_id: string
  question_text: string | null; given_answer: string | null; correct_answer: string | null
  is_correct: boolean; response_ms: number | null; created_at: string
}
interface ModProgress { module_id: string; status: string; best_score: number | null; attempts: number; total_time_seconds: number; first_started_at: string | null; completed_at: string | null; updated_at: string }
interface Session { id: number; started_at: string; ended_at: string | null; duration_seconds: number | null; device: string | null }
interface ReviewCard { card_id: string; card_front: string | null; box: number; due_date: string | null; last_result: boolean | null; review_count: number; updated_at: string }
interface BadgeRow { id: number; badge_id: string; earned_at: string }
interface RewardRow { id: number; learner_id: string; milestone_xp: number; note: string | null; granted_at: string }

type Tab = 'overview' | 'activity' | 'review' | 'analysis' | 'progress' | 'rewards'

const TABS: { id: Tab; icon: string; label: string }[] = [
  { id: 'overview', icon: '📊', label: '개요' },
  { id: 'activity', icon: '🗓️', label: '활동' },
  { id: 'review', icon: '⛏️', label: '복습' },
  { id: 'analysis', icon: '🔬', label: '분석' },
  { id: 'progress', icon: '🗺️', label: '진행' },
  { id: 'rewards', icon: '🎁', label: '보상' },
]

/** 모듈 한글 별명 (v1.2.0: 신규 8모듈 추가) */
const MODULE_NAMES: Record<string, string> = {
  A1: '알파벳 두 얼굴', A2: '모음 5형제', A3: '소리 합치기', A4: '마법의 e',
  C0: '영어나라 헌법', C5: '대명사 변신', C6: 'be동사 삼형제', C7: '일반동사 부대',
  B21a: '동사 사냥터 1', B21b: '동사 사냥터 2', B22a: '동사 사냥터 3', B22b: '동사 사냥터 4',
  D1S: '생존 캠프', D2S: '미국 상륙 작전', D3S: '미국 친구 사귀기',
  T1: '과거로 GO!', T2: '미래로 GO!', T3: '지금 이 순간',
}

/** 라이트너 박스 층 색 (흙→돌→청금석→금→다이아) */
const BOX_COLORS = ['var(--dirt)', 'var(--wc-stone)', 'var(--info)', 'var(--gold)', 'var(--diamond)']
const BOX_LABELS = ['박스1 (오늘)', '박스2 (2일)', '박스3 (4일)', '박스4 (7일)', '박스5 (14일)']

const DOW_KO = ['일', '월', '화', '수', '목', '금', '토']
const GOAL_SEC = 15 * 60
const MILESTONE = 1000
const DIAG_DONE_XP = 30 // App.tsx onDiagComplete 보너스와 동일

/** 향후 확장 월드 로드맵 — 중학 대비 심화 과정 (콘텐츠 추가 시 열림)
 *  월드 5(시제 시간여행)는 v1.2.0에서 정식 오픈 → 로드맵에서 졸업 */
const FUTURE_WORLDS: { world: number; emoji: string; name: string; desc: string }[] = [
  { world: 6, emoji: '🧩', name: '문장 확장 공방', desc: '접속사·관계사·구와 절로 긴 문장 만들기' },
  { world: 7, emoji: '📖', name: '독해 던전', desc: '짧은 지문 읽기 → 중학 내신형 독해 훈련' },
  { world: 8, emoji: '🔨', name: '어휘 대장간', desc: '중학 필수 어휘 + 접두사·접미사로 단어 폭발' },
  { world: 9, emoji: '💬', name: '회화 아레나', desc: '상황별 실전 회화 — 자기소개·여행·토론' },
  { world: 10, emoji: '✍️', name: '서술 마스터리', desc: '문장→문단 영작 + 시험 서술형 대비' },
]

/** 앱 실제 XP 규칙(StepRunner·ReviewMine emit)과 동일 산식 (CONTRACT §2)
 *  복습 10 XP는 v1.2.0부터 — 그 전엔 복습 answer_events 자체가 없었으므로 소급 불일치 없음 */
function xpOf(e: AnswerEvent): number {
  switch (e.activity_type) {
    case 'diagnostic': return 0 // 진단 문항은 XP 없음(완료 시 보너스만)
    case 'game_match': return XP.gameClear // 15 — 엔진이 정오답 무관 부여
    case 'speak': return XP.speak // 10
    case 'review': return e.is_correct ? XP.reviewCorrect : 0 // 10 (v1.2.0 복습 개편)
    default: return e.is_correct ? XP.correct : 0 // 10
  }
}
/** 복습 콤보 보너스 — 하루 복습 정답 10장마다 +20 (ReviewMine과 동일 산식) */
function comboBonusOf(reviewCorrectInDay: number): number {
  return Math.floor(reviewCorrectInDay / XP.reviewComboEvery) * XP.reviewCombo
}
function moduleBonus(p: ModProgress): number {
  return p.module_id.startsWith('DIAG-') ? DIAG_DONE_XP : XP.moduleClear // 30 / 50
}

/** KST 날짜 키 'YYYY-MM-DD' */
function kstDate(iso: string): string { return new Date(iso).toLocaleDateString('sv', { timeZone: 'Asia/Seoul' }) }
/** KST 시:분:초 */
function kstClock(iso: string): string {
  return new Date(iso).toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul', hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })
}
function dateLabel(key: string, todayKey: string, yKey: string): string {
  if (key === todayKey) return '오늘'
  if (key === yKey) return '어제'
  const d = new Date(`${key}T00:00:00Z`)
  return `${d.getUTCMonth() + 1}월 ${d.getUTCDate()}일 (${DOW_KO[d.getUTCDay()]})`
}
function fmtMin(sec: number): string {
  const m = Math.floor(sec / 60)
  if (m < 60) return `${m}분`
  return `${Math.floor(m / 60)}시간 ${m % 60}분`
}

export function AdminPage() {
  const [pinOk, setPinOk] = useState(() => sessionStorage.getItem('wc_admin') === '1')
  return pinOk ? <Dashboard /> : <PinGate onOk={() => { sessionStorage.setItem('wc_admin', '1'); setPinOk(true) }} />
}

function PinGate(props: { onOk: () => void }) {
  const [pin, setPin] = useState('')
  const [err, setErr] = useState(false)
  const [serverPin, setServerPin] = useState<string | null>(null)
  useEffect(() => { fetchLearner().then(l => setServerPin(l.admin_pin)).catch(() => setServerPin('7351')) }, [])
  function tryPin(p: string) {
    if (serverPin && p === serverPin) props.onOk()
    else { setErr(true); setPin(''); setTimeout(() => setErr(false), 1200) }
  }
  return (
    <div className="center-box admin-pin">
      <div className="diag-big">👨‍👦</div>
      <h2>아빠 전용 관제실</h2>
      <p>PIN 4자리를 입력하세요</p>
      <div className={`pin-dots ${err ? 'shake' : ''}`}>{[0, 1, 2, 3].map(i => <span key={i} className={`pin-dot ${i < pin.length ? 'filled' : ''}`} />)}</div>
      {err && <p className="pin-err">PIN이 달라요</p>}
      <div className="pin-pad">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, '⌫'].map((k, i) => (
          <button key={i} className="pin-key" disabled={k === ''} onClick={() => {
            if (k === '⌫') setPin(pin.slice(0, -1))
            else if (pin.length < 4) {
              const np = pin + String(k)
              setPin(np)
              if (np.length === 4) tryPin(np)
            }
          }}>{k}</button>
        ))}
      </div>
    </div>
  )
}

function Dashboard() {
  const [tab, setTab] = useState<Tab>('overview')
  const [learner, setLearner] = useState<Learner | null>(null)
  const [events, setEvents] = useState<AnswerEvent[]>([])
  const [progress, setProgress] = useState<ModProgress[]>([])
  const [sessions, setSessions] = useState<Session[]>([])
  const [cards, setCards] = useState<ReviewCard[]>([])
  const [badges, setBadges] = useState<BadgeRow[]>([])
  const [rewards, setRewards] = useState<RewardRow[]>([])
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null)
  const [loading, setLoading] = useState(false)
  const [viewerOpen, setViewerOpen] = useState(false)
  const [granting, setGranting] = useState<number | null>(null)
  const [latest, setLatest] = useState<VersionInfo | null>(null)
  const timerRef = useRef<number | null>(null)

  const refresh = useCallback(async () => {
    setLoading(true)
    // 새 버전 감지 (v1.2.1) — 관제실 탭은 오래 열려 있으므로, 배포되면 배너로 새로고침 유도
    fetch(`/version.json?t=${Date.now()}`, { cache: 'no-store' })
      .then(r => (r.ok ? r.json() : null)).then(v => v && setLatest(v as VersionInfo)).catch(() => {})
    try {
      const l = await fetchLearner()
      setLearner(l)
      // 최근 120일 — 캘린더/추이/분석 공용. KST 기준 시작일.
      const d = new Date(); d.setDate(d.getDate() - 119)
      const sinceIso = encodeURIComponent(`${d.toLocaleDateString('sv', { timeZone: 'Asia/Seoul' })}T00:00:00+09:00`)
      const [ev, pr, se, rc, bd, rw] = await Promise.all([
        db.select('answer_events', `learner_id=eq.${l.id}&created_at=gte.${sinceIso}&order=created_at.desc&limit=6000`),
        db.select('module_progress', `learner_id=eq.${l.id}`),
        db.select('sessions', `learner_id=eq.${l.id}&order=started_at.desc&limit=120`),
        db.select('review_cards', `learner_id=eq.${l.id}&order=box.desc`),
        db.select('badges', `learner_id=eq.${l.id}&order=earned_at.desc`),
        db.select('parent_rewards', `learner_id=eq.${l.id}&order=granted_at.desc`),
      ])
      setEvents(ev as unknown as AnswerEvent[])
      setProgress(pr as unknown as ModProgress[])
      setSessions(se as unknown as Session[])
      setCards(rc as unknown as ReviewCard[])
      setBadges(bd as unknown as BadgeRow[])
      setRewards(rw as unknown as RewardRow[])
      setUpdatedAt(new Date())
    } catch { /* 오프라인 — 기존 데이터 유지 */ }
    setLoading(false)
  }, [])

  useEffect(() => {
    void refresh()
    timerRef.current = window.setInterval(() => void refresh(), 25000)
    const onVis = () => { if (!document.hidden) void refresh() }
    document.addEventListener('visibilitychange', onVis)
    return () => { if (timerRef.current) clearInterval(timerRef.current); document.removeEventListener('visibilitychange', onVis) }
  }, [refresh])

  const grantReward = useCallback(async (milestone: number) => {
    const lid = learner?.id
    if (!lid) return
    setGranting(milestone)
    try {
      const rows = await db.insert('parent_rewards', { learner_id: lid, milestone_xp: milestone })
      const row = (rows as unknown as RewardRow[])[0]
      if (row) setRewards(prev => [row, ...prev.filter(r => r.milestone_xp !== milestone)])
    } catch { /* 재시도 가능 */ }
    setGranting(null)
  }, [learner?.id])

  // ── 날짜 키 ──
  const todayKey = new Date().toLocaleDateString('sv', { timeZone: 'Asia/Seoul' })
  const yKey = useMemo(() => { const d = new Date(); d.setDate(d.getDate() - 1); return d.toLocaleDateString('sv', { timeZone: 'Asia/Seoul' }) }, [])
  const weekStart = useMemo(() => {
    const d = new Date(`${todayKey}T00:00:00Z`)
    d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7))
    return d.toISOString().slice(0, 10)
  }, [todayKey])

  const M = useMemo(() => computeMetrics(events, progress, sessions, cards, learner, todayKey, yKey, weekStart), [events, progress, sessions, cards, learner, todayKey, yKey, weekStart])

  const lp = levelProgress(learner?.xp ?? 0)

  return (
    <div className="admin">
      <header className="admin-head">
        <h1>👨‍👦 예한이 관제실</h1>
        <button className="refresh-btn" onClick={() => void refresh()} disabled={loading}>
          {loading ? '갱신 중…' : '🔄'}
        </button>
      </header>
      <p className="admin-updated">{updatedAt ? `${updatedAt.toLocaleTimeString('ko-KR')} 기준 · 25초 자동 갱신 · v${APP_VERSION}` : '불러오는 중…'}</p>

      {latest && isNewer(latest.version, APP_VERSION) && (
        <button className="adm-update" onClick={() => location.reload()}>
          🔄 새 버전 v{latest.version} 도착! <b>여기를 눌러 업데이트</b>{latest.notes ? <span className="adm-update-notes"> — {latest.notes}</span> : null}
        </button>
      )}

      <nav className="adm-tabs">
        {TABS.map(t => (
          <button key={t.id} className={`adm-tab ${tab === t.id ? 'on' : ''}`} onClick={() => setTab(t.id)}>
            <span className="adm-tab-i">{t.icon}</span>{t.label}
          </button>
        ))}
      </nav>

      {tab === 'overview' && <OverviewTab M={M} lp={lp} learner={learner} onSeeAll={() => setViewerOpen(true)} />}
      {tab === 'activity' && <ActivityTab events={events} todayKey={todayKey} yKey={yKey} dayAgg={M.dayAgg} onSeeAll={() => setViewerOpen(true)} />}
      {tab === 'review' && <ReviewTab M={M} cards={cards} />}
      {tab === 'analysis' && <AnalysisTab M={M} />}
      {tab === 'progress' && <ProgressTab M={M} />}
      {tab === 'rewards' && <RewardsTab M={M} lp={lp} learner={learner} rewards={rewards} badges={badges} granting={granting} onGrant={grantReward} todayKey={todayKey} />}

      <p className="admin-foot">WordCraft 관제실 v2 · 문항 단위 기록 기반 심층 분석</p>

      {viewerOpen && learner && (
        <ProblemViewer learnerId={learner.id} baseEvents={events} onClose={() => setViewerOpen(false)} />
      )}
    </div>
  )
}

/* ═══════════════ 집계 엔진 ═══════════════ */
interface Metrics {
  todayEvents: AnswerEvent[]
  todaySec: number; todayAcc: number | null; accDelta: number | null
  todayXp: number; weekXp: number; totalXp: number
  streak: number; completedCount: number
  dueToday: number; reviewedToday: boolean
  days7: { dow: string; acc: number | null }[]
  dayAgg: Record<string, { n: number; correct: number; sec: number }>
  weakAreas: { id: string; pct: number; total: number }[]
  weakspots: { text: string; module: string; n: number }[]
  typeBreakdown: { type: string; total: number; correct: number; pct: number }[]
  respAvgMs: number | null; respBuckets: { label: string; n: number }[]
  mastery: { id: string; status: string; acc: number | null; attempts: number; timeSec: number; best: number | null; n: number }[]
  boxDist: number[]; dueBuckets: { overdue: number; today: number; soon: number; later: number }
  reviewAcc: number | null; reviewCount: number; masteredCards: number
  earnedBadges: Set<string>
  worldProgress: { world: number; emoji: string; name: string; mods: { id: string; status: string }[]; done: number; total: number }[]
  todayBalance: { course: number; review: number }; weekBalance: { course: number; review: number }
}

function computeMetrics(
  events: AnswerEvent[], progress: ModProgress[], sessions: Session[], cards: ReviewCard[],
  learner: Learner | null, todayKey: string, yKey: string, weekStart: string,
): Metrics {
  const kst = (iso: string) => new Date(iso).toLocaleString('sv', { timeZone: 'Asia/Seoul' })
  const dayOf = (iso: string) => kstDate(iso)
  const progMap = new Map(progress.map(p => [p.module_id, p]))

  const todayEvents = events.filter(e => kst(e.created_at).startsWith(todayKey))
  const todayCorrect = todayEvents.filter(e => e.is_correct).length
  const todayAcc = todayEvents.length ? Math.round((todayCorrect / todayEvents.length) * 100) : null

  // 오늘 학습시간: 세션 duration 합 vs 활동로그 활성시간(간격 5분 미만) 중 큰 값
  const todaySessionSec = sessions.filter(s => kst(s.started_at).startsWith(todayKey)).reduce((a, s) => a + (s.duration_seconds || 0), 0)
  const daySecFromEvents = (key: string): number => {
    const ts = events.filter(e => dayOf(e.created_at) === key).map(e => new Date(e.created_at).getTime()).sort((a, b) => a - b)
    let sec = 0
    for (let i = 1; i < ts.length; i++) { const g = (ts[i] - ts[i - 1]) / 1000; if (g > 0 && g < 300) sec += g }
    return Math.round(sec)
  }
  const todaySec = Math.max(todaySessionSec, daySecFromEvents(todayKey))

  const yEvents = events.filter(e => kst(e.created_at).startsWith(yKey))
  const yAcc = yEvents.length ? Math.round((yEvents.filter(e => e.is_correct).length / yEvents.length) * 100) : null
  const accDelta = todayAcc !== null && yAcc !== null ? todayAcc - yAcc : null

  // XP (앱 실제 규칙 + 보너스, 완료일 귀속) — 같은 날이면 오늘 XP = 누적 XP
  const bonusOn = (pred: (k: string) => boolean) => progress
    .filter(p => (p.status === 'completed' || p.status === 'mastered') && pred(dayOf(p.completed_at || p.updated_at)))
    .reduce((a, p) => a + moduleBonus(p), 0)
  // 복습 콤보 보너스 (일별 복습 정답 수 → 10장마다 +20, ReviewMine과 1:1)
  const reviewCorrectByDay: Record<string, number> = {}
  for (const e of events) {
    if (e.activity_type !== 'review' || !e.is_correct) continue
    const k = dayOf(e.created_at)
    reviewCorrectByDay[k] = (reviewCorrectByDay[k] || 0) + 1
  }
  const comboOn = (pred: (k: string) => boolean) =>
    Object.entries(reviewCorrectByDay).filter(([k]) => pred(k)).reduce((a, [, n]) => a + comboBonusOf(n), 0)
  const todayXp = todayEvents.reduce((a, e) => a + xpOf(e), 0) + bonusOn(k => k === todayKey) + comboOn(k => k === todayKey)
  const weekXp = events.filter(e => { const k = dayOf(e.created_at); return k >= weekStart && k <= todayKey }).reduce((a, e) => a + xpOf(e), 0)
    + bonusOn(k => k >= weekStart && k <= todayKey) + comboOn(k => k >= weekStart && k <= todayKey)
  // 누적 XP: 앱(learner.xp)과 활동로그 산출 중 큰 값 — 구버전(APK) 동기화 지연에도 계속 정확
  const totalXpData = events.reduce((a, e) => a + xpOf(e), 0)
    + progress.filter(p => p.status === 'completed' || p.status === 'mastered').reduce((a, p) => a + moduleBonus(p), 0)
    + comboOn(() => true)
  const totalXp = Math.max(learner?.xp ?? 0, totalXpData)
  // 학습 밸런스 (모험 vs 복습 XP — 50:50 목표)
  const balanceOf = (pred: (k: string) => boolean) => {
    let course = 0, review = 0
    for (const e of events) {
      const k = dayOf(e.created_at)
      if (!pred(k)) continue
      if (e.activity_type === 'review') review += xpOf(e)
      else course += xpOf(e)
    }
    review += comboOn(pred)
    course += bonusOn(pred)
    return { course, review }
  }
  const todayBalance = balanceOf(k => k === todayKey)
  const weekBalance = balanceOf(k => k >= weekStart && k <= todayKey)

  const completedCount = progress.filter(p => !p.module_id.startsWith('DIAG-') && (p.status === 'completed' || p.status === 'mastered')).length

  // 복습
  const dueToday = cards.filter(c => c.due_date && c.due_date <= todayKey).length
  const reviewedToday = todayEvents.some(e => e.activity_type === 'review')
  const boxDist = [1, 2, 3, 4, 5].map(b => cards.filter(c => c.box === b).length)
  const dueBuckets = {
    overdue: cards.filter(c => c.due_date && c.due_date < todayKey).length,
    today: cards.filter(c => c.due_date === todayKey).length,
    soon: cards.filter(c => c.due_date && c.due_date > todayKey && c.due_date <= addDays(todayKey, 3)).length,
    later: cards.filter(c => c.due_date && c.due_date > addDays(todayKey, 3)).length,
  }
  const reviewEvents = events.filter(e => e.activity_type === 'review')
  const reviewAcc = reviewEvents.length ? Math.round((reviewEvents.filter(e => e.is_correct).length / reviewEvents.length) * 100) : null
  const masteredCards = cards.filter(c => c.box >= 5).length

  // 7일 정답률 추이
  const days7: { dow: string; acc: number | null }[] = []
  for (let i = 6; i >= 0; i--) {
    const dt = new Date(); dt.setDate(dt.getDate() - i)
    const key = dt.toLocaleDateString('sv', { timeZone: 'Asia/Seoul' })
    const evs = events.filter(e => dayOf(e.created_at) === key)
    days7.push({ dow: DOW_KO[new Date(`${key}T00:00:00Z`).getUTCDay()], acc: evs.length ? Math.round((evs.filter(e => e.is_correct).length / evs.length) * 100) : null })
  }

  // 캘린더 히트맵용 일별 집계
  const dayAgg: Record<string, { n: number; correct: number; sec: number }> = {}
  for (const e of events) {
    const k = dayOf(e.created_at)
    if (!dayAgg[k]) dayAgg[k] = { n: 0, correct: 0, sec: 0 }
    dayAgg[k].n++; if (e.is_correct) dayAgg[k].correct++
  }
  for (const k of Object.keys(dayAgg)) dayAgg[k].sec = daySecFromEvents(k)

  // 취약 영역 (개념=모듈 단위, 표본 5+)
  const modAgg: Record<string, { total: number; correct: number }> = {}
  for (const e of events) {
    if (e.activity_type === 'diagnostic') continue
    if (!modAgg[e.module_id]) modAgg[e.module_id] = { total: 0, correct: 0 }
    modAgg[e.module_id].total++; if (e.is_correct) modAgg[e.module_id].correct++
  }
  const weakAreas = Object.entries(modAgg).filter(([, v]) => v.total >= 5)
    .map(([id, v]) => ({ id, pct: Math.round((v.correct / v.total) * 100), total: v.total }))
    .sort((a, b) => a.pct - b.pct)

  // 반복 오답 TOP
  const wrongCount: Record<string, { text: string; module: string; n: number }> = {}
  for (const e of events.filter(e => !e.is_correct)) {
    const k = e.question_id
    if (!wrongCount[k]) wrongCount[k] = { text: e.question_text || e.question_id, module: e.module_id, n: 0 }
    wrongCount[k].n++
  }
  const weakspots = Object.values(wrongCount).sort((a, b) => b.n - a.n).slice(0, 8)

  // 활동 유형별 정답률
  const typeAgg: Record<string, { total: number; correct: number }> = {}
  for (const e of events) {
    if (!typeAgg[e.activity_type]) typeAgg[e.activity_type] = { total: 0, correct: 0 }
    typeAgg[e.activity_type].total++; if (e.is_correct) typeAgg[e.activity_type].correct++
  }
  const typeBreakdown = Object.entries(typeAgg).map(([type, v]) => ({ type, total: v.total, correct: v.correct, pct: Math.round((v.correct / v.total) * 100) }))
    .sort((a, b) => b.total - a.total)

  // 응답시간
  const rts = events.map(e => e.response_ms).filter((x): x is number => x != null && x > 0)
  const respAvgMs = rts.length ? Math.round(rts.reduce((a, b) => a + b, 0) / rts.length) : null
  const respBuckets = [
    { label: '~3초', n: rts.filter(x => x < 3000).length },
    { label: '3~7초', n: rts.filter(x => x >= 3000 && x < 7000).length },
    { label: '7~15초', n: rts.filter(x => x >= 7000 && x < 15000).length },
    { label: '15초+', n: rts.filter(x => x >= 15000).length },
  ]

  // 모듈 마스터리
  const mastery = MODULE_ORDER.map(id => {
    const p = progMap.get(id)
    const evs = events.filter(e => e.module_id === id && e.activity_type !== 'diagnostic')
    const acc = evs.length ? Math.round((evs.filter(e => e.is_correct).length / evs.length) * 100) : null
    return { id, status: p?.status || 'locked', acc, attempts: p?.attempts || 0, timeSec: p?.total_time_seconds || 0, best: p?.best_score ?? null, n: evs.length }
  })

  // 뱃지 (데이터에서 계산 — badges 테이블 비어도 정확. lib/badges.ts 판정과 1:1)
  const earnedBadges = new Set<string>()
  if (completedCount >= 1) earnedBadges.add('first_module')
  for (const w of WORLDS) {
    if (w.modules.length && w.modules.every(id => { const p = progMap.get(id); return p && (p.status === 'completed' || p.status === 'mastered') })) earnedBadges.add(`world${w.world}_clear`)
  }
  // 퍼펙트: 진단(DIAG-*) 제외 — 진단 100%가 퍼펙트로 오인되던 버그 봉합 (v1.2.0)
  if (progress.some(p => !p.module_id.startsWith('DIAG-') && (p.best_score ?? 0) >= 100)) earnedBadges.add('perfect_module')
  const diagDone = progress.filter(p => p.module_id.startsWith('DIAG-') && (p.status === 'completed' || p.status === 'mastered')).length
  if (diagDone >= 4) earnedBadges.add('diag_all')
  const streak = learner?.streak_days ?? 0
  if (streak >= 3) earnedBadges.add('streak_3')
  if (streak >= 7) earnedBadges.add('streak_7')
  if (streak >= 14) earnedBadges.add('streak_14')
  const bossWins = new Set(events.filter(e => e.activity_type === 'boss' && e.is_correct).map(e => e.module_id))
  if (bossWins.size >= 5) earnedBadges.add('boss_slayer')
  const reviewCorrectTotal = reviewEvents.filter(e => e.is_correct).length
  if (reviewCorrectTotal >= 10) earnedBadges.add('review_10')
  if (reviewCorrectTotal >= 50) earnedBadges.add('review_50')
  if (reviewCorrectTotal >= 200) earnedBadges.add('review_200')
  // 황금 밸런스: 모험·복습 둘 다 한 날 7일 (앱 balanceDays와 동일 개념)
  const dayKinds: Record<string, { course: boolean; review: boolean }> = {}
  for (const e of events) {
    if (e.activity_type === 'diagnostic') continue
    const k = dayOf(e.created_at)
    if (!dayKinds[k]) dayKinds[k] = { course: false, review: false }
    if (e.activity_type === 'review') dayKinds[k].review = true
    else dayKinds[k].course = true
  }
  if (Object.values(dayKinds).filter(v => v.course && v.review).length >= 7) earnedBadges.add('balance_7')

  // 월드 진행
  const worldProgress = WORLDS.filter(w => w.modules.length).map(w => {
    const mods = w.modules.map(id => ({ id, status: progMap.get(id)?.status || 'locked' }))
    const done = mods.filter(m => m.status === 'completed' || m.status === 'mastered').length
    return { world: w.world, emoji: w.emoji, name: w.name_ko, mods, done, total: w.modules.length }
  })

  return {
    todayEvents, todaySec, todayAcc, accDelta, todayXp, weekXp, totalXp, streak, completedCount,
    dueToday, reviewedToday, days7, dayAgg, weakAreas, weakspots, typeBreakdown, respAvgMs, respBuckets,
    mastery, boxDist, dueBuckets, reviewAcc, reviewCount: reviewEvents.length, masteredCards, earnedBadges, worldProgress,
    todayBalance, weekBalance,
  }
}

function addDays(key: string, n: number): string {
  const d = new Date(`${key}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10)
}

/* ═══════════════ 탭: 개요 ═══════════════ */
function OverviewTab(props: { M: Metrics; lp: { level: number; cur: number; need: number }; learner: Learner | null; onSeeAll: () => void }) {
  const { M, lp } = props
  return (
    <div className="adm-screen">
      <div className="adm-stat-grid">
        <div className="adm-stat">
          <span className="k">⏱ 오늘 학습</span>
          <span className="v">{Math.floor(M.todaySec / 60)}분</span>
          {M.todaySec >= GOAL_SEC ? <span className="d up">목표 15분 달성 ✓</span> : <span className="d flat">{`목표 15분 · 지금 ${Math.floor(M.todaySec / 60)}분`}</span>}
        </div>
        <div className="adm-stat">
          <span className="k">🎯 오늘 정답률</span>
          <span className="v">{M.todayAcc === null ? '—' : `${M.todayAcc}%`}</span>
          {M.accDelta !== null ? <span className={`d ${M.accDelta >= 0 ? 'up' : 'down'}`}>{`어제 ${M.accDelta >= 0 ? '+' : ''}${M.accDelta}%p`}</span> : <span className="d flat">어제 기록 없음</span>}
        </div>
        <div className="adm-stat hl">
          <span className="k">⚡ 오늘 XP</span>
          <span className="v">+{M.todayXp}</span>
          <span className="d flat">{`누적 ${M.totalXp.toLocaleString()} · LV.${lp.level}`}</span>
        </div>
        <div className="adm-stat">
          <span className="k">⛏️ 복습 카드</span>
          <span className="v">{M.dueToday}장</span>
          {M.dueToday === 0 ? (M.reviewedToday ? <span className="d up">오늘 완료 ✓</span> : <span className="d flat">예정 없음</span>) : <span className="d flat">{`${M.dueToday}장 남음`}</span>}
        </div>
      </div>

      <div className="stat-row">
        <div className="stat-tile"><b>⭐ {M.totalXp.toLocaleString()}</b><span>누적 XP</span></div>
        <div className="stat-tile"><b>{M.completedCount}/{MODULE_ORDER.length}</b><span>모듈 클리어</span></div>
        <div className="stat-tile" title="출석 기준: 하루 15분 이상 학습 (2026-07-16부터)"><b>🔥 {M.streak}</b><span>연속 출석 (15분↑)</span></div>
      </div>

      <div className="adm-panel adm-chart">
        <h4>정답률 추이 · 최근 7일</h4>
        <TrendChart days={M.days7} />
      </div>

      <div className="adm-panel">
        <div className="adm-panel-head">
          <h4>최근 활동</h4>
          <button className="adm-view-btn" onClick={props.onSeeAll}>전체 보기 ▸</button>
        </div>
        {M.todayEvents.length === 0 ? <p className="admin-empty">오늘 기록이 아직 없어요.</p> : (
          <div className="adm-feed">
            {M.todayEvents.slice(0, 12).map(e => (
              <div key={e.id} className="adm-feed-wrap">
                <div className="adm-feed-row">
                  <time>{new Date(e.created_at).toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul', hour12: false, hour: '2-digit', minute: '2-digit' })}</time>
                  <span className="what"><em>[{feedTag(e)}]</em> {e.question_text || e.question_id}</span>
                  {e.is_correct ? <span className="adm-pill o">정답</span> : <span className="adm-pill x">오답</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

/* ═══════════════ 탭: 활동 (캘린더 + 필터 피드) ═══════════════ */
type FeedFilter = 'all' | 'wrong' | 'review' | 'boss' | 'game' | 'speak'
const FILTERS: { id: FeedFilter; label: string }[] = [
  { id: 'all', label: '전체' }, { id: 'wrong', label: '오답만' }, { id: 'review', label: '복습' },
  { id: 'boss', label: '보스전' }, { id: 'game', label: '게임' }, { id: 'speak', label: '말하기' },
]
function matchFilter(e: AnswerEvent, f: FeedFilter): boolean {
  if (f === 'all') return true
  if (f === 'wrong') return !e.is_correct
  if (f === 'review') return e.activity_type === 'review'
  if (f === 'boss') return e.activity_type === 'boss'
  if (f === 'speak') return e.activity_type === 'speak'
  if (f === 'game') return e.activity_type.startsWith('game_')
  return true
}

function ActivityTab(props: { events: AnswerEvent[]; todayKey: string; yKey: string; dayAgg: Record<string, { n: number; correct: number; sec: number }>; onSeeAll: () => void }) {
  const { events, todayKey, yKey, dayAgg } = props
  const [filter, setFilter] = useState<FeedFilter>('all')
  const [selDay, setSelDay] = useState<string>(todayKey)
  const [month, setMonth] = useState<string>(() => todayKey.slice(0, 7)) // 'YYYY-MM'

  const dayEvents = useMemo(() =>
    events.filter(e => kstDate(e.created_at) === selDay).slice().sort((a, b) => a.created_at < b.created_at ? -1 : 1)
  , [events, selDay])
  const filtered = dayEvents.filter(e => matchFilter(e, filter))
  const dayStat = dayAgg[selDay]

  return (
    <div className="adm-screen">
      <div className="adm-panel">
        <h4>학습 캘린더 <span className="adm-sub">색이 진할수록 그날 많이 공부한 거예요</span></h4>
        <Calendar month={month} onMonth={setMonth} dayAgg={dayAgg} selected={selDay} onSelect={setSelDay} todayKey={todayKey} />
        <div className="cal-legend">
          <span>적음</span>
          <i className="cal-sw l0" /><i className="cal-sw l1" /><i className="cal-sw l2" /><i className="cal-sw l3" /><i className="cal-sw l4" />
          <span>많음</span>
        </div>
      </div>

      <div className="adm-panel">
        <div className="adm-panel-head">
          <h4>{dateLabel(selDay, todayKey, yKey)}의 활동</h4>
          <button className="adm-view-btn" onClick={props.onSeeAll}>문제 다시보기 ▸</button>
        </div>
        {dayStat ? (
          <div className="day-summary">
            <span><b>{dayStat.n}</b>문항</span>
            <span><b>{dayStat.n ? Math.round((dayStat.correct / dayStat.n) * 100) : 0}%</b> 정답</span>
            <span><b>{Math.floor(dayStat.sec / 60)}</b>분</span>
          </div>
        ) : <p className="admin-empty">이 날은 학습 기록이 없어요.</p>}

        {dayStat && (
          <>
            <div className="adm-filter">
              {FILTERS.map(f => (
                <button key={f.id} className={`adm-chip ${filter === f.id ? 'on' : ''}`} onClick={() => setFilter(f.id)}>{f.label}</button>
              ))}
            </div>
            {filtered.length === 0 ? <p className="admin-empty">해당하는 기록이 없어요.</p> : (
              <div className="adm-feed">
                {filtered.map(e => {
                  const hasMore = (!e.is_correct && e.given_answer) || e.response_ms != null
                  const row = (
                    <div className="adm-feed-row">
                      <time>{new Date(e.created_at).toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul', hour12: false, hour: '2-digit', minute: '2-digit' })}</time>
                      <span className="what"><em>[{feedTag(e)}]</em> {e.question_text || e.question_id}</span>
                      {e.is_correct ? <span className="adm-pill o">정답</span> : <span className="adm-pill x">오답</span>}
                    </div>
                  )
                  return hasMore ? (
                    <details key={e.id}>
                      <summary>{row}</summary>
                      <div className="adm-feed-more">
                        {!e.is_correct && e.given_answer && <>답: "{e.given_answer}" → 정답: "{e.correct_answer}" · </>}
                        {e.response_ms != null && <>{(e.response_ms / 1000).toFixed(1)}초</>}
                      </div>
                    </details>
                  ) : <div key={e.id} className="adm-feed-wrap">{row}</div>
                })}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

function Calendar(props: { month: string; onMonth: (m: string) => void; dayAgg: Record<string, { n: number; correct: number; sec: number }>; selected: string; onSelect: (k: string) => void; todayKey: string }) {
  const { month, dayAgg, selected, todayKey } = props
  const year = parseInt(month.slice(0, 4), 10)
  const mon = parseInt(month.slice(5, 7), 10) // 1-12
  const first = new Date(Date.UTC(year, mon - 1, 1))
  const startDow = first.getUTCDay()
  const daysInMonth = new Date(Date.UTC(year, mon, 0)).getUTCDate()
  const cells: (string | null)[] = []
  for (let i = 0; i < startDow; i++) cells.push(null)
  for (let d = 1; d <= daysInMonth; d++) cells.push(`${month}-${String(d).padStart(2, '0')}`)
  const level = (n: number) => n === 0 ? 0 : n < 10 ? 1 : n < 25 ? 2 : n < 50 ? 3 : 4
  const shift = (delta: number) => {
    const d = new Date(Date.UTC(year, mon - 1 + delta, 1))
    props.onMonth(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`)
  }
  return (
    <div className="cal">
      <div className="cal-head">
        <button className="cal-nav" onClick={() => shift(-1)}>◂</button>
        <b>{year}년 {mon}월</b>
        <button className="cal-nav" onClick={() => shift(1)} disabled={month >= todayKey.slice(0, 7)}>▸</button>
      </div>
      <div className="cal-grid">
        {DOW_KO.map(d => <span key={d} className="cal-dow">{d}</span>)}
        {cells.map((k, i) => {
          if (!k) return <span key={`b${i}`} className="cal-cell empty" />
          const agg = dayAgg[k]
          const lv = agg ? level(agg.n) : 0
          const isToday = k === todayKey
          const isSel = k === selected
          const future = k > todayKey
          return (
            <button key={k} className={`cal-cell l${lv} ${isSel ? 'sel' : ''} ${isToday ? 'today' : ''} ${future ? 'future' : ''}`}
              disabled={future} onClick={() => props.onSelect(k)}
              title={agg ? `${k}: ${agg.n}문항 · ${agg.n ? Math.round((agg.correct / agg.n) * 100) : 0}%` : k}>
              {parseInt(k.slice(8), 10)}
            </button>
          )
        })}
      </div>
    </div>
  )
}

/* ═══════════════ 탭: 복습 (SRS) ═══════════════ */
function ReviewTab(props: { M: Metrics; cards: ReviewCard[] }) {
  const { M, cards } = props
  const total = cards.length
  return (
    <div className="adm-screen">
      <div className="adm-stat-grid">
        <div className="adm-stat"><span className="k">🃏 전체 카드</span><span className="v">{total}장</span><span className="d flat">라이트너 5칸</span></div>
        <div className="adm-stat"><span className="k">💎 장기기억</span><span className="v">{M.masteredCards}장</span><span className="d flat">박스5 도달</span></div>
        <div className="adm-stat"><span className="k">🎯 복습 정답률</span><span className="v">{M.reviewAcc === null ? '—' : `${M.reviewAcc}%`}</span><span className="d flat">누적 {M.reviewCount}회</span></div>
        <div className="adm-stat"><span className="k">📅 오늘 예정</span><span className="v">{M.dueToday}장</span>{M.reviewedToday ? <span className="d up">완료 ✓</span> : <span className="d flat">대기</span>}</div>
      </div>

      <div className="adm-panel">
        <h4>학습 밸런스 <span className="adm-sub">목표 = 모험:복습 50:50 (복습 카드 +{XP.reviewCorrect} XP · {XP.reviewComboEvery}장 콤보 +{XP.reviewCombo})</span></h4>
        <BalanceRow label="오늘" b={M.todayBalance} />
        <BalanceRow label="이번 주" b={M.weekBalance} />
        <p className="admin-note">복습 비중이 낮으면 예한이 앱 월드맵의 '오늘의 밸런스' 미터가 복습을 권해요. 오답 문제는 자동으로 복습 카드로 리스폰됩니다.</p>
      </div>

      {total === 0 ? (
        <div className="adm-panel">
          <h4>복습 광산 (간격 반복)</h4>
          <p className="admin-empty">아직 복습 카드가 없어요. 모듈을 클리어하면 다음 날부터 복습 카드가 광산에 리젠돼요 — 라이트너 5칸(오늘·2일·4일·7일·14일) 간격으로 장기기억까지 굳혀줍니다.</p>
        </div>
      ) : (
        <>
          <div className="adm-panel">
            <h4>박스 분포 (많이 맞힐수록 오른쪽 다이아 층으로)</h4>
            <div className="adm-dist">
              {M.boxDist.map((n, i) => n > 0 ? <i key={i} style={{ width: `${(n / total) * 100}%`, background: BOX_COLORS[i] }} /> : null)}
            </div>
            <div className="rv-boxrows">
              {M.boxDist.map((n, i) => (
                <div key={i} className="rv-boxrow">
                  <span className="sq" style={{ background: BOX_COLORS[i] }} />
                  <span className="rv-boxlabel">{BOX_LABELS[i]}</span>
                  <span className="rv-boxn">{n}장</span>
                  <span className="rv-boxbar"><i style={{ width: `${total ? (n / total) * 100 : 0}%`, background: BOX_COLORS[i] }} /></span>
                </div>
              ))}
            </div>
          </div>

          <div className="adm-panel">
            <h4>복습 일정</h4>
            <div className="rv-due">
              <div className="rv-due-cell overdue"><b>{M.dueBuckets.overdue}</b><span>밀림</span></div>
              <div className="rv-due-cell today"><b>{M.dueBuckets.today}</b><span>오늘</span></div>
              <div className="rv-due-cell soon"><b>{M.dueBuckets.soon}</b><span>3일 내</span></div>
              <div className="rv-due-cell later"><b>{M.dueBuckets.later}</b><span>이후</span></div>
            </div>
          </div>

          <div className="adm-panel">
            <h4>카드별 성취 (박스 높은 순)</h4>
            <div className="rv-cards">
              {cards.slice(0, 40).map((c, i) => (
                <div key={i} className="rv-card">
                  <span className="rv-card-box" style={{ background: BOX_COLORS[(c.box || 1) - 1] }}>{c.box}</span>
                  <span className="rv-card-front">{c.card_front || c.card_id}</span>
                  <span className="rv-card-meta">{c.review_count}회{c.last_result === false ? ' · 최근 오답' : c.last_result === true ? ' · 최근 정답' : ''}</span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  )
}

/** 모험 vs 복습 XP 밸런스 바 (50:50 목표선 포함) */
function BalanceRow(props: { label: string; b: { course: number; review: number } }) {
  const { course, review } = props.b
  const total = course + review
  const pct = total ? Math.round((review / total) * 100) : 0
  return (
    <div className="adm-balance-row">
      <span className="lbl">{props.label}</span>
      {total === 0 ? <span className="adm-balance-none">기록 없음</span> : (
        <>
          <span className="adm-balance-bar">
            <i className="c" style={{ width: `${100 - pct}%` }} />
            <i className="r" style={{ width: `${pct}%` }} />
            <em />
          </span>
          <span className="nums">모험 {course} : 복습 {review} ({pct}%)</span>
        </>
      )}
    </div>
  )
}

/* ═══════════════ 탭: 심층 분석 ═══════════════ */
function AnalysisTab(props: { M: Metrics }) {
  const { M } = props
  return (
    <div className="adm-screen">
      <div className="adm-panel">
        <h4>취약 영역 (개념별 정답률 낮은 순)</h4>
        {M.weakAreas.length === 0 ? <p className="admin-empty">표본이 아직 부족해요 (개념별 5문항 이상).</p> : (
          <div className="adm-weak">
            {M.weakAreas.slice(0, 8).map(w => {
              const col = w.pct < 70 ? 'var(--redstone)' : w.pct < 85 ? 'var(--gold)' : 'var(--success)'
              return (
                <div key={w.id} className="adm-weak-row">
                  <span className="nm">{MODULE_NAMES[w.id] || w.id}</span>
                  <span className="bar"><i style={{ width: `${w.pct}%`, background: col }} /></span>
                  <span className="pc" style={{ color: col }}>{w.pct}%</span>
                </div>
              )
            })}
          </div>
        )}
      </div>

      <div className="adm-panel">
        <h4>활동 유형별 정답률</h4>
        {M.typeBreakdown.length === 0 ? <p className="admin-empty">기록이 없어요.</p> : (
          <div className="adm-weak">
            {M.typeBreakdown.map(t => {
              const col = t.pct < 70 ? 'var(--redstone)' : t.pct < 85 ? 'var(--gold)' : 'var(--success)'
              return (
                <div key={t.type} className="adm-weak-row">
                  <span className="nm">{typeLabel(t.type)} <em className="ana-n">{t.correct}/{t.total}</em></span>
                  <span className="bar"><i style={{ width: `${t.pct}%`, background: col }} /></span>
                  <span className="pc" style={{ color: col }}>{t.pct}%</span>
                </div>
              )
            })}
          </div>
        )}
      </div>

      <div className="adm-panel">
        <h4>반응 속도 <span className="adm-sub">평균 {M.respAvgMs === null ? '—' : `${(M.respAvgMs / 1000).toFixed(1)}초`}</span></h4>
        <div className="ana-resp">
          {M.respBuckets.map(b => {
            const max = Math.max(1, ...M.respBuckets.map(x => x.n))
            return (
              <div key={b.label} className="ana-resp-col">
                <div className="ana-resp-bar"><i style={{ height: `${(b.n / max) * 100}%` }} /></div>
                <span className="ana-resp-n">{b.n}</span>
                <span className="ana-resp-l">{b.label}</span>
              </div>
            )
          })}
        </div>
      </div>

      <div className="adm-panel">
        <h4>자주 틀리는 문제 TOP</h4>
        {M.weakspots.length === 0 ? <p className="admin-empty">반복 오답이 없어요 — 좋은 신호!</p> : (
          <ul className="weak-list">
            {M.weakspots.map((w, i) => (
              <li key={i}><span className="weak-n">{w.n}회</span> <b>[{MODULE_NAMES[w.module] || w.module}]</b> {w.text}</li>
            ))}
          </ul>
        )}
      </div>

      <div className="adm-panel">
        <h4>모듈별 마스터리</h4>
        <div className="mastery">
          {M.mastery.map(m => {
            const cls = m.status === 'completed' || m.status === 'mastered' ? 'done' : m.status === 'in_progress' ? 'doing' : m.status === 'available' ? 'open' : 'locked'
            const col = m.acc === null ? 'var(--text-2)' : m.acc < 70 ? 'var(--redstone)' : m.acc < 85 ? 'var(--gold)' : 'var(--success)'
            return (
              <div key={m.id} className={`mastery-row ${cls}`}>
                <span className="mastery-id">{m.id}</span>
                <span className="mastery-nm">{MODULE_NAMES[m.id] || m.id}</span>
                <span className="mastery-acc" style={{ color: col }}>{m.acc === null ? '—' : `${m.acc}%`}</span>
                <span className="mastery-meta">{m.n > 0 ? `${m.n}문항 · ${Math.round(m.timeSec / 60)}분` : '미시작'}</span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

/* ═══════════════ 탭: 진행 + 로드맵 ═══════════════ */
function ProgressTab(props: { M: Metrics }) {
  const { M } = props
  const totalDone = M.completedCount
  const totalMods = MODULE_ORDER.length
  const pct = Math.round((totalDone / totalMods) * 100)
  return (
    <div className="adm-screen">
      <div className="adm-panel">
        <h4>전체 진행률</h4>
        <div className="prog-hero">
          <div className="prog-ring" style={{ background: `conic-gradient(var(--diamond) ${pct * 3.6}deg, var(--wc-surface-border) 0)` }}>
            <span>{pct}%</span>
          </div>
          <div className="prog-hero-txt">
            <b>{totalDone} / {totalMods} 모듈</b>
            <span>클리어한 학습 모듈</span>
          </div>
        </div>
      </div>

      <div className="adm-panel">
        <h4>월드 지도 (현재 커리큘럼)</h4>
        {M.worldProgress.map(w => (
          <div key={w.world} className="road-world">
            <div className="road-world-head">
              <b>{w.emoji} 월드 {w.world} · {w.name}</b>
              <span className="road-count">{w.done}/{w.total}</span>
            </div>
            <div className="road-mods">
              {w.mods.map(m => {
                const cls = m.status === 'completed' || m.status === 'mastered' ? 'done' : m.status === 'in_progress' ? 'doing' : m.status === 'available' ? 'open' : 'locked'
                return <span key={m.id} className={`road-mod ${cls}`}>{m.id}<em>{MODULE_NAMES[m.id] || ''}</em></span>
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="adm-panel">
        <h4>🚀 앞으로 열릴 월드 <span className="adm-sub">중학 대비 심화 과정 (콘텐츠 준비 중)</span></h4>
        <div className="road-future">
          {FUTURE_WORLDS.map(w => (
            <div key={w.world} className="road-fut">
              <span className="road-fut-em">{w.emoji}</span>
              <div className="road-fut-txt">
                <b>월드 {w.world} · {w.name}</b>
                <span>{w.desc}</span>
              </div>
              <span className="road-fut-lock">예정</span>
            </div>
          ))}
        </div>
        <p className="admin-note">각 월드는 콘텐츠(JSON)만 추가하면 자동으로 열리는 구조예요. 예한이 진도에 맞춰 난이도를 이어서 확장할 수 있습니다.</p>
      </div>
    </div>
  )
}

/* ═══════════════ 탭: 성취·보상 ═══════════════ */
function RewardsTab(props: {
  M: Metrics; lp: { level: number; cur: number; need: number }; learner: Learner | null
  rewards: RewardRow[]; badges: BadgeRow[]; granting: number | null; onGrant: (m: number) => void; todayKey: string
}) {
  const { M, lp, rewards, badges } = props
  const totalXp = M.totalXp
  const passedMiles: number[] = []
  for (let m = MILESTONE; m <= totalXp; m += MILESTONE) passedMiles.push(m)
  const nextMile = (Math.floor(totalXp / MILESTONE) + 1) * MILESTONE
  const mileProg = Math.round(((totalXp % MILESTONE) / MILESTONE) * 100)
  const grantedMap = new Map(rewards.map(r => [r.milestone_xp, r]))
  // 뱃지: 데이터 계산(earnedBadges) ∪ badges 테이블
  const earnedAt = new Map(badges.map(b => [b.badge_id, b.earned_at]))
  const earnedIds = new Set<string>([...M.earnedBadges, ...badges.map(b => b.badge_id)])

  return (
    <div className="adm-screen">
      <div className="adm-reward-hero">
        <div className="adm-reward-total">
          <span className="k">누적 총 XP</span>
          <span className="v">{totalXp.toLocaleString()}</span>
          <span className="lv">LV.{lp.level} · {levelTitle(lp.level)}</span>
        </div>
        <div className="adm-reward-mini">
          <div className="m"><b>+{M.todayXp}</b><span>오늘 XP</span></div>
          <div className="m"><b>+{M.weekXp}</b><span>이번 주 XP</span></div>
        </div>
      </div>

      <div className="adm-panel">
        <h4>보상 마일스톤 · 1,000 XP마다</h4>
        <div className="adm-mile-next">
          <span>다음 보상까지</span>
          <b>{(nextMile - totalXp).toLocaleString()} XP</b>
          <span className="tgt">→ {nextMile.toLocaleString()}</span>
        </div>
        <div className="adm-mile-bar"><i style={{ width: `${mileProg}%` }} /></div>
        {passedMiles.length === 0 ? (
          <p className="admin-note">아직 첫 보상 마일스톤(1,000 XP) 전이에요.</p>
        ) : (
          <div className="adm-mile-list">
            {passedMiles.slice().reverse().map(m => {
              const r = grantedMap.get(m)
              return (
                <div key={m} className={`adm-mile-row ${r ? 'done' : ''}`}>
                  <span className="mx">🏅 {m.toLocaleString()} XP</span>
                  {r ? <span className="mg">지급 완료 · {new Date(r.granted_at).toLocaleDateString('ko-KR', { timeZone: 'Asia/Seoul', month: 'short', day: 'numeric' })}</span>
                    : <button className="mgbtn" disabled={props.granting === m} onClick={() => props.onGrant(m)}>{props.granting === m ? '지급 중…' : '보상 지급함 ✓'}</button>}
                </div>
              )
            })}
          </div>
        )}
      </div>

      <div className="adm-panel">
        <h4>뱃지 도감 <span className="adm-sub">{earnedIds.size}/{Object.keys(BADGE_DEFS).length}</span></h4>
        <div className="rw-badges">
          {Object.entries(BADGE_DEFS).map(([id, b]) => {
            const got = earnedIds.has(id)
            const when = earnedAt.get(id)
            return (
              <div key={id} className={`rw-badge ${got ? 'got' : 'off'}`}>
                <span className="rw-badge-em">{got ? b.emoji : '🔒'}</span>
                <b>{b.name}</b>
                <span className="rw-badge-desc">{got ? b.desc : `조건: ${b.hint}`}</span>
                {got && when && <span className="rw-badge-when">{new Date(when).toLocaleDateString('ko-KR', { timeZone: 'Asia/Seoul', month: 'short', day: 'numeric' })}</span>}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

/* ═══════════════ 문제 다시보기 (오답 필터 추가) ═══════════════ */
function ProblemViewer(props: { learnerId: string; baseEvents: AnswerEvent[]; onClose: () => void }) {
  const [events, setEvents] = useState<AnswerEvent[]>(props.baseEvents)
  const [loading, setLoading] = useState(true)
  const [dateKey, setDateKey] = useState('')
  const [idx, setIdx] = useState(0)
  const [wrongOnly, setWrongOnly] = useState(false)

  const todayKey = new Date().toLocaleDateString('sv', { timeZone: 'Asia/Seoul' })
  const yKey = (() => { const d = new Date(); d.setDate(d.getDate() - 1); return d.toLocaleDateString('sv', { timeZone: 'Asia/Seoul' }) })()

  useEffect(() => {
    let alive = true
    const d30 = new Date(); d30.setDate(d30.getDate() - 89)
    const since = encodeURIComponent(`${d30.toLocaleDateString('sv', { timeZone: 'Asia/Seoul' })}T00:00:00+09:00`)
    db.select('answer_events', `learner_id=eq.${props.learnerId}&created_at=gte.${since}&order=created_at.asc&limit=6000`)
      .then(rows => { if (alive && rows.length) setEvents(rows as unknown as AnswerEvent[]) })
      .catch(() => { /* baseEvents 유지 */ })
      .finally(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [props.learnerId])

  const availDates = useMemo(() => {
    const set = new Set<string>()
    for (const e of events) set.add(kstDate(e.created_at))
    return Array.from(set).sort().reverse()
  }, [events])

  useEffect(() => {
    if (dateKey || !availDates.length) return
    setDateKey(availDates.includes(todayKey) ? todayKey : availDates[0])
  }, [availDates, dateKey, todayKey])

  const problems = useMemo(() =>
    events.filter(e => kstDate(e.created_at) === dateKey && (!wrongOnly || !e.is_correct)).slice().sort((a, b) => a.created_at < b.created_at ? -1 : 1)
  , [events, dateKey, wrongOnly])

  useEffect(() => { setIdx(0) }, [dateKey, wrongOnly])

  const kb = useRef({ len: 0, onClose: props.onClose })
  kb.current = { len: problems.length, onClose: props.onClose }
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') kb.current.onClose()
      else if (e.key === 'ArrowLeft') setIdx(i => Math.max(0, i - 1))
      else if (e.key === 'ArrowRight') setIdx(i => Math.min(kb.current.len - 1, i + 1))
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const cur = problems[idx]
  return (
    <div className="pv-overlay" role="dialog" aria-modal="true" onClick={props.onClose}>
      <div className="pv-sheet" onClick={(e: { stopPropagation(): void }) => e.stopPropagation()}>
        <div className="pv-head">
          <span className="pv-title">📄 문제 다시보기</span>
          {availDates.length > 0 && (
            <select className="pv-date" value={dateKey} onChange={(e: { target: { value: string } }) => setDateKey(e.target.value)}>
              {availDates.map(d => <option key={d} value={d}>{dateLabel(d, todayKey, yKey)}</option>)}
            </select>
          )}
          <button className={`pv-wrong ${wrongOnly ? 'on' : ''}`} onClick={() => setWrongOnly(v => !v)}>{wrongOnly ? '오답만 ✓' : '오답만'}</button>
          <button className="pv-close" onClick={props.onClose} aria-label="닫기">✕</button>
        </div>

        {loading && !problems.length ? (
          <div className="pv-empty">불러오는 중…</div>
        ) : !cur ? (
          <div className="pv-empty">{wrongOnly ? '이 날짜엔 오답이 없어요 — 굿!' : '이 날짜에는 푼 문제가 없어요.'}</div>
        ) : (
          <>
            <div className="pv-body">
              <div className="pv-meta">
                <time>{kstClock(cur.created_at)}</time>
                <span className="pv-mod">[{feedTag(cur)}]</span>
                {cur.is_correct ? <span className="pv-badge o">정답 ✓</span> : <span className="pv-badge x">오답 ✕</span>}
              </div>
              <div className={`pv-q ${cur.is_correct ? '' : 'wrong'}`}>{cur.question_text || cur.question_id}</div>
              <div className="pv-ans-row">
                <div className={`pv-ans ${cur.is_correct ? 'ok' : 'no'}`}>
                  <span className="lbl">예한이 답</span>
                  <b>{cur.given_answer ?? '—'}</b>
                </div>
                {!cur.is_correct && (
                  <div className="pv-ans ok">
                    <span className="lbl">정답</span>
                    <b>{cur.correct_answer ?? '—'}</b>
                  </div>
                )}
              </div>
              {cur.response_ms != null && <p className="pv-rt">걸린 시간 {(cur.response_ms / 1000).toFixed(1)}초</p>}
            </div>

            <div className="pv-dots">
              {problems.map((p, i) => (
                <button key={p.id} className={`pv-dot ${p.is_correct ? 'o' : 'x'} ${i === idx ? 'cur' : ''}`}
                  onClick={() => setIdx(i)} aria-label={`${i + 1}번 ${p.is_correct ? '정답' : '오답'}`} />
              ))}
            </div>
            <div className="pv-nav">
              <button className="pv-navbtn" disabled={idx <= 0} onClick={() => setIdx(i => Math.max(0, i - 1))}>◂ 이전</button>
              <span className="pv-count">{idx + 1} / {problems.length}</span>
              <button className="pv-navbtn" disabled={idx >= problems.length - 1} onClick={() => setIdx(i => Math.min(problems.length - 1, i + 1))}>다음 ▸</button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

/* ═══════════════ 순수 SVG 추이 차트 ═══════════════ */
function TrendChart(props: { days: { dow: string; acc: number | null }[] }) {
  const pts = props.days.map((d, i) => d.acc === null ? null : { x: 34 + i * 44, y: Math.min(114, 18 + (100 - d.acc) * 1.6), acc: d.acc })
  const segs: string[] = []
  let cur: string[] = []
  for (const p of pts) { if (p) cur.push(`${p.x},${p.y}`); else { if (cur.length > 1) segs.push(cur.join(' ')); cur = [] } }
  if (cur.length > 1) segs.push(cur.join(' '))
  const today = pts[6]
  return (
    <svg viewBox="0 0 320 130" role="img" aria-label="최근 7일 정답률 추이">
      <line x1="8" y1="18" x2="312" y2="18" style={{ stroke: 'var(--wc-surface-border)', strokeWidth: 1 }} strokeDasharray="3 3" />
      <line x1="8" y1="58" x2="312" y2="58" style={{ stroke: 'var(--wc-surface-border)', strokeWidth: 1 }} strokeDasharray="3 3" />
      <line x1="8" y1="98" x2="312" y2="98" style={{ stroke: 'var(--wc-surface-border)', strokeWidth: 1 }} strokeDasharray="3 3" />
      <text x="8" y="14" style={{ fill: 'var(--text-2)', fontSize: 9 }}>100%</text>
      <text x="8" y="54" style={{ fill: 'var(--text-2)', fontSize: 9 }}>75%</text>
      <text x="8" y="94" style={{ fill: 'var(--text-2)', fontSize: 9 }}>50%</text>
      {segs.map((s, i) => <polyline key={i} points={s} style={{ fill: 'none', stroke: 'var(--diamond)', strokeWidth: 2 }} />)}
      {pts.map((p, i) => p && i < 6 ? <circle key={i} cx={p.x} cy={p.y} r={3.5} style={{ fill: 'var(--diamond)' }} /> : null)}
      {today && <>
        <circle cx={today.x} cy={today.y} r={5} style={{ fill: 'var(--gold)' }} />
        <text x={today.x} y={today.y - 13} textAnchor="middle" style={{ fill: 'var(--gold)', fontSize: 10, fontWeight: 700 }}>{today.acc}%</text>
      </>}
      {props.days.map((d, i) => <text key={i} x={34 + i * 44} y="122" textAnchor="middle" style={{ fill: 'var(--text-2)', fontSize: 9 }}>{d.dow}</text>)}
    </svg>
  )
}

/* ═══════════════ 헬퍼 ═══════════════ */
function feedTag(e: AnswerEvent): string {
  if (e.activity_type === 'review') return '복습'
  if (e.activity_type === 'game_listen_choice') return '듣기'
  if (e.activity_type === 'diagnostic') return '진단'
  return MODULE_NAMES[e.module_id] || typeLabel(e.activity_type)
}
function typeLabel(t: string): string {
  const map: Record<string, string> = {
    quiz: '퀴즈', boss: '보스전', diagnostic: '진단', speak: '말하기',
    game_choice: '게임', game_listen_choice: '듣기게임', game_match: '짝맞추기', game_order: '조립게임', review: '복습',
  }
  return map[t] || t
}

import { useEffect, useState } from 'react'
import { WORLDS, MODULE_ORDER, loadModule, type ModuleDef } from '../lib/content'
import type { LocalState } from '../lib/store'
import { XP, levelProgress, levelTitle } from '../lib/xp'
import { todayStr } from '../lib/leitner'

export function WorldMap(props: { state: LocalState; dueCount: number; onOpenModule: (id: string) => void; onOpenDiag: () => void }) {
  const s = props.state
  const lp = levelProgress(s.xp)
  const onSeg = Math.min(10, Math.round((lp.cur / lp.need) * 10))
  const [meta, setMeta] = useState<Record<string, ModuleDef>>({})

  useEffect(() => {
    MODULE_ORDER.forEach(id => {
      loadModule(id).then(m => setMeta(prev => ({ ...prev, [id]: m }))).catch(() => {/* 미제작 모듈 */})
    })
  }, [])

  const diagAllDone = s.diagDone.length >= 4

  function moduleState(id: string): 'done' | 'open' | 'locked' {
    const p = s.progress[id]
    if (p && (p.status === 'completed' || p.status === 'mastered')) return 'done'
    const i = MODULE_ORDER.indexOf(id)
    // 진단 배정 (R-01 봉합): 배정 모듈까지의 모든 모듈은 잠금 해제 (A-006 v2 — 선행 모듈 skipped 취급)
    const placementIdx = s.placement ? MODULE_ORDER.indexOf(s.placement) : 0
    if (i <= placementIdx) return 'open'
    // 그 이후는 순서 잠금: 이전 모듈 완료 시 열림
    if (i === 0) return 'open'
    const prev = s.progress[MODULE_ORDER[i - 1]]
    return prev && (prev.status === 'completed' || prev.status === 'mastered') ? 'open' : 'locked'
  }

  // 잠김 해제 조건 문구 (A6): "○○ 클리어하면 열려!"
  function unlockNote(id: string): string {
    const i = MODULE_ORDER.indexOf(id)
    const prevId = i > 0 ? MODULE_ORDER[i - 1] : ''
    const prevTitle = (prevId && meta[prevId]?.title_ko) || '이전 단계'
    return `${prevTitle} 클리어하면 열려!`
  }

  return (
    <div className="worldmap">
      <header className="topbar">
        <div className="topbar-left">
          <span className="avatar">🧑‍🚀</span>
          <div>
            <b>{s.nickname}</b>
            <span className="level-tag">{levelTitle(lp.level)}</span>
          </div>
        </div>
        <div className="topbar-right">
          <span className="streak" title="연속 출석 — 하루 15분 이상 학습하면 인정!">🔥 {s.streak_days}</span>
          <span className="xp-chip">⭐ {s.xp} XP</span>
        </div>
      </header>

      {/* XP HUD (시안 05): 골드 LV 배지 + 10칸 픽셀 세그먼트 + 바 밖 수치 */}
      <div className="wc-hud">
        <span className="wc-lv">LV.{lp.level}</span>
        <div className="wc-hud-col">
          <div className="xpbar-seg">
            {Array.from({ length: 10 }, (_, k) => <i key={k} className={k < onSeg ? 'on' : ''} />)}
          </div>
          <div className="xp-meta"><span>{lp.cur} / {lp.need} XP</span><span>다음 레벨 -{lp.need - lp.cur}</span></div>
        </div>
      </div>

      {!diagAllDone && (
        <button className="diag-banner" onClick={props.onOpenDiag}>
          <span className="diag-emoji">📡</span>
          <span><b>플레이어 스캔 {s.diagDone.length}/4</b><br />네 능력치를 스캔하고 시작 지점을 찾자!</span>
          <span className="diag-arrow">▶</span>
        </button>
      )}

      {props.dueCount > 0 && (
        <button className="due-banner clickable" onClick={() => { location.hash = '/review' }}>
          ⛏️ 복습 광산에 캘 카드 <b>{props.dueCount}장</b> 리젠! 최대 <b>+{props.dueCount * XP.reviewCorrect + Math.floor(props.dueCount / XP.reviewComboEvery) * XP.reviewCombo} XP</b> — 캐러 가기 ▶
        </button>
      )}

      {/* 오늘의 학습 밸런스 (v1.2.0): 모험(기본코스)과 복습을 50:50으로 — 복습도 모험만큼 값지다! */}
      <BalanceMeter state={s} dueCount={props.dueCount} />

      {WORLDS.map(w => (
        <section key={w.world} className="world">
          <h2 className="world-title">{w.emoji} 월드 {w.world} — {w.name_ko}</h2>
          {w.modules.length === 0 ? (
            <p className="world-locked-note">다음 업데이트에서 열려! 지금 월드를 정복해 두자 💪</p>
          ) : (
            <div className="wc-map">
              {w.modules.map((id, idx) => {
                const st = moduleState(id)
                const m = meta[id]
                const best = s.progress[id]?.best_score
                const n = starCount(best)
                const prevDone = idx > 0 && moduleState(w.modules[idx - 1]) === 'done'
                const chip = st === 'done' ? 'CLEAR' : st === 'open' ? 'PLAY' : 'LOCK'
                const sub = st === 'locked'
                  ? unlockNote(id)
                  : st === 'done'
                    ? (m?.subtitle_ko || '완벽 채굴 도전 — 다시 플레이!')
                    : (m?.subtitle_ko || '지금 바로 캐러 가자! ⛏️')
                return (
                  <div key={id} className="wc-tile-wrap">
                    {idx > 0 && <div className={`link-v ${prevDone ? 'done' : ''}`} />}
                    <button className={`wc-tile is-${st}`} disabled={st === 'locked'} onClick={() => props.onOpenModule(id)}>
                      <span className="ico">{st === 'locked' ? '🔒' : (m?.emoji || '📦')}</span>
                      <span className="txt">
                        <h3>{m?.title_ko || id}</h3>
                        <span className="sub">{sub}</span>
                      </span>
                      <span className="right">
                        {st === 'done' && <span className="wc-stars">{'★'.repeat(n)}<span className="off">{'★'.repeat(3 - n)}</span></span>}
                        <span className="state-chip">{chip}</span>
                      </span>
                    </button>
                  </div>
                )
              })}
            </div>
          )}
        </section>
      ))}
    </div>
  )
}

/** 오늘의 학습 밸런스 미터 — 모험 XP vs 복습 XP (목표 50:50) */
function BalanceMeter(props: { state: LocalState; dueCount: number }) {
  const d = props.state.dailyXp
  const today = todayStr()
  const course = d?.date === today ? d.course : 0
  const review = d?.date === today ? d.review : 0
  const total = course + review
  if (total === 0) return null // 오늘 아직 시작 전 — 조용히
  const pct = Math.round((review / total) * 100)
  const msg = pct >= 40 && pct <= 60
    ? '⚖️ 황금 밸런스! 모험과 복습이 완벽한 조화 👑'
    : pct < 40
      ? (props.dueCount > 0 ? `⛏️ 복습 광산이 기다려! 캐면 바로 밸런스 UP (+${XP.reviewCorrect}씩)` : '⛏️ 오늘 복습 카드를 다 캤다면 OK!')
      : '🗺️ 복습 만렙! 이제 새 모험을 떠나볼까?'
  return (
    <div className="balance-meter">
      <div className="balance-head"><b>오늘의 밸런스</b><span>모험 {course} XP · 복습 {review} XP</span></div>
      <div className="balance-bar">
        <i className="course" style={{ width: `${100 - pct}%` }} />
        <i className="review" style={{ width: `${pct}%` }} />
        <em className="mid" />
      </div>
      <p className="balance-msg">{msg}</p>
    </div>
  )
}

// 별점 (A3): 정답률 기준 켜진 별 개수 — 90+:3, 70~89:2, ~69:0 (시안 06 표기)
function starCount(best: number | null | undefined): number {
  if (best == null) return 0
  if (best >= 90) return 3
  if (best >= 70) return 2
  return 0
}

#!/usr/bin/env python3
"""v1.3.0 콘텐츠 빌드 — CONTRACT v1.3 §9 오디오 규약
1) modules + modules_r + diagnostics + ghost + listening → 단일 content.json
2) voice 필드가 있는 항목에 audio_url 주입 (결정적 경로 = tts-audio/<scope>/<slug>_<voice>.mp3)
3) TTS 생성 매니페스트(tts_manifest.json) 출력 — 중복 텍스트·음성은 1클립으로 dedupe
"""
import json, glob, os, re, hashlib, sys

BASE = 'https://gbynvzxgbpmoqdsriowz.supabase.co/storage/v1/object/public/tts-audio/'
ROOT = os.path.dirname(os.path.abspath(__file__))
C = os.path.join(ROOT, '04_CONTENT')

manifest = {}  # path -> {scope, voice, text}

def slug_of(text: str) -> str:
    s = re.sub(r'[^a-z0-9]+', '_', text.lower()).strip('_')[:40].strip('_')
    h = hashlib.sha1(text.encode()).hexdigest()[:6]
    return f'{s}_{h}' if s else h

def clip(scope: str, text: str, voice: str) -> str:
    path = f'{scope}/{slug_of(text)}_{voice}.mp3'
    manifest[path] = {'scope': scope, 'voice': voice, 'text': text}
    return BASE + path

def inject(obj, default_scope='common'):
    """voice가 달린 항목에 audio_url 주입. 재생 텍스트 우선순위: play > tts > en > example"""
    if isinstance(obj, dict):
        v = obj.get('voice')
        if isinstance(v, str) and v:
            text = obj.get('play') or obj.get('tts') or obj.get('en') or obj.get('example')
            if isinstance(text, str) and text.strip():
                obj['audio_url'] = clip(default_scope, text.strip(), v)
        for val in obj.values():
            inject(val, default_scope)
    elif isinstance(obj, list):
        for val in obj:
            inject(val, default_scope)

def load(p):
    with open(p, encoding='utf-8') as f:
        return json.load(f)

modules = {}
for p in sorted(glob.glob(f'{C}/modules/*.json')) + sorted(glob.glob(f'{C}/modules_r/*.json')):
    m = load(p)
    mid = m['module_id']
    if mid.startswith('R'):
        # 수정 동굴: voice 항목 → 클립. 룬 도감 항목은 예시 단어를 nova로 (도감 탭 재생)
        for r in m.get('runes', []):
            if r.get('example'):
                r['audio_url'] = clip('common', str(r['example']).strip(), r.get('voice') or 'nova')
        inject(m)
    modules[mid] = m

diagnostics = {d['diag_id']: d for d in (load(p) for p in sorted(glob.glob(f'{C}/diagnostics/*.json')))}

ghost = {}
for p in sorted(glob.glob(f'{C}/ghost/*.json')):
    g = load(p)
    # 보스 등장 대사 = onyx (한국어 대사 — gpt-4o-mini-tts 다국어)
    if g.get('intro_ko'):
        g['intro_audio_url'] = clip('ghost', g['intro_ko'].strip(), 'onyx')
    inject(g, 'common')
    ghost[g['module_id']] = g

listening = load(f'{C}/listening/listening.json')
inject(listening, 'common')

# v1.4.0 문장 소환진 (딕토빌드 음성 클립 주입)
forge = None
forge_path = f'{C}/forge/missions.json'
if os.path.exists(forge_path):
    forge = load(forge_path)
    inject(forge, 'common')

bundle = {'modules': modules, 'diagnostics': diagnostics, 'ghost': ghost, 'listening': listening}
if forge: bundle['forge'] = forge
out = os.path.join(ROOT, 'dist_out')
os.makedirs(out, exist_ok=True)
with open(os.path.join(out, 'content.json'), 'w', encoding='utf-8') as f:
    json.dump(bundle, f, ensure_ascii=False, separators=(',', ':'))
with open(os.path.join(ROOT, 'tts_manifest.json'), 'w', encoding='utf-8') as f:
    json.dump([{'path': k, **v} for k, v in sorted(manifest.items())], f, ensure_ascii=False, indent=1)

by_voice = {}
for v in manifest.values():
    by_voice[v['voice']] = by_voice.get(v['voice'], 0) + 1
print(f"modules={len(modules)} diagnostics={len(diagnostics)} ghost={len(ghost)}")
print(f"echo_sets={len(listening['echo_sets'])} commands={len(listening['commands'])}")
print(f"content.json bytes={os.path.getsize(os.path.join(out,'content.json'))}")
print(f"클립 매니페스트 {len(manifest)}개 — 음성별: {by_voice}")

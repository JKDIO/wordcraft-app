// 뱃지 시스템 v2 (v1.2.0) — 정의·조건·진행도·판정을 한 곳에서 (앱/관제실 공용)
// 원칙: ① 모든 뱃지는 앱의 실제 기능과 정합되는 "판정 함수"를 가진다 (장식용 뱃지 금지)
//       ② 잠긴 뱃지는 클릭하면 획득 조건(hint)과 진행도를 보여준다 (Profile/관제실 공통)
//       ③ 앱 시작 시 syncBadges()가 놓친 뱃지를 소급 지급 (동기화 유실·구버전 대비)
import type { LocalState } from './store'
import { MODULE_ORDER, WORLDS } from './content'

export interface BadgeDef {
  emoji: string
  name: string
  desc: string // 획득 후 표시되는 설명
  hint: string // 잠김 상태에서 클릭 시 보여줄 획득 조건
  /** 진행도 (표시용). null이면 진행바 없이 조건 문구만 */
  progress?: (s: LocalState) => { cur: number; max: number } | null
}

const doneModules = (s: LocalState) =>
  MODULE_ORDER.filter(id => { const p = s.progress[id]; return p && (p.status === 'completed' || p.status === 'mastered') })

/** 진단 완료 수 — 로컬 diagDone ∪ 서버 병합된 progress의 DIAG-* 행 (풀 스캔 뱃지 누락 봉합) */
export const diagDoneCount = (s: LocalState) => {
  const ids = new Set(s.diagDone)
  for (const key of Object.keys(s.progress)) {
    if (!key.startsWith('DIAG-')) continue
    const p = s.progress[key]
    if (p && (p.status === 'completed' || p.status === 'mastered')) ids.add(key.slice(5))
  }
  return ids.size
}

const worldDone = (s: LocalState, world: number) => {
  const w = WORLDS.find(x => x.world === world)
  if (!w || !w.modules.length) return { cur: 0, max: 1 }
  const done = doneModules(s)
  return { cur: w.modules.filter(id => done.includes(id)).length, max: w.modules.length }
}

export const BADGE_DEFS: Record<string, BadgeDef> = {
  first_module: {
    emoji: '🥇', name: '첫 채굴', desc: '첫 모듈 클리어', hint: '아무 모듈이나 1개 클리어하면 획득!',
    progress: s => ({ cur: Math.min(1, doneModules(s).length), max: 1 }),
  },
  world1_clear: { emoji: '⛏️', name: '소리 광산 정복', desc: '월드 1 전체 클리어', hint: '월드 1(소리 광산)의 모든 챕터를 클리어하면 획득!', progress: s => worldDone(s, 1) },
  // v1.3.0: 월드 1.5 수정 동굴 — computeEarnedBadges의 `world${w.world}_clear` 템플릿과 자동 정합 (관제실 파생도 동일 템플릿)
  'world1.5_clear': { emoji: '💎', name: '수정 동굴 정복', desc: '월드 1.5 전체 클리어 — 소리를 여는 자', hint: '수정 동굴(R0~R9)의 모든 룬 챕터를 클리어하면 획득!', progress: s => worldDone(s, 1.5) },
  world2_clear: { emoji: '🏰', name: '문법 성 정복', desc: '월드 2 전체 클리어', hint: '월드 2(문법 성)의 모든 챕터를 클리어하면 획득!', progress: s => worldDone(s, 2) },
  world3_clear: { emoji: '🏹', name: '사냥의 달인', desc: '월드 3 전체 클리어', hint: '월드 3(동사 사냥터)의 모든 챕터를 클리어하면 획득!', progress: s => worldDone(s, 3) },
  world4_clear: { emoji: '🏕️', name: '생존왕', desc: '월드 4 전체 클리어', hint: '월드 4(생존 캠프)의 모든 챕터를 클리어하면 획득!', progress: s => worldDone(s, 4) },
  world5_clear: { emoji: '⏳', name: '시간의 지배자', desc: '월드 5 전체 클리어', hint: '월드 5(시제 시간여행)의 모든 챕터를 클리어하면 획득!', progress: s => worldDone(s, 5) },
  streak_3: { emoji: '🔥', name: '3일 연속', desc: '3일 연속 출석', hint: '3일 연속으로 공부하면 획득!', progress: s => ({ cur: Math.min(s.streak_days, 3), max: 3 }) },
  streak_7: { emoji: '🌋', name: '일주일 불꽃', desc: '7일 연속 출석', hint: '7일 연속으로 공부하면 획득!', progress: s => ({ cur: Math.min(s.streak_days, 7), max: 7 }) },
  streak_14: { emoji: '☄️', name: '2주 무정지', desc: '14일 연속 출석', hint: '14일 연속으로 공부하면 획득! 진짜 각오가 필요해', progress: s => ({ cur: Math.min(s.streak_days, 14), max: 14 }) },
  perfect_module: {
    emoji: '💯', name: '퍼펙트!', desc: '정확도 100% 클리어', hint: '한 모듈을 정확도 100%로 클리어하면 획득!',
    progress: () => null,
  },
  boss_slayer: {
    emoji: '⚔️', name: '보스 사냥꾼', desc: '보스전 5회 승리', hint: '서로 다른 모듈의 보스전에서 5번 이기면 획득!',
    progress: s => ({ cur: Math.min((s.bossWins || []).length, 5), max: 5 }),
  },
  diag_all: {
    emoji: '📡', name: '풀 스캔', desc: '진단 4종 완료', hint: '플레이어 스캔(진단) 4종을 모두 완료하면 획득!',
    progress: s => ({ cur: Math.min(diagDoneCount(s), 4), max: 4 }),
  },
  review_10: {
    emoji: '🪨', name: '견습 광부', desc: '복습 카드 10개 정답', hint: '복습 광산에서 카드 10개를 맞히면 획득!',
    progress: s => ({ cur: Math.min(s.reviewTotal || 0, 10), max: 10 }),
  },
  review_50: {
    emoji: '💎', name: '다이아 채굴자', desc: '복습 카드 50개 정답', hint: '복습 광산에서 카드 50개를 맞히면 획득!',
    progress: s => ({ cur: Math.min(s.reviewTotal || 0, 50), max: 50 }),
  },
  review_200: {
    emoji: '👑', name: '전설의 광부', desc: '복습 카드 200개 정답', hint: '복습 광산에서 카드 200개를 맞히면 획득! 장기기억 만렙 인증',
    progress: s => ({ cur: Math.min(s.reviewTotal || 0, 200), max: 200 }),
  },
  balance_7: {
    emoji: '⚖️', name: '황금 밸런스', desc: '모험+복습 둘 다 한 날 7일 달성', hint: '하루에 모험(모듈)과 복습을 둘 다 한 날을 7일 모으면 획득!',
    progress: s => ({ cur: Math.min((s.balanceDays || []).length, 7), max: 7 }),
  },
}

/** 현재 로컬 상태 기준으로 획득 가능한 뱃지 전체 판정 (idempotent — syncBadges에서 사용) */
export function computeEarnedBadges(s: LocalState): string[] {
  const out: string[] = []
  const done = doneModules(s)
  if (done.length >= 1) out.push('first_module')
  for (const w of WORLDS) {
    if (w.modules.length && w.modules.every(id => done.includes(id))) out.push(`world${w.world}_clear`)
  }
  if (s.streak_days >= 3) out.push('streak_3')
  if (s.streak_days >= 7) out.push('streak_7')
  if (s.streak_days >= 14) out.push('streak_14')
  // 퍼펙트: 진단(DIAG-*) 제외, 학습 모듈 100점만
  if (MODULE_ORDER.some(id => (s.progress[id]?.best_score ?? 0) >= 100)) out.push('perfect_module')
  if ((s.bossWins || []).length >= 5) out.push('boss_slayer')
  if (diagDoneCount(s) >= 4) out.push('diag_all')
  const rv = s.reviewTotal || 0
  if (rv >= 10) out.push('review_10')
  if (rv >= 50) out.push('review_50')
  if (rv >= 200) out.push('review_200')
  if ((s.balanceDays || []).length >= 7) out.push('balance_7')
  return out
}

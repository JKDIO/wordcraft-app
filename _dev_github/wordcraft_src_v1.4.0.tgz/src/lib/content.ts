// 콘텐츠 로더 — CONTENT_SPEC v1.0 계약 타입
// 배포본은 단일 /content.json (7/14 평탄화 — 모듈·진단 JSON을 1회 fetch 후 메모리 인덱싱)
export interface TtsText {
  tts?: string | null
  // v1.3.0 오디오 계약(CONTRACT v1.3 §9): audio_url 있으면 진짜 음성 클립 재생, 실패 시 tts 폴백
  audio_url?: string | null
  voice?: string | null
}

export interface StoryLine { speaker: string; emoji?: string; text_ko: string; text_en?: string | null }
export interface LearnExample extends TtsText { en: string; ko: string }
export interface LearnCard { title_ko: string; rule_ko: string; examples: LearnExample[]; tip_ko?: string; art_key?: string }
export interface ChoiceItem extends TtsText {
  id: string; q_ko: string; choices: string[]; answer_idx: number; explain_ko: string
  meme_correct?: string; meme_wrong?: string
}
export interface MatchPair extends TtsText { left: string; right: string }
export interface OrderItem extends TtsText { id: string; prompt_ko: string; tokens: string[]; answer: string; ko?: string }

export type Step =
  | { type: 'story'; lines: StoryLine[] }
  | { type: 'learn'; card: LearnCard }
  | { type: 'game'; kind: 'choice' | 'listen_choice'; prompt_ko?: string; items: ChoiceItem[] }
  | { type: 'game'; kind: 'match'; prompt_ko?: string; items: { pairs: MatchPair[] }[] | { pairs: MatchPair[] } }
  | { type: 'game'; kind: 'order'; prompt_ko?: string; items: OrderItem[] }
  | { type: 'quiz'; questions: ChoiceItem[] }
  | { type: 'speak'; mission_ko: string; target_en: string; tts: string }

export interface ReviewCardDef extends TtsText { card_id: string; front: string; back: string }

/** v1.3.0 수정 동굴 룬 도감 항목 (CONTRACT v1.3 §11) */
export interface RuneDef extends TtsText {
  ipa: string; name_ko: string; example: string; example_ko?: string; tip_ko?: string; art_key?: string
}

export interface ModuleDef {
  module_id: string; world: number; order: number
  title_ko: string; subtitle_ko?: string; emoji: string
  xp_module_clear: number; estimated_minutes: number
  steps: Step[]; review_cards: ReviewCardDef[]
  boss: { title_ko: string; intro_ko?: string; questions: ChoiceItem[] }
  runes?: RuneDef[] // 수정 동굴(R*) 전용 — 완료 시 도감에 수집
}

/** v1.3.0 유령 보스 (CONTRACT v1.3 §8) */
export interface GhostDef {
  module_id: string; title_ko: string; intro_ko: string
  intro_audio_url?: string | null
  taunt_correct?: string[]; taunt_wrong?: string[]
  questions: ChoiceItem[]
}

/** v1.4.0 문장 소환진 (CONTRACT §12 — 시안 승인 후 구현) */
export interface ForgeMission extends TtsText { id: string; ko?: string; answer: string; tokens: string[] }
export interface ForgeDef { kernel: ForgeMission[]; expand: ForgeMission[]; dicto: ForgeMission[] }

/** v1.3.0 리스닝 아케이드 (CONTRACT v1.3 §10) */
export interface EchoItem extends TtsText { id: string; play: string; q_ko: string; choices: string[]; answer_idx: number; explain_ko: string; ko_map?: string[] }
export interface EchoSet { id: string; title_ko: string; focus_ko?: string; items: EchoItem[] }
export interface CommandItem extends TtsText { id: string; play: string; q_ko: string; choices: string[]; answer_idx: number; explain_ko: string }
export interface ListeningDef { echo_sets: EchoSet[]; commands: CommandItem[] }

export interface DiagQuestion extends ChoiceItem { kind?: 'choice' | 'listen_choice' | 'order'; tokens?: string[]; answer?: string; prompt_ko?: string }
export interface DiagDef {
  diag_id: string; title_ko: string; emoji: string; intro_ko: string
  questions: DiagQuestion[]
  scoring: { bands: { min_pct: number; label_ko: string; start_module: string }[] }
}

// v1.2.0 확장: 문법 성 +C7, 동사 사냥터 +B22a/B22b, 생존 캠프 +D2S/D3S, 월드5 시제 시간여행 오픈
// v1.3.0 확장: 월드 1.5 수정 동굴(R0~R9, 발음기호 마스터) — A4(월드1) 클리어로 잠금 해제
export const RUNE_MODULES = ['R0', 'R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9']
export const WORLDS = [
  { world: 1, name_ko: '소리 광산', emoji: '⛏️', modules: ['A1', 'A2', 'A3', 'A4'] },
  { world: 1.5, name_ko: '수정 동굴', emoji: '💎', modules: RUNE_MODULES },
  { world: 2, name_ko: '문법 성', emoji: '🏰', modules: ['C0', 'C5', 'C6', 'C7'] },
  { world: 3, name_ko: '동사 사냥터', emoji: '🏹', modules: ['B21a', 'B21b', 'B22a', 'B22b'] },
  { world: 4, name_ko: '생존 캠프', emoji: '🏕️', modules: ['D1S', 'D2S', 'D3S'] },
  { world: 5, name_ko: '시제 시간여행', emoji: '⏳', modules: ['T1', 'T2', 'T3'] },
  { world: 6, name_ko: '문장 소환진 공방', emoji: '🔮', modules: [] }, // v1.4.0 오픈 — 모듈이 아니라 소환진 게임 (WorldMap 특수 렌더)
]
export const MODULE_ORDER = ['A1', 'A2', 'A3', 'A4', 'R0', 'R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9', 'C0', 'C5', 'C6', 'C7', 'B21a', 'B21b', 'B22a', 'B22b', 'D1S', 'D2S', 'D3S', 'T1', 'T2', 'T3']
export const DIAG_ORDER = ['D1', 'D2', 'D3', 'D4']
/** 진단 배정(placement)은 R 모듈이 없던 시절 규칙 — R 모듈은 배정 자동 해제에서 제외하고 자체 순서 잠금만 따른다 */
export const isRuneModule = (id: string) => /^R\d$/.test(id)

interface ContentBundle {
  modules: Record<string, ModuleDef>
  diagnostics: Record<string, DiagDef>
  ghost?: Record<string, GhostDef>      // v1.3.0
  listening?: ListeningDef              // v1.3.0
  forge?: ForgeDef                      // v1.4.0
}

let bundlePromise: Promise<ContentBundle> | null = null

/** 단일 content.json 1회 fetch — 이후 모든 모듈/진단은 메모리에서 반환 */
function loadContent(): Promise<ContentBundle> {
  if (!bundlePromise) {
    bundlePromise = fetch('/content.json').then(res => {
      if (!res.ok) throw new Error(`콘텐츠를 불러오지 못했어 (${res.status})`)
      return res.json() as Promise<ContentBundle>
    })
  }
  return bundlePromise
}

export const loadModule = (id: string) =>
  loadContent().then(c => {
    const m = c.modules[id]
    if (!m) throw new Error(`모듈 ${id}을(를) 찾지 못했어`)
    return m
  })

export const loadDiag = (id: string) =>
  loadContent().then(c => {
    const d = c.diagnostics[id]
    if (!d) throw new Error(`진단 ${id}을(를) 찾지 못했어`)
    return d
  })

// v1.3.0 로더
export const loadGhost = (moduleId: string) =>
  loadContent().then(c => {
    const g = c.ghost?.[moduleId]
    if (!g) throw new Error(`유령 보스 ${moduleId}을(를) 찾지 못했어`)
    return g
  })

export const loadListening = () =>
  loadContent().then(c => {
    if (!c.listening) throw new Error('리스닝 콘텐츠를 찾지 못했어')
    return c.listening
  })

export const loadForge = () =>
  loadContent().then(c => {
    if (!c.forge) throw new Error('소환진 콘텐츠를 찾지 못했어')
    return c.forge
  })

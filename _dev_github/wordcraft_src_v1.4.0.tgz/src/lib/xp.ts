// XP 규칙 — CONTENT_SPEC §6 (콘텐츠·엔진 계약)
// v1.2.0 복습 개편: 복습 정답 5→10 (기본코스와 동급 가치 = 50:50 원칙),
// 하루 복습 정답 10장마다 콤보 보너스 +20. (v1.2.0 이전에는 복습 answer_events가
// 기록되지 않았으므로 관제실 파생 XP와 소급 불일치 없음 — CONTRACT §2 참조)
export const XP = {
  correct: 10,
  gameClear: 15,
  speak: 10,
  moduleClear: 50,
  bossClear: 100,
  reviewCorrect: 10,
  reviewCombo: 20,
  reviewComboEvery: 10,
  ghostClear: 50, // v1.3.0 유령 보스 최초 통과 보너스 (CONTRACT v1.3 §8)
} as const

/** 레벨업 필요 누적 XP = 300 × 현재 레벨 (누진) */
export function levelForXp(totalXp: number): number {
  let level = 1
  let need = 300
  let acc = totalXp
  while (acc >= need) {
    acc -= need
    level += 1
    need = 300 * level
  }
  return level
}

export function levelProgress(totalXp: number): { level: number; cur: number; need: number } {
  let level = 1
  let need = 300
  let acc = totalXp
  while (acc >= need) {
    acc -= need
    level += 1
    need = 300 * level
  }
  return { level, cur: acc, need }
}

export const LEVEL_TITLES = [
  '', '워드 탐험가', '사운드 마스터', '문장 건축가', '그래머 기사', '대화의 용사',
  '광산의 지배자', '언어 연금술사', '전설의 크래프터',
]
export function levelTitle(level: number): string {
  return LEVEL_TITLES[Math.min(level, LEVEL_TITLES.length - 1)] || '전설의 크래프터'
}

// v1.4.0 문장 소환진 (CONTRACT §12 — Dio님 시안 승인 2026-07-16)
// "조립한 문장이 그대로 실행된다": 모드 3종 — 설계도 건축(kernel→확장) / 소환 실험실(자유 조립) / 딕토빌드(듣고 재조립)
// 3단 피드백: ①비문=소환 실패+깨진 블록 진단 ②문법OK·미션 불일치=애니메이션 실행+대조 카드(+발견 XP) ③정답=미션 장면+풀 XP
import { useEffect, useMemo, useRef, useState } from 'react'
import { loadForge, type ForgeDef, type ForgeMission } from '../lib/content'
import { SUBJECTS, VERBS, OBJECTS, ADVERBS, validate, normalize, type ForgeVerdict } from '../lib/forge'
import { mountForgeStage, type ForgeStageHandle } from '../lib/forgeStage'
import { playClip, stopClip } from '../lib/audio'
import { loadLocal, saveLocal } from '../lib/store'
import { XP } from '../lib/xp'
import type { StepEvent } from '../engine/StepRunner'

type Mode = 'menu' | 'kernel' | 'expand' | 'dicto' | 'lab'

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]] }
  return a
}

/** 발견 XP — 문장당 평생 1회 (localStorage forgeFound, additive 필드) */
function tryDiscover(sentence: string): boolean {
  const s = loadLocal()
  const found = s.forgeFound || []
  const key = normalize(sentence)
  if (found.includes(key)) return false
  saveLocal({ ...s, forgeFound: [...found, key].slice(-500) })
  return true
}

export function ForgeScreen(props: { onEvent: (e: StepEvent) => void; onExit: () => void }) {
  const [forge, setForge] = useState<ForgeDef | null>(null)
  const [error, setError] = useState(false)
  const [mode, setMode] = useState<Mode>('menu')
  const [mi, setMi] = useState(0) // 미션 인덱스
  const [placed, setPlaced] = useState<number[]>([])
  const [feedback, setFeedback] = useState<
    | null
    | { kind: 'broken'; brokenIdx: number; hint_ko: string; law_ko: string }
    | { kind: 'mismatch'; mine: string; target: string; discovered: boolean }
    | { kind: 'success'; sentence: string }
    | { kind: 'lab-ok'; sentence: string; discovered: boolean }
  >(null)
  const firstTryRef = useRef(true)
  const busyRef = useRef(false)
  const stageRef = useRef<HTMLDivElement | null>(null)
  const stage = useRef<ForgeStageHandle | null>(null)
  const [labPick, setLabPick] = useState<string[]>([])

  useEffect(() => {
    loadForge().then(setForge).catch(() => setError(true))
    return () => { stopClip(); stage.current?.destroy() }
  }, [])

  // 스테이지 마운트 (메뉴 외 화면)
  useEffect(() => {
    if (mode !== 'menu' && stageRef.current && !stage.current) {
      stage.current = mountForgeStage(stageRef.current)
      stage.current.summon('zombie')
    }
    if (mode === 'menu' && stage.current) { stage.current.destroy(); stage.current = null }
  }, [mode])

  const missions: ForgeMission[] = useMemo(() => {
    if (!forge) return []
    if (mode === 'kernel') return forge.kernel
    if (mode === 'expand') return forge.expand
    if (mode === 'dicto') return forge.dicto
    return []
  }, [forge, mode])

  const mission = missions[mi] || null
  const pool = useMemo(() => mission ? shuffle(mission.tokens.map((t, i) => ({ t, i }))) : [], [mission?.id])

  // 딕토빌드: 문항 시작 시 자동 재생
  useEffect(() => {
    if (mode === 'dicto' && mission) {
      const t = setTimeout(() => playClip(mission), 500)
      return () => clearTimeout(t)
    }
  }, [mode, mission?.id])

  function startMode(m: Mode) {
    setMode(m); setMi(0); setPlaced([]); setFeedback(null); setLabPick([])
    firstTryRef.current = true
  }

  function runParse(v: Extract<ForgeVerdict, { kind: 'ok' }>) {
    const st = stage.current
    if (!st) return 900
    st.summon(v.parse.subject.actor)
    return st.play(v.parse.verb.key, {
      speed: v.parse.adverb?.speed ?? 1,
      partner: v.parse.object?.actor,
    })
  }

  function emitMission(correct: boolean, given: string) {
    if (!mission || !firstTryRef.current) return
    firstTryRef.current = false
    props.onEvent({
      activity_type: 'forge', question_id: mission.id, question_text: mission.ko || `(듣고 조립) ${mission.answer}`,
      given_answer: given, correct_answer: mission.answer, is_correct: correct,
      xp: correct ? XP.correct : 0,
    })
  }

  function emitDiscover(sentence: string) {
    props.onEvent({
      activity_type: 'forge_discover', question_id: `DISC:${normalize(sentence).replace(/ /g, '_')}`,
      question_text: sentence, is_correct: true, xp: 2,
    })
  }

  function summonMission() {
    if (!mission || busyRef.current) return
    const tokens = placed.map(i => mission.tokens[i])
    const v = validate(tokens)
    if (v.kind === 'broken') {
      emitMission(false, tokens.join(' '))
      stage.current?.failFx()
      setFeedback({ kind: 'broken', brokenIdx: v.brokenIdx, hint_ko: v.hint_ko, law_ko: v.law_ko })
      return
    }
    const mine = v.sentence
    if (normalize(mine) === normalize(mission.answer)) {
      emitMission(true, mine)
      busyRef.current = true
      const dur = runParse(v)
      stage.current?.successFx(XP.correct)
      setTimeout(() => { busyRef.current = false; setFeedback({ kind: 'success', sentence: mine }) }, Math.min(dur, 1800))
    } else {
      // 문법 OK — 탐구 보상: 실행은 된다! (시행착오 안전지대)
      emitMission(false, mine)
      const discovered = tryDiscover(mine)
      if (discovered) emitDiscover(mine)
      busyRef.current = true
      const dur = runParse(v)
      setTimeout(() => { busyRef.current = false; setFeedback({ kind: 'mismatch', mine, target: mission.answer, discovered }) }, Math.min(dur, 1800))
    }
  }

  function summonLab() {
    if (busyRef.current) return
    const v = validate(labPick)
    if (v.kind === 'broken') {
      stage.current?.failFx()
      setFeedback({ kind: 'broken', brokenIdx: v.brokenIdx, hint_ko: v.hint_ko, law_ko: v.law_ko })
      return
    }
    const discovered = tryDiscover(v.sentence)
    if (discovered) emitDiscover(v.sentence)
    busyRef.current = true
    const dur = runParse(v)
    setTimeout(() => { busyRef.current = false; setFeedback({ kind: 'lab-ok', sentence: v.sentence, discovered }) }, Math.min(dur, 1800))
  }

  function nextMission() {
    setFeedback(null); setPlaced([]); firstTryRef.current = true
    if (mi + 1 >= missions.length) setMode('menu')
    else setMi(mi + 1)
  }

  if (error) return <div className="forge-root"><p style={{ padding: 20 }}>소환진을 불러오지 못했어. 나중에 다시!</p><button className="btn secondary wide" onClick={props.onExit}>월드맵으로</button></div>
  if (!forge) return <div className="forge-root"><p style={{ padding: 20 }}>🔮 마법진 그리는 중…</p></div>

  if (mode === 'menu') {
    return (
      <div className="forge-root arcade">
        <header className="arcade-head">
          <h2>🔮 문장 소환진</h2>
          <p>블록으로 문장을 조립하면 — 그 문장이 진짜로 실행된다! 비문은 소환 실패, 문법이 맞으면 뭐든 움직여.</p>
        </header>
        <button className="arcade-card" onClick={() => startMode('kernel')}>
          <span className="arcade-emoji">📐</span>
          <span className="arcade-txt"><h3>설계도 건축 I — 기본 소환</h3><span>주어+동사 핵심 뼈대 · 설계도 {forge.kernel.length}장</span></span>
          <span className="arcade-go">▶</span>
        </button>
        <button className="arcade-card" onClick={() => startMode('expand')}>
          <span className="arcade-emoji">🏗️</span>
          <span className="arcade-txt"><h3>설계도 건축 II — 확장 소환</h3><span>대상·빠르기까지 붙여 문장 키우기 · 설계도 {forge.expand.length}장</span></span>
          <span className="arcade-go">▶</span>
        </button>
        <button className="arcade-card" onClick={() => startMode('dicto')}>
          <span className="arcade-emoji">🎧</span>
          <span className="arcade-txt"><h3>딕토빌드 — 듣고 소환</h3><span>귀로 들은 문장을 그대로 재조립 · {forge.dicto.length}문장</span></span>
          <span className="arcade-go">▶</span>
        </button>
        <button className="arcade-card" onClick={() => startMode('lab')}>
          <span className="arcade-emoji">🧪</span>
          <span className="arcade-txt"><h3>소환 실험실 — 자유 조립</h3><span>아무 문장이나 만들어 봐! 새 문장 발견 = +2 XP (문장당 1번)</span></span>
          <span className="arcade-go">▶</span>
        </button>
        <p className="arcade-tip">💡 틀려도 감점 없음 — 비문이면 마법진이 어디가 깨졌는지 알려줘!</p>
        <button className="btn secondary wide" onClick={props.onExit}>월드맵으로</button>
      </div>
    )
  }

  const isLab = mode === 'lab'
  const isDicto = mode === 'dicto'

  return (
    <div className="forge-root forge-play">
      <div className="quiz-top">
        <button className="btn-back" onClick={() => setMode('menu')}>←</button>
        {!isLab && <span className="q-count">{Math.min(mi + 1, missions.length)}/{missions.length}</span>}
        <span className="arcade-mode-chip">{mode === 'kernel' ? '📐 기본' : mode === 'expand' ? '🏗️ 확장' : isDicto ? '🎧 딕토빌드' : '🧪 실험실'}</span>
      </div>

      <div className="forge-stage-box" ref={stageRef} />

      {!isLab && mission && (
        <div className="forge-mission">
          {isDicto ? (
            <p className="forge-mission-ko">🎧 잘 듣고 그대로 조립! <button className="tts-btn" onClick={() => playClip(mission)}>🔊</button></p>
          ) : (
            <p className="forge-mission-ko">📜 미션: <b>"{mission.ko}"</b></p>
          )}
        </div>
      )}

      {/* 조립 슬롯 */}
      <div className="order-slots forge-slots">
        {(isLab ? labPick : placed.map(i => mission!.tokens[i])).length === 0 && <span className="order-hint">아래 블록을 눌러 마법진에 올려봐!</span>}
        {(isLab ? labPick : placed.map(i => mission!.tokens[i])).map((t, pos) => {
          const broken = feedback?.kind === 'broken' && feedback.brokenIdx === pos
          return (
            <button key={pos} className={`token placed ${broken ? 'forge-broken' : ''}`}
              onClick={() => {
                if (busyRef.current) return
                setFeedback(null)
                if (isLab) setLabPick(labPick.filter((_, k) => k !== pos))
                else setPlaced(placed.filter((_, k) => k !== pos))
              }}>{t}</button>
          )
        })}
      </div>

      {/* 블록 풀 */}
      {isLab ? (
        <div className="forge-palette">
          {[
            { label: '주인공', items: SUBJECTS.map(s => s.token) },
            { label: '동작', items: VERBS.flatMap(v => [v.s3]) },
            { label: '대상', items: OBJECTS.map(o => o.token) },
            { label: '빠르기', items: ADVERBS.map(a => a.token) },
          ].map(g => (
            <div key={g.label} className="forge-group">
              <span className="forge-group-label">{g.label}</span>
              <div className="order-pool">
                {g.items.map(t => (
                  <button key={t} className="token" onClick={() => { if (!busyRef.current) { setFeedback(null); setLabPick([...labPick, t]) } }}>{t}</button>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="order-pool">
          {pool.map(({ t, i }) => (
            <button key={i} className={`token ${placed.includes(i) ? 'used' : ''}`} disabled={placed.includes(i)}
              onClick={() => { if (!busyRef.current) { setFeedback(null); setPlaced([...placed, i]) } }}>{t}</button>
          ))}
        </div>
      )}

      <button className="btn gold wide forge-summon"
        disabled={(isLab ? labPick.length : placed.length) === 0 || busyRef.current || feedback?.kind === 'success'}
        onClick={isLab ? summonLab : summonMission}>
        ⚡ 소환!
      </button>

      {/* 3단 피드백 */}
      {feedback?.kind === 'broken' && (
        <div className="feedback no forge-fb">
          <p className="feedback-meme">💥 파직! 소환 실패 — 깨진 블록을 찾았어</p>
          <p className="feedback-explain">{feedback.hint_ko}{feedback.law_ko ? ` (${feedback.law_ko})` : ''}</p>
          <p className="forge-fb-sub">블록을 다시 배열하고 ⚡ 소환! — 리스폰은 무한이야</p>
        </div>
      )}
      {feedback?.kind === 'mismatch' && (
        <div className="feedback forge-fb forge-compare">
          <p className="feedback-meme">✨ 오… 문법은 완벽해서 실행됐어! {feedback.discovered ? '(+2 XP 새 문장 발견!)' : ''} 근데 미션이랑 달라</p>
          <div className="forge-diff">
            <p><span className="forge-diff-tag">내 문장</span> {feedback.mine}</p>
            <p><span className="forge-diff-tag gold">미션 문장</span> {feedback.target}</p>
          </div>
          <p className="forge-fb-sub">둘의 차이를 찾아서 다시 소환해봐!</p>
        </div>
      )}
      {feedback?.kind === 'success' && (
        <div className="feedback ok forge-fb">
          <p className="feedback-meme">🌟 완벽 소환! "{feedback.sentence}" +{XP.correct} XP</p>
          <button className="btn primary wide" onClick={nextMission}>{mi + 1 >= missions.length ? '모드 클리어! 🏆' : '다음 설계도 →'}</button>
        </div>
      )}
      {feedback?.kind === 'lab-ok' && (
        <div className="feedback ok forge-fb">
          <p className="feedback-meme">✨ "{feedback.sentence}" 소환 성공!{feedback.discovered ? ' 새 문장 발견 +2 XP 🧪' : ' (이미 발견한 문장)'}</p>
          <button className="btn secondary wide" onClick={() => { setLabPick([]); setFeedback(null) }}>또 실험하기 🔁</button>
        </div>
      )}
    </div>
  )
}

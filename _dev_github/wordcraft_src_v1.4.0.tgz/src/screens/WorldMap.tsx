import { useEffect, useState } from 'react'
import { WORLDS, MODULE_ORDER, loadModule, isRuneModule, type ModuleDef } from '../lib/content'
import type { LocalState, ProgressEntry } from '../lib/store'
import { XP, levelProgress, levelTitle } from '../lib/xp'
import { todayStr } from '../lib/leitner'

// ── v1.3.0 유령 보스 출몰 규칙 (CONTRACT v1.3 §8) ──
const GHOST_FIRST_DAYS = 2   // 완료 D+2부터 첫 출몰
const GHOST_REMATCH_DAYS = 7 // 마스터 D+7부터 별 상향 리매치
const GHOST_MAX_VISIBLE = 3  // 동시 출몰 상한 (간격 분산 — 오래된 완료 순)

function daysSinceKST(iso: string | null | undefined): number {
  if (!iso) return -1
  const dayMs = 86400000
  const key = (d: Date) => new Date(d.toLocaleDateString('sv', { timeZone: 'Asia/Seoul' }) + 'T00:00:00Z').getTime()
  return Math.round((key(new Date()) - key(new Date(iso))) / dayMs)
}

/** 유령 출몰 대상 모듈 집합 — 첫 도전(D+2, 미마스터) 우선 + 리매치(D+7, 별<3) */
export function ghostTargets(progress: Record<string, ProgressEntry>): Set<string> {
  const first: { id: string; at: string }[] = []
  const rematch: { id: string; at: string }[] = []
  for (const id of MODULE_ORDER) {
    const p = progress[id]
    if (!p || (p.status !== 'completed' && p.status !== 'mastered')) continue
    const stars = p.stars ?? 0
    if (stars <= 0) {
      if (daysSinceKST(p.completed_at) >= GHOST_FIRST_DAYS) first.push({ id, at: p.completed_at || '' })
    } else if (stars < 3) {
      if (daysSinceKST(p.mastered_at) >= GHOST_REMATCH_DAYS) rematch.push({ id, at: p.mastered_at || '' })
    }
  }
  first.sort((a, b) => a.at.localeCompare(b.at))
  rematch.sort((a, b) => a.at.localeCompare(b.at))
  return new Set([...first, ...rematch].slice(0, GHOST_MAX_VISIBLE).map(x => x.id))
}

export function WorldMap(props: {
  state: LocalState; dueCount: number
  onOpenModule: (id: string) => void; onOpenDiag: () => void
  onOpenGhost: (id: string) => void; onOpenListen: () => void; onOpenRunes: () => void
  onOpenForge: () => void
}) {
  const s = props.state
  const lp = levelProgress(s.xp)
  const onSeg = Math.min(10, Math.round((lp.cur / lp.need) * 10))
  const [meta, setMeta] = useState<Record<string, ModuleDef>>({})

  useEffect(() => {
    MODULE_ORDER.forEach(id => {
      loadModule(id).then(m => setMeta(prev => ({ ...prev, [id]: m }))).catch(() => {/* 미제작 모듈 */})
    })
  }, [])

  const diagAllDone = s.diagDone.length >= 4

  function moduleState(id: string): 'done' | 'open' | 'locked' {
    const p = s.progress[id]
    if (p && (p.status === 'completed' || p.status === 'mastered')) return 'done'
    const i = MODULE_ORDER.indexOf(id)
    // 진단 배정 (R-01 봉합): 배정 모듈까지의 모든 모듈은 잠금 해제 (A-006 v2 — 선행 모듈 skipped 취급)
    // v1.3.0: 수정 동굴(R*)은 진단 시절에 없던 신규 월드 — 배정 자동 해제에서 제외, 자체 순서 잠금만 따른다
    const placementIdx = s.placement ? MODULE_ORDER.indexOf(s.placement) : 0
    if (i <= placementIdx && !isRuneModule(id)) return 'open'
    // 그 이후는 순서 잠금: 이전 모듈 완료 시 열림
    // v1.3.0: 본선(비 R 모듈)의 "이전 모듈"은 R 모듈을 건너뛴다 — 수정 동굴은 보너스 월드(본선 진도 비차단)
    if (i === 0) return 'open'
    let j = i - 1
    if (!isRuneModule(id)) while (j > 0 && isRuneModule(MODULE_ORDER[j])) j--
    const prev = s.progress[MODULE_ORDER[j]]
    return prev && (prev.status === 'completed' || prev.status === 'mastered') ? 'open' : 'locked'
  }

  const ghosts = ghostTargets(s.progress)

  // 잠김 해제 조건 문구 (A6): "○○ 클리어하면 열려!"
  function unlockNote(id: string): string {
    const i = MODULE_ORDER.indexOf(id)
    let j = i - 1
    if (!isRuneModule(id)) while (j > 0 && isRuneModule(MODULE_ORDER[j])) j-- // v1.3.0: 본선 안내는 R 모듈 건너뜀
    const prevId = j >= 0 ? MODULE_ORDER[j] : ''
    const prevTitle = (prevId && meta[prevId]?.title_ko) || '이전 단계'
    return `${prevTitle} 클리어하면 열려!`
  }

  return (
    <div className="worldmap">
      <header className="topbar">
        <div className="topbar-left">
          <span className="avatar">🧑‍🚀</span>
          <div>
            <b>{s.nickname}</b>
            <span className="level-tag">{levelTitle(lp.level)}</span>
          </div>
        </div>
        <div className="topbar-right">
          <span className="streak" title="연속 출석 — 하루 15분 이상 학습하면 인정!">🔥 {s.streak_days}</span>
          <span className="xp-chip">⭐ {s.xp} XP</span>
        </div>
      </header>

      {/* XP HUD (시안 05): 골드 LV 배지 + 10칸 픽셀 세그먼트 + 바 밖 수치 */}
      <div className="wc-hud">
        <span className="wc-lv">LV.{lp.level}</span>
        <div className="wc-hud-col">
          <div className="xpbar-seg">
            {Array.from({ length: 10 }, (_, k) => <i key={k} className={k < onSeg ? 'on' : ''} />)}
          </div>
          <div className="xp-meta"><span>{lp.cur} / {lp.need} XP</span><span>다음 레벨 -{lp.need - lp.cur}</span></div>
        </div>
      </div>

      {!diagAllDone && (
        <button className="diag-banner" onClick={props.onOpenDiag}>
          <span className="diag-emoji">📡</span>
          <span><b>플레이어 스캔 {s.diagDone.length}/4</b><br />네 능력치를 스캔하고 시작 지점을 찾자!</span>
          <span className="diag-arrow">▶</span>
        </button>
      )}

      {props.dueCount > 0 && (
        <button className="due-banner clickable" onClick={() => { location.hash = '/review' }}>
          ⛏️ 복습 광산에 캘 카드 <b>{props.dueCount}장</b> 리젠! 최대 <b>+{props.dueCount * XP.reviewCorrect + Math.floor(props.dueCount / XP.reviewComboEvery) * XP.reviewCombo} XP</b> — 캐러 가기 ▶
        </button>
      )}

      {/* 오늘의 학습 밸런스 (v1.2.0): 모험(기본코스)과 복습을 50:50으로 — 복습도 모험만큼 값지다! */}
      <BalanceMeter state={s} dueCount={props.dueCount} />

      {/* v1.3.0 소리 훈련소 (에코 사냥·지령 미션) — 진짜 사람 목소리 듣기 훈련 */}
      <button className="due-banner listen-banner clickable" onClick={props.onOpenListen}>
        🎧 <b>소리 훈련소</b> 오픈! 진짜 목소리로 귀 단련 — 에코 사냥 · 지령 미션 ▶
      </button>

      {ghosts.size > 0 && (
        <div className="ghost-notice">
          👻 <b>유령 출몰!</b> 클리어한 모듈에 유령이 나타났어 — 진짜 배웠는지 시험하러 왔대. (이기면 👻별 획득!)
        </div>
      )}

      {WORLDS.map(w => (
        <section key={w.world} className="world">
          <h2 className="world-title">
            {w.emoji} 월드 {w.world} — {w.name_ko}
            {w.world === 1.5 && (
              <button className="runedex-btn" onClick={props.onOpenRunes}>💎 룬 도감</button>
            )}
          </h2>
          {w.modules.length === 0 ? (
            w.world === 6 ? (
              /* v1.4.0 문장 소환진 공방 — 모듈이 아닌 소환 게임 입구 */
              <button className="wc-tile is-open forge-entry" onClick={props.onOpenForge}>
                <span className="ico">🔮</span>
                <span className="txt">
                  <h3>문장 소환진</h3>
                  <span className="sub">조립한 문장이 진짜로 실행된다! 설계도 건축 · 실험실 · 딕토빌드</span>
                </span>
                <span className="right"><span className="state-chip">PLAY</span></span>
              </button>
            ) : (
              <p className="world-locked-note">다음 업데이트에서 열려! 지금 월드를 정복해 두자 💪</p>
            )
          ) : (
            <div className="wc-map">
              {w.modules.map((id, idx) => {
                const st = moduleState(id)
                const m = meta[id]
                const p = s.progress[id]
                const best = p?.best_score
                const n = starCount(best)
                const gStars = p?.stars ?? 0
                const hasGhost = ghosts.has(id)
                const prevDone = idx > 0 && moduleState(w.modules[idx - 1]) === 'done'
                const chip = st === 'done' ? 'CLEAR' : st === 'open' ? 'PLAY' : 'LOCK'
                const sub = st === 'locked'
                  ? unlockNote(id)
                  : hasGhost
                    ? '👻 유령의 시험이 기다린다 — 리매치!'
                    : st === 'done'
                      ? (m?.subtitle_ko || '완벽 채굴 도전 — 다시 플레이!')
                      : (m?.subtitle_ko || '지금 바로 캐러 가자! ⛏️')
                return (
                  <div key={id} className="wc-tile-wrap">
                    {idx > 0 && <div className={`link-v ${prevDone ? 'done' : ''}`} />}
                    <button
                      className={`wc-tile is-${st} ${hasGhost ? 'has-ghost' : ''}`}
                      disabled={st === 'locked'}
                      onClick={() => (hasGhost ? props.onOpenGhost(id) : props.onOpenModule(id))}
                    >
                      <span className="ico">{st === 'locked' ? '🔒' : hasGhost ? '👻' : (m?.emoji || '📦')}</span>
                      <span className="txt">
                        <h3>{m?.title_ko || id}</h3>
                        <span className="sub">{sub}</span>
                      </span>
                      <span className="right">
                        {st === 'done' && gStars > 0 && (
                          <span className="wc-stars ghost-stars" title="유령 보스 별">👻{'★'.repeat(gStars)}</span>
                        )}
                        {st === 'done' && <span className="wc-stars">{'★'.repeat(n)}<span className="off">{'★'.repeat(3 - n)}</span></span>}
                        <span className="state-chip">{chip}</span>
                      </span>
                    </button>
                    {hasGhost && st === 'done' && (
                      <button className="ghost-replay" onClick={() => props.onOpenModule(id)}>모듈 다시 풀기는 여기 →</button>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </section>
      ))}
    </div>
  )
}

/** 오늘의 학습 밸런스 미터 — 모험 XP vs 복습 XP (목표 50:50) */
function BalanceMeter(props: { state: LocalState; dueCount: number }) {
  const d = props.state.dailyXp
  const today = todayStr()
  const course = d?.date === today ? d.course : 0
  const review = d?.date === today ? d.review : 0
  const total = course + review
  if (total === 0) return null // 오늘 아직 시작 전 — 조용히
  const pct = Math.round((review / total) * 100)
  const msg = pct >= 40 && pct <= 60
    ? '⚖️ 황금 밸런스! 모험과 복습이 완벽한 조화 👑'
    : pct < 40
      ? (props.dueCount > 0 ? `⛏️ 복습 광산이 기다려! 캐면 바로 밸런스 UP (+${XP.reviewCorrect}씩)` : '⛏️ 오늘 복습 카드를 다 캤다면 OK!')
      : '🗺️ 복습 만렙! 이제 새 모험을 떠나볼까?'
  return (
    <div className="balance-meter">
      <div className="balance-head"><b>오늘의 밸런스</b><span>모험 {course} XP · 복습 {review} XP</span></div>
      <div className="balance-bar">
        <i className="course" style={{ width: `${100 - pct}%` }} />
        <i className="review" style={{ width: `${pct}%` }} />
        <em className="mid" />
      </div>
      <p className="balance-msg">{msg}</p>
    </div>
  )
}

// 별점 (A3): 정답률 기준 켜진 별 개수 — 90+:3, 70~89:2, ~69:0 (시안 06 표기)
function starCount(best: number | null | undefined): number {
  if (best == null) return 0
  if (best >= 90) return 3
  if (best >= 70) return 2
  return 0
}

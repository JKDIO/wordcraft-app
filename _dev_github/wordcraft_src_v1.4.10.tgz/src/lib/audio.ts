// v1.3.0 오디오 재생 (CONTRACT v1.3 §9) — Storage public URL 클립 우선, 실패/부재 시 네이티브 TTS 폴백.
// WebView 안전(L8): 표준 HTMLAudioElement + 기존 tts.ts 폴백만 사용, 브라우저 전용 API 의존 없음.
// v1.4.1: 이중 재생(남/여 동시) 봉합 — 정지 시 핸들러 먼저 해제 + 재생이 시작된 클립은 늦은 error여도 폴백 금지(started).
import { speak, stopSpeak } from './tts'

const AUDIO_BASE = 'https://gbynvzxgbpmoqdsriowz.supabase.co/storage/v1/object/public/tts-audio/'

let current: HTMLAudioElement | null = null

export interface Playable { audio_url?: string | null; tts?: string | null }

/** 클립 재생 — rate 0.75 = 천천히 토글. 클립 실패 시 tts 텍스트로 1회 폴백. */
export function playClip(p: Playable, rate = 1) {
  const ttsRate = rate < 1 ? 0.6 : 0.85
  if (p.audio_url) {
    try {
      stopClip()
      const a = new Audio(p.audio_url)
      a.playbackRate = rate
      let started = false
      let fell = false
      const fallback = () => {
        if (started || fell) return
        fell = true
        if (p.tts) speak(p.tts, ttsRate)
      }
      a.onplaying = () => { started = true }
      a.onerror = fallback
      current = a
      const pr = a.play()
      if (pr && typeof pr.catch === 'function') pr.catch(fallback)
      return
    } catch { /* 아래 폴백 */ }
  }
  if (p.tts) speak(p.tts, ttsRate)
}

export function stopClip() {
  try {
    if (current) {
      current.onerror = null
      current.onplaying = null
      current.pause()
      current.src = ''
      current = null
    }
  } catch { /* */ }
  // 진행 중이던 폴백 TTS도 함께 정지(이전 문항의 늦은 폴백이 새 클립과 겹치는 것 차단)
  stopSpeak()
}

/** 콘텐츠 빌드 시 주입되는 audio_url 규약과 동일한 URL 생성 (수동 참조용) */
export function clipUrl(scope: string, slug: string, voice: string): string {
  return `${AUDIO_BASE}${scope}/${slug}_${voice}.mp3`
}

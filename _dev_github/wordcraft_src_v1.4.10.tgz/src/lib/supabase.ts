// 경량 Supabase REST + Auth 클라이언트 (PostgREST + GoTrue) — 외부 의존성 0
// v2(다가구): Supabase Auth 세션(JWT) 도입 — 세션이 있으면 그 토큰으로 호출(Phase3 RLS가 가족 판별),
// 없으면 기존처럼 anon 키(레거시 예한이 기기 호환). apikey 헤더는 항상 anon.
const SUPA = 'https://gbynvzxgbpmoqdsriowz.supabase.co'
const URL_BASE = `${SUPA}/rest/v1`
const AUTH_BASE = `${SUPA}/auth/v1`
const ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdieW52enhnYnBtb3Fkc3Jpb3d6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM3NzE5NTksImV4cCI6MjA5OTM0Nzk1OX0.tMtlmdyHgq_AURSNe_D5JdHqORZ60C4I_fh1lJ19T8U'

export const FAMILY_CODE = 'wc-yehan-7351'

type Row = Record<string, unknown>

// ---------- Auth 세션 (GoTrue) ----------
interface Session { access_token: string; refresh_token: string; expires_at: number }
const SESSION_KEY = 'wordcraft_auth_v1'
let session: Session | null = (() => {
  try { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null') as Session | null } catch { return null }
})()
function saveSession(s: Session | null) {
  session = s
  try { s ? localStorage.setItem(SESSION_KEY, JSON.stringify(s)) : localStorage.removeItem(SESSION_KEY) } catch { /* */ }
}
export function isAuthed(): boolean { return !!session }
export function authToken(): string | null { return session?.access_token ?? null }

async function authReq(path: string, init: RequestInit = {}): Promise<Row> {
  const res = await fetch(`${AUTH_BASE}${path}`, {
    ...init,
    headers: { apikey: ANON_KEY, 'Content-Type': 'application/json', ...(init.headers || {}) },
  })
  const text = await res.text()
  const body = (text ? JSON.parse(text) : {}) as Row
  if (!res.ok) throw new Error(`auth ${res.status}: ${text}`)
  return body
}
function storeTokens(r: Row): boolean {
  const at = r.access_token as string | undefined
  const rt = r.refresh_token as string | undefined
  if (at && rt) {
    saveSession({ access_token: at, refresh_token: rt, expires_at: Date.now() + (Number(r.expires_in) || 3600) * 1000 })
    return true
  }
  return false
}
/** 익명 로그인(아이 기기) — 자격증명 없이 signup = 익명 세션(대시보드에서 익명 로그인 ON 필요) */
export async function signInAnonymously(): Promise<void> {
  const r = await authReq('/signup', { method: 'POST', body: JSON.stringify({ data: {}, gotrue_meta_security: {} }) })
  storeTokens(r)
}
/** 구글 로그인(보호자) — 리디렉션. 돌아오면 URL 해시에 토큰이 실려온다. */
export function signInWithGoogle(redirectTo: string = location.origin + location.pathname): void {
  location.href = `${AUTH_BASE}/authorize?provider=google&redirect_to=${encodeURIComponent(redirectTo)}`
}
/** 앱 로드 시 구글 콜백 해시(#access_token=...) 처리 — 토큰 저장 후 해시 정리(라우팅 해시엔 영향 없음) */
export function consumeAuthRedirect(): boolean {
  try {
    const h = location.hash || ''
    if (h.includes('access_token=')) {
      const p = new URLSearchParams(h.replace(/^#/, ''))
      const at = p.get('access_token'), rt = p.get('refresh_token')
      if (at && rt) {
        saveSession({ access_token: at, refresh_token: rt, expires_at: Date.now() + (Number(p.get('expires_in')) || 3600) * 1000 })
        history.replaceState(null, '', location.pathname + location.search)
        return true
      }
    }
  } catch { /* */ }
  return false
}
async function refreshSession(): Promise<boolean> {
  if (!session?.refresh_token) return false
  try {
    const r = await authReq('/token?grant_type=refresh_token', { method: 'POST', body: JSON.stringify({ refresh_token: session.refresh_token }) })
    return storeTokens(r)
  } catch { saveSession(null); return false }
}
export interface AuthUser { id: string; email?: string; is_anonymous?: boolean }
export async function getAuthUser(): Promise<AuthUser | null> {
  if (!session) return null
  try { return await authReq('/user', { headers: { Authorization: `Bearer ${session.access_token}` } }) as unknown as AuthUser } catch { return null }
}
export async function signOut(): Promise<void> {
  try { if (session) await authReq('/logout', { method: 'POST', headers: { Authorization: `Bearer ${session.access_token}` } }) } catch { /* */ }
  saveSession(null)
}

// ---------- REST (세션 토큰 우선, 없으면 anon — 레거시 호환) ----------
async function doFetch(path: string, init: RequestInit, token: string): Promise<Response> {
  return fetch(`${URL_BASE}${path}`, {
    ...init,
    headers: { apikey: ANON_KEY, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', Prefer: 'return=representation', ...(init.headers || {}) },
  })
}
async function req(path: string, init: RequestInit = {}): Promise<Row[]> {
  let res = await doFetch(path, init, session?.access_token || ANON_KEY)
  if (res.status === 401 && session && await refreshSession()) res = await doFetch(path, init, session.access_token)
  if (!res.ok) throw new Error(`supabase ${res.status}: ${await res.text()}`)
  const text = await res.text()
  return text ? JSON.parse(text) : []
}

export const db = {
  select: (table: string, query: string) => req(`/${table}?${query}`),
  insert: (table: string, rows: Row | Row[]) =>
    req(`/${table}`, { method: 'POST', body: JSON.stringify(rows) }),
  /** ignore=true면 이미 있는 행은 건드리지 않음 (복습 카드 박스 보존 등 성취 보호용) */
  upsert: (table: string, rows: Row | Row[], onConflict: string, ignore = false) =>
    req(`/${table}?on_conflict=${onConflict}`, {
      method: 'POST',
      body: JSON.stringify(rows),
      headers: { Prefer: `resolution=${ignore ? 'ignore' : 'merge'}-duplicates,return=representation` },
    }),
  update: (table: string, query: string, patch: Row) =>
    req(`/${table}?${query}`, { method: 'PATCH', body: JSON.stringify(patch) }),
}

/** RPC 호출 (세션 토큰 우선) */
export async function rpc(fn: string, args: Row): Promise<unknown> {
  const call = (token: string) => fetch(`${URL_BASE}/rpc/${fn}`, {
    method: 'POST',
    headers: { apikey: ANON_KEY, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(args),
  })
  let res = await call(session?.access_token || ANON_KEY)
  if (res.status === 401 && session && await refreshSession()) res = await call(session.access_token)
  const text = await res.text()
  if (!res.ok) throw new Error(`rpc ${res.status}: ${text}`)
  return text ? JSON.parse(text) : null
}
/** 가족 코드로 연결 (보호자=guardian / 아이기기=device) */
export async function joinFamily(code: string, role: 'guardian' | 'device', relation?: string | null, learnerId?: string | null): Promise<unknown> {
  return rpc('wc_join_family', { p_code: code, p_role: role, p_relation: relation ?? null, p_learner_id: learnerId ?? null })
}
/** 가족 코드로 그 가족의 아이(프로필) 목록 */
export async function familyLearners(code: string): Promise<{ id: string; nickname: string }[]> {
  const r = await rpc('wc_family_learners', { p_code: code })
  return (Array.isArray(r) ? r : []) as { id: string; nickname: string }[]
}
/** Phase 3: 레거시 기기(로컬 learnerId 보유·세션無) 무중단 이관 — 현재 익명 세션을 그 learner에 device 바인딩 */
export async function bindLegacyDevice(learnerId: string): Promise<void> {
  await rpc('wc_bind_legacy_device', { p_learner_id: learnerId })
}

export interface Learner {
  id: string
  family_code: string
  family_id?: string | null
  nickname: string
  admin_pin: string
  xp: number
  level: number
  streak_days: number
  last_active_date: string | null
}

const LEARNER_COLS = 'id,family_code,family_id,nickname,admin_pin,xp,level,streak_days,last_active_date'

export async function fetchLearner(): Promise<Learner> {
  const rows = await db.select('learners', `family_code=eq.${FAMILY_CODE}&limit=1`)
  if (!rows.length) throw new Error('learner not found')
  return rows[0] as unknown as Learner
}

/** id로 learner 단건 조회 (기기 세션이 바인딩된 아이 로드용) */
export async function fetchLearnerById(id: string): Promise<Learner | null> {
  const rows = await db.select('learners', `id=eq.${id}&select=${LEARNER_COLS}&limit=1`)
  return rows.length ? (rows[0] as unknown as Learner) : null
}

/** 이 기기(익명 세션)에 연결된 아이 learner — memberships(role=device)의 learner_id로 조회.
 *  연결 안 됐거나 오류면 null(레거시 폴백은 호출부가 처리). */
export async function myDeviceLearner(uid: string): Promise<Learner | null> {
  try {
    const m = await db.select('memberships', `user_id=eq.${uid}&role=eq.device&select=learner_id&limit=1`)
    const lid = m.length ? ((m[0] as { learner_id?: string | null }).learner_id ?? null) : null
    if (!lid) return null
    return await fetchLearnerById(lid)
  } catch { return null }
}

/** 보호자(구글) 세션의 가족 + 그 가족 아이들.
 *  familyId=null = 아직 가족 미가입(가족 코드 입력 필요). learners=가족 내 아이 목록(없을 수 있음). */
export async function myFamilyLearners(uid: string): Promise<{ familyId: string | null; learners: Learner[] }> {
  const m = await db.select('memberships', `user_id=eq.${uid}&role=in.(owner,guardian)&select=family_id&limit=1`)
  if (!m.length) return { familyId: null, learners: [] }
  const familyId = (m[0] as { family_id?: string | null }).family_id ?? null
  if (!familyId) return { familyId: null, learners: [] }
  const rows = await db.select('learners', `family_id=eq.${familyId}&select=${LEARNER_COLS}&order=nickname.asc`)
  return { familyId, learners: rows as unknown as Learner[] }
}

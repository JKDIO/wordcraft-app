import { useEffect, useState } from 'react'
import { getAuthUser, myFamilyLearners, joinFamily, signOut, type Learner } from '../lib/supabase'
import { AdminPage } from './AdminPage'

/** v2 다가구 — 보호자(구글) 대시보드.
 *  ① 아직 가족 미가입 → 가족 코드로 보호자 연결 ② 가족의 아이 목록 → 아이 선택 시 그 아이 관제실.
 *  기존 관제실(AdminPage)을 아이별로 재사용(learner 전달 → PIN 생략). */
const RELATIONS = ['아빠', '엄마', '할아버지', '할머니'] as const

export function FamilyDashboard() {
  const [phase, setPhase] = useState<'loading' | 'join' | 'list'>('loading')
  const [learners, setLearners] = useState<Learner[]>([])
  const [selected, setSelected] = useState<Learner | null>(null)
  const [code, setCode] = useState('')
  const [relation, setRelation] = useState<string>('아빠')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  async function load() {
    setErr(null)
    const user = await getAuthUser()
    if (!user) { setPhase('join'); setErr('로그인이 풀렸어요. 다시 로그인해줘!'); return }
    try {
      const { familyId, learners } = await myFamilyLearners(user.id)
      if (!familyId) { setPhase('join') }
      else { setLearners(learners); setPhase('list') }
    } catch { setErr('가족 정보를 불러오지 못했어요. 잠시 후 다시 시도!'); setPhase('join') }
  }
  useEffect(() => { void load() }, [])

  async function connectGuardian() {
    setBusy(true); setErr(null)
    try {
      await joinFamily(code.trim(), 'guardian', relation)
      await load()
    } catch { setErr('연결에 실패했어요. 가족 코드를 다시 확인해줘!') }
    setBusy(false)
  }

  async function logout() {
    setBusy(true)
    try { await signOut() } catch { /* */ }
    location.hash = ''
    location.reload()
  }

  // 아이를 골랐으면 그 아이 관제실 (PIN 생략 — 이미 구글 인증됨)
  if (selected) return <AdminPage learner={selected} onExit={() => setSelected(null)} />

  if (phase === 'loading') {
    return <div className="center-box"><div className="diag-big">👨‍👩‍👧</div><p>가족 정보를 불러오는 중…</p></div>
  }

  if (phase === 'join') {
    return (
      <div className="center-box">
        <div className="diag-big">👨‍👩‍👧</div>
        <h2>우리 가족 연결하기</h2>
        <p>가족 <b>참여 코드</b>를 입력해줘! (아이 기기에 알려준 그 코드)</p>
        <input
          value={code}
          onChange={(e: { target: { value: string } }) => setCode(e.target.value.toUpperCase())}
          placeholder="예: YEHAN-1234"
          style={{ width: '100%', maxWidth: 320, padding: '12px 14px', fontSize: 18, textAlign: 'center', letterSpacing: 1, borderRadius: 12, border: '1px solid #2a3a4f', background: '#0f1a28', color: '#eaf1fa', margin: '8px 0' }}
        />
        <p style={{ margin: '6px 0 2px', opacity: 0.85 }}>나는 아이의…</p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center', margin: '4px 0 10px' }}>
          {RELATIONS.map(r => (
            <button key={r} className={`btn ${relation === r ? 'primary' : 'ghost'}`} onClick={() => setRelation(r)}>{r}</button>
          ))}
        </div>
        <button className="btn primary wide" disabled={busy || !code.trim()} onClick={connectGuardian}>{busy ? '연결 중…' : '가족 연결 →'}</button>
        {err && <p style={{ color: '#ff8f7e', marginTop: 10 }}>{err}</p>}
        <button className="btn ghost wide" disabled={busy} onClick={logout}>로그아웃</button>
      </div>
    )
  }

  // phase === 'list'
  return (
    <div className="center-box">
      <div className="diag-big">👨‍👩‍👧</div>
      <h2>우리 아이들</h2>
      {learners.length === 0 ? (
        <p>아직 등록된 아이가 없어요. 아이 기기에서 가족 코드로 프로필을 만들면 여기에 나타나요! 🧒</p>
      ) : (
        <>
          <p>성취를 볼 아이를 골라줘! 👇</p>
          {learners.map(l => (
            <button key={l.id} className="btn secondary wide" onClick={() => setSelected(l)}>
              🧒 {l.nickname} <span style={{ opacity: 0.7, fontSize: 13 }}>· Lv.{l.level} · {l.xp.toLocaleString()} XP</span>
            </button>
          ))}
        </>
      )}
      {err && <p style={{ color: '#ff8f7e', marginTop: 10 }}>{err}</p>}
      <button className="btn ghost wide" disabled={busy} onClick={logout}>로그아웃</button>
    </div>
  )
}

# WordCraft 소스 스냅샷 — v1.4.12 (2026-07-23)
> **현재 소스 SSOT = 이 스냅샷 + `wordcraft_src_v1.4.9.tgz`.** (src_v1.4.6_recon/1.4.7은 낡음.)

## v1.4.8/1.4.9 다가구 Phase 3 (2026-07-23)
- supabase.ts: `bindLegacyDevice(learnerId)` (RPC wc_bind_legacy_device) — 레거시 기기 무중단 device 바인딩.
- App.tsx: 시작 시 세션 없고 로컬 learnerId 있으면 자동 익명 로그인+바인딩(무중단 이관). `#/admin`도 세션 확보(격리 후 데이터 접근).
- version.ts 1.4.9.
- DB: RLS 멤버십 격리(마이그레이션 phase3_membership_rls_isolation) — 코드 아닌 DB. 앱은 세션 토큰으로 호출(supabase.ts req 세션 우선, 이미 구현됨).
- 검증: 격리 양방향 실측 통과(RELEASE_LOG v1.4.9 참조).
유실된 노트북 SSOT를 GitHub v1.4.0 스냅샷 + 프로젝트 메모리 문서로 재구성. 라이브 배포본은 v1.4.6 → 이번 v1.4.7(다가구 A) 배포 예정.

## v1.4.7 다가구 인증 라우팅 (2026-07-23, Phase 2-C 완결)
- **App.tsx**: 인증 상태 판별(getAuthUser) → legacy(세션無=예한 하위호환)/device(익명=아이기기)/guardian(구글=보호자) 분기. guardian→가족 대시보드 자동 이동·학습세션 미생성(하트비트 가드). device→myDeviceLearner로 바인딩 아이 로드. /family 라우트 + noLearnerChrome.
- **supabase.ts**: fetchLearnerById·myDeviceLearner(uid)·myFamilyLearners(uid) 추가. Learner에 family_id(옵셔널). LEARNER_COLS.
- **store.ts**: initLearner(s, preLearner?) — 바인딩 아이 주입(없으면 레거시 fetchLearner=예한).
- **screens/FamilyDashboard.tsx**(신규): 보호자 미가입→가족코드로 guardian 연결 / 가족 아이 목록→선택 시 AdminPage(learner) / 로그아웃.
- **screens/AdminPage.tsx**: AdminPage(props: {learner?, onExit?}) — learner 전달 시 PIN 생략·헤더에 아이 이름·← 버튼. 레거시 /admin PIN 경로 불변.
- 검증: tsc 0 · bun --production · playwright 6라우트(/, /connect, /family, /admin, /review, /profile) 렌더+JS에러0. 레거시 예한 흐름 비파괴.

## 재구성 반영(이전 v1.4.6까지, tsc 0 · bun --production · playwright 스모크 통과)
- version.ts APP_VERSION=1.4.7
- audio.ts (v1.4.1): stopClip 핸들러 선해제+started(onplaying) 플래그+stopSpeak — 이중 목소리 봉합
- tts.ts (v1.4.1): stopSpeak() 신설
- MatchGame.tsx (v1.4.6): speak→playClip
- StepRunner SpeakView + content.ts speak (v1.4.5): speak→playClip(audio_url 우선)
- ReviewMine.tsx (v1.4.4): 입구 진입마다 재조회 + wordcraft_review_done_v1 재채굴 차단 + review_count+1
- leitner.ts kstTomorrowStr + App.tsx 시드 KST(v1.4.4)
- forge.ts OBJECTS 'the monster'(v1.4.2 일부)
- **store.ts syncSharedDaily + App 호출 (v1.4.3) — syncSharedDaily 반영(2026-07-23 Phase2), 관제실 xpOf 1:1**

## ⚠️ 아직 재구성 안 된 v1.4.x 델타 (첫 다가구 앱 배포 전 반드시 재적용 — 라이브 main.js 대조)
1. v1.4.1 뒤로가기 버튼: ListenArcade 라운드(setMode('menu')) + GhostBattle 전투 phase 상단 ← (props.onExit). *cosmetic.*
2. v1.4.2 소환진 explode/eat: forgeStage.ts explode=주어 폭발후 리스폰, eat=목적어 배역을 먹잇감 스프라이트로 / ForgeScreen 버튼·피드백을 조립 슬롯 아래로. *픽셀 로직 — 라이브 대조 필수.*
3. (완료 2026-07-23) ~~v1.4.3 syncSharedDaily~~: store.ts 신설 함수(오늘 answer_events KST xpOf 1:1 + module/diag/ghost 보너스 + 복습 콤보 / 14일 sessions≥15분 출석칩 합집합 / 오늘 활성시간 서버 max) + App.tsx 시작 시 호출. 참조: AdminPage xpOf(L70)·comboBonusOf(L81)·moduleBonus(L84). *display-only, additive.*
4. v1.4.5 build_content.py default_voice: R* voice누락 재생항목 nova 기본 주입(기존 audio_url 미덮어씀). *04_CONTENT 유실로 현재 테스트 불가 — content.json은 이미 v1.4.6 산출물.*

## 유실·주의
- 04_CONTENT(콘텐츠 원본 JSON) 유실 — content.json(v1.4.6, 475클립) 산출물만 존재. 신규 콘텐츠 저작 시 필요.
- 배포 산출물(main.js/content.json/app.css)은 GitHub·Vercel에 v1.4.6로 온전 → 재배포 불필요.

## Phase 2-C 코어 (2026-07-23, v1.4.7에 통합 완료)
- supabase.ts: Auth 세션 계층(GoTrue) — signInWithGoogle(리디렉션)·signInAnonymously·refresh·getAuthUser·signOut·세션우선 REST/RPC. 세션 없으면 anon(레거시 호환).
- screens/Connect.tsx: 부모(구글)/아이(가족코드→wc_family_learners→프로필→signInAnonymously+wc_join_family) 연결 화면.
- App.tsx: consumeAuthRedirect() 모듈로드 처리 + /connect 라우트.
- 백엔드: wc_family_learners(p_code) RPC(anon/authenticated).
- **✅ 인증상태별 앱 라우팅 완료(위 v1.4.7).** 남은 것: **라이브 왕복 테스트(배포 후 구글 로그인/코드 연결 실측)** + Phase 3(RLS 가족 격리).

## v1.4.10 (2026-07-23)
- GhostBattle 전투 phase + ListenArcade 라운드 상단 ← 나가기 버튼 복원(v1.4.1 델타 재적용, 인라인 스타일). version 1.4.10.
- 남은: v1.4.2 소환진 픽셀(별도 세션).

## v1.4.11 (2026-07-23)
- SuperConsole.tsx(신규 #/super): 소유자 가족·아이 생성 콘솔. supabase.ts isOwner/adminListFamilies/adminCreateFamily/adminAddLearner. App.tsx /super 라우트+슈퍼 자동바인딩 제외+wc_after_login. index.html manifest/apple 태그. version 1.4.11.
- DB: phase5_superadmin_console_rpcs (wc_owners + 소유자게이트 RPC 4종).

## v1.4.12 (2026-07-23)
- 부모 셀프서비스: families.parent_name + RPC(wc_guardian_family, wc_guardian_add_learner, create_family 3-arg). SuperConsole 부모명. FamilyDashboard 재설계(아이 추가·아이별 문자링크·설치안내·관제실). Connect 아이 딥링크(?kid=&name= 원터치). InstallGuide 신규(카톡 금지·문자·홈화면). version 1.4.12.
- DB: phase5b_parent_name_and_guardian_selfserve.

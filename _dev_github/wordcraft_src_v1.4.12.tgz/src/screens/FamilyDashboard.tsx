import { useEffect, useState } from 'react'
import {
  getAuthUser, guardianFamily, guardianAddLearner, joinFamily, signOut,
  fetchLearnerById, kidConnectLink, type GuardianFamily, type Learner,
} from '../lib/supabase'
import { AdminPage } from './AdminPage'
import { InstallGuide } from './InstallGuide'

/** v2 다가구 — 보호자(부모) 대시보드.
 *  ① 미가입 → 가족 코드로 보호자 연결 ② 가입됨 → 우리 아이 관리(추가·아이별 링크 복사·설치안내·관제실). */
const RELATIONS = ['아빠', '엄마', '할아버지', '할머니'] as const

export function FamilyDashboard() {
  const [phase, setPhase] = useState<'loading' | 'join' | 'dash'>('loading')
  const [fam, setFam] = useState<GuardianFamily | null>(null)
  const [selected, setSelected] = useState<Learner | null>(null)
  const [code, setCode] = useState('')
  const [relation, setRelation] = useState<string>('아빠')
  const [addNick, setAddNick] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  const [copied, setCopied] = useState<string | null>(null)
  const [guideFor, setGuideFor] = useState<string | null>(null)

  async function load() {
    setErr(null)
    const user = await getAuthUser()
    if (!user || user.is_anonymous) { setPhase('join'); setErr('로그인이 필요해요. 다시 로그인해줘!'); return }
    try {
      const f = await guardianFamily()
      if (!f) setPhase('join')
      else { setFam(f); setPhase('dash') }
    } catch { setErr('가족 정보를 불러오지 못했어요.'); setPhase('join') }
  }
  useEffect(() => { void load() }, [])

  async function connectGuardian() {
    setBusy(true); setErr(null)
    try { await joinFamily(code.trim(), 'guardian', relation); await load() }
    catch { setErr('연결에 실패했어요. 가족 코드를 다시 확인해줘!') }
    setBusy(false)
  }
  async function addKid() {
    if (!addNick.trim()) return
    setBusy(true); setErr(null)
    try { await guardianAddLearner(addNick.trim()); setAddNick(''); await load() }
    catch { setErr('아이 추가 실패 — 다시 시도해줘.') }
    setBusy(false)
  }
  async function openKid(id: string) {
    setBusy(true)
    try { const l = await fetchLearnerById(id); if (l) setSelected(l) } catch { /* */ }
    setBusy(false)
  }
  function copy(text: string, tag: string) {
    try { void navigator.clipboard.writeText(text); setCopied(tag); setTimeout(() => setCopied(null), 1600) } catch { /* */ }
  }
  async function logout() { setBusy(true); try { await signOut() } catch { /* */ } location.hash = ''; location.reload() }

  // 아이 관제실
  if (selected) return <AdminPage learner={selected} onExit={() => setSelected(null)} />

  if (phase === 'loading') return <div className="center-box"><div className="diag-big">👨‍👩‍👧</div><p>가족 정보를 불러오는 중…</p></div>

  if (phase === 'join') return (
    <div className="center-box">
      <div className="diag-big">👨‍👩‍👧</div>
      <h2>우리 가족 연결하기</h2>
      <p>받으신 <b>가족 코드</b>를 입력해줘!</p>
      <input value={code} onChange={(e: { target: { value: string } }) => setCode(e.target.value.toUpperCase())} placeholder="예: JINYOUNG-3607"
        style={{ width: '100%', maxWidth: 320, padding: '12px 14px', fontSize: 18, textAlign: 'center', letterSpacing: 1, borderRadius: 12, border: '1px solid #2a3a4f', background: '#0f1a28', color: '#eaf1fa', margin: '8px 0' }} />
      <p style={{ margin: '6px 0 2px', opacity: 0.85 }}>나는 아이의…</p>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center', margin: '4px 0 10px' }}>
        {RELATIONS.map(r => <button key={r} className={`btn ${relation === r ? 'primary' : 'ghost'}`} onClick={() => setRelation(r)}>{r}</button>)}
      </div>
      <button className="btn primary wide" disabled={busy || !code.trim()} onClick={connectGuardian}>{busy ? '연결 중…' : '가족 연결 →'}</button>
      {err && <p style={{ color: '#ff8f7e', marginTop: 10 }}>{err}</p>}
      <button className="btn ghost wide" disabled={busy} onClick={logout}>로그아웃</button>
    </div>
  )

  // phase === 'dash'
  const inputStyle = { padding: '10px 12px', fontSize: 15, borderRadius: 10, border: '1px solid #2a3a4f', background: '#0f1a28', color: '#eaf1fa' } as const
  return (
    <div style={{ maxWidth: 680, margin: '0 auto', padding: '16px 14px 60px' }}>
      <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
        <h1 style={{ fontSize: 20, margin: 0 }}>👨‍👩‍👧 {fam?.name || '우리 가족'}</h1>
        <button className="btn ghost" onClick={logout}>로그아웃</button>
      </header>
      <p style={{ opacity: 0.8, fontSize: 13, marginTop: 0 }}>{fam?.parent_name ? <>보호자: <b>{fam.parent_name}</b> · </> : null}아이를 추가하고, 각 아이의 <b>링크를 문자로</b> 보내주세요.</p>

      {/* 아이 추가 */}
      <section style={{ background: '#111b28', border: '1px solid #21324a', borderRadius: 14, padding: 14, margin: '10px 0' }}>
        <h3 style={{ margin: '0 0 8px' }}>➕ 아이 추가</h3>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <input style={{ ...inputStyle, flex: '1 1 180px' }} placeholder="아이 이름 (예: 찬영)" value={addNick} onChange={(e: { target: { value: string } }) => setAddNick(e.target.value)} />
          <button className="btn primary" disabled={busy || !addNick.trim()} onClick={addKid}>추가</button>
        </div>
      </section>

      {err && <p style={{ color: '#ff8f7e' }}>{err}</p>}

      {/* 아이 목록 */}
      {(!fam || fam.learners.length === 0)
        ? <p style={{ opacity: 0.7 }}>아직 등록된 아이가 없어요. 위에서 아이를 추가해줘!</p>
        : fam.learners.map(l => {
          const link = kidConnectLink(l.id, l.nickname)
          const sms = `${l.nickname}아, 아래 링크 눌러서 영어 게임 시작하자!\n${link}\n\n※ 카톡 말고 문자로 열고, "홈 화면에 추가"하면 소리도 잘 나와요.`
          return (
            <section key={l.id} style={{ background: '#0f1a28', border: '1px solid #21324a', borderRadius: 14, padding: 14, margin: '10px 0' }}>
              <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', flexWrap: 'wrap', gap: 6 }}>
                <h3 style={{ margin: 0 }}>🧒 {l.nickname}</h3>
                <span style={{ opacity: 0.7, fontSize: 13 }}>Lv.{l.level} · {l.xp.toLocaleString()} XP</span>
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', margin: '10px 0 4px' }}>
                <button className="btn primary" onClick={() => copy(sms, 'sms-' + l.id)}>{copied === 'sms-' + l.id ? '복사됨 ✓ (문자 붙여넣기)' : '📩 초대 문자 복사'}</button>
                <button className="btn ghost" onClick={() => copy(link, 'link-' + l.id)}>{copied === 'link-' + l.id ? '복사됨 ✓' : '링크만 복사'}</button>
                <button className="btn secondary" disabled={busy} onClick={() => openKid(l.id)}>📊 관제실</button>
                <button className="btn ghost" onClick={() => setGuideFor(guideFor === l.id ? null : l.id)}>{guideFor === l.id ? '가이드 닫기' : '설치 안내'}</button>
              </div>
              {guideFor === l.id && <InstallGuide />}
            </section>
          )
        })}
    </div>
  )
}

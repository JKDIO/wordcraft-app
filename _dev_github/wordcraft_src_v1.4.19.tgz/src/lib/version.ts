// 앱 버전 + 원격 업데이트 체크 — 서버 /version.json과 비교
// 배포 시 반드시 APP_VERSION과 dist/version.json의 version을 함께 올릴 것 (RELEASE_LOG 규칙)
export const APP_VERSION = '1.4.19'

export interface VersionInfo {
  version: string; date?: string; notes?: string
  /** v1.4.16 — 단어 대륙 입구 스위치. 음원 전수 파형 감사(L22) PASS 후 서버에서 true로 바꾸면
   *  앱 재배포 없이 예한이에게 입구가 열린다. 미설정(undefined)이면 닫힘으로 본다. */
  vocab_ready?: boolean
}

/** a가 b보다 최신이면 true (semver 단순 비교) */
export function isNewer(a: string, b: string): boolean {
  const A = String(a).split('.').map(x => parseInt(x, 10) || 0)
  const B = String(b).split('.').map(x => parseInt(x, 10) || 0)
  const len = Math.max(A.length, B.length)
  for (let i = 0; i < len; i++) {
    const x = A[i] || 0, y = B[i] || 0
    if (x > y) return true
    if (x < y) return false
  }
  return false
}

// ── v1.4.16 단어 대륙 (Vocabulary Continent) ──────────────────────────────
// GIU Basic 전체 + 중학 전 과정을 덮는 2,400단어를 10티어 × 20팩 × 12단어로 운영하는 어휘 엔진.
//
// 설계 근거(마스터 블루프린트 20원리):
//   ① 인출 연습  — 모든 모드가 "꺼내보기". 읽고 넘기는 화면은 학습 카드 1장뿐이다.
//   ② 간격 반복  — 팩을 끝내면 12장이 전부 라이트너 복습 카드로 들어간다.
//   ③ 교차 연습  — 한 단어를 같은 모드로 반복하지 않는다. 매 문항 모드가 바뀐다.
//   ④ 이중 부호화 — 단어마다 음원 + 예문 + 이모지.
//   ⑧ i+1        — 팩은 12개, 그중 이미 아는 것은 사전 스캔에서 걸러 실제 새 단어만 남긴다.
//   ⑨ 정서 필터  — 아는 단어를 억지로 다시 시키지 않는다(지루함이 이탈의 1순위 원인).
//   ⑯ 자기결정   — 다음 팩을 하나로 강제하지 않고 열린 팩 중에서 고르게 한다.
//   ⑱ 바람직한 어려움 — 힌트는 3단계(초성 → 첫 글자 → 연상 단서)로 늦게 준다.
//
// 스키마 변경 0 (L17 additive): 팩 진도는 기존 module_progress에 module_id='V3-07' 형태로 기록하고,
// 복습 카드는 card_id='vocab:<단어>'로 기존 review_cards에 넣는다. 새 테이블·새 컬럼 없음.

export interface VocabWord {
  w: string
  ko: string
  pos: string
  ipa: string
  ex: string
  ex_ko: string
  hint_ko: string
  distractors: string[]
  tags?: string[]
  /** 빌드가 주입하는 음원 (단어 / 예문). 없으면 playClip이 TTS로 폴백한다(L19·L21⑤). */
  audio_url?: string
  audio_ex_url?: string
  tts?: string
}

export interface VocabPack {
  pack_id: string
  tier: number
  theme_ko: string
  title_ko: string
  emoji: string
  intro_ko: string
  words: VocabWord[]
}

export interface VocabTier {
  tier: number
  name_ko: string
  concept_ko: string
  packs: string[]
}

export interface VocabData {
  version: number
  tiers: VocabTier[]
  packs: Record<string, VocabPack>
}

// ── 데이터 로딩 (지연 로드 — 단어 대륙에 들어갈 때만 받는다) ──
let _cache: VocabData | null = null
let _inflight: Promise<VocabData> | null = null
export function loadVocab(): Promise<VocabData> {
  if (_cache) return Promise.resolve(_cache)
  if (_inflight) return _inflight
  _inflight = fetch('/vocab.json', { cache: 'default' })
    .then(r => { if (!r.ok) throw new Error('vocab ' + r.status); return r.json() as Promise<VocabData> })
    .then(d => { _cache = d; return d })
    .finally(() => { _inflight = null })
  return _inflight
}
export function vocabCached(): VocabData | null { return _cache }

// ── 잠금 규칙 ────────────────────────────────────────────────
// 티어 1은 항상 열림. 티어 N은 티어 N-1의 팩을 16/20(80%) 이상 끝내면 열린다.
// 팩은 "앞에서부터 순서대로"가 아니라 **열린 팩 중에서 고르게** 한다(자율성).
// 구체적으로: 그 티어에서 아직 안 끝낸 팩 중 앞에서부터 3개가 동시에 열린다.
export const TIER_UNLOCK_RATIO = 0.8
export const OPEN_PACK_WINDOW = 3

export type PackState = 'done' | 'open' | 'locked'
type ProgressLike = Record<string, { status?: string } | undefined>

export function isPackDone(progress: ProgressLike, packId: string): boolean {
  const st = progress[packId]?.status
  return st === 'completed' || st === 'mastered'
}

export function tierDoneCount(progress: ProgressLike, tier: VocabTier): number {
  return tier.packs.filter(p => isPackDone(progress, p)).length
}

export function isTierOpen(progress: ProgressLike, tiers: VocabTier[], tier: number): boolean {
  if (tier <= 1) return true
  const prev = tiers.find(t => t.tier === tier - 1)
  if (!prev) return true
  return tierDoneCount(progress, prev) >= Math.ceil(prev.packs.length * TIER_UNLOCK_RATIO)
}

/** 티어 안에서 각 팩의 상태 — 안 끝낸 팩 중 앞 3개가 열린다. */
export function packStates(progress: ProgressLike, tiers: VocabTier[], tier: VocabTier): Record<string, PackState> {
  const out: Record<string, PackState> = {}
  const open = isTierOpen(progress, tiers, tier.tier)
  let opened = 0
  for (const p of tier.packs) {
    if (isPackDone(progress, p)) { out[p] = 'done'; continue }
    if (open && opened < OPEN_PACK_WINDOW) { out[p] = 'open'; opened++ }
    else out[p] = 'locked'
  }
  return out
}

// ── 문항 생성 ────────────────────────────────────────────────
// 5개 모드. 한 단어를 연속으로 같은 모드에 내지 않는다(교차 연습).
export type VocabMode =
  | 'meaning'   // 뜻 사냥 — 영어를 보고 한국어 뜻 고르기
  | 'listen'    // 소리 낚시 — 음원을 듣고 영어 단어 고르기
  | 'gap'       // 문장 구멍 — 예문의 빈칸에 들어갈 단어 고르기
  | 'spell'     // 철자 대장간 — 글자 타일을 순서대로 눌러 조립
  | 'recall'    // 한→영 소환 — 한국어를 보고 영어 고르기 (가장 어려운 인출)
  | 'speak'     // 소리 지르기 — 듣고 따라 말하기 (출력 가설, 블루프린트 원리 10)

export const MODE_LABEL: Record<VocabMode, string> = {
  meaning: '뜻 사냥', listen: '소리 낚시', gap: '문장 구멍',
  spell: '철자 대장간', recall: '한→영 소환', speak: '소리 지르기',
}
export const MODE_EMOJI: Record<VocabMode, string> = {
  meaning: '🎯', listen: '🎣', gap: '🧩', spell: '🔨', recall: '🪄', speak: '📣',
}

// ── v1.4.19 티어별 모드 해금 ──────────────────────────────────
// 왜: v1.4.18까지 1번 팩과 200번 팩의 구조가 완전히 같았다. 새로 열리는 게 없으면 계속할 이유가 없다.
// 티어가 오를 때마다 **새로운 하는 법**이 하나씩 열린다.
export const MODE_UNLOCK: { tier: number; mode: VocabMode; name: string }[] = [
  { tier: 1, mode: 'meaning', name: '뜻 사냥' },
  { tier: 1, mode: 'listen',  name: '소리 낚시' },
  { tier: 1, mode: 'spell',   name: '철자 대장간' },  // T1부터 — 첫 구역이 '탭만' 되면 첫인상이 죽는다
  { tier: 2, mode: 'recall',  name: '한→영 소환' },
  { tier: 3, mode: 'speak',   name: '소리 지르기' },
  { tier: 4, mode: 'gap',     name: '문장 구멍' },
]

/** 손가락이 '4개 중 하나 탭'만 하는 모드 — 이 비율이 높으면 이름만 다르고 같은 게임이다. */
const TAP_MODES: VocabMode[] = ['meaning', 'listen', 'recall', 'gap']
/** 탭이 아닌 행동(조립·발화) */
const ACTIVE_MODES: VocabMode[] = ['spell', 'speak']
/** 이 티어에서 쓸 수 있는 모드들 */
export function modesForTier(tier: number): VocabMode[] {
  return MODE_UNLOCK.filter(u => u.tier <= tier).map(u => u.mode)
}
/** 이 티어에서 **새로** 열린 모드 (팩 시작 화면에서 알려준다) */
export function newModeAtTier(tier: number): { mode: VocabMode; name: string } | null {
  const u = MODE_UNLOCK.filter(x => x.tier === tier)
  return u.length && tier > 1 ? { mode: u[0].mode, name: u[0].name } : null
}

export interface VocabQuestion {
  id: string
  mode: VocabMode
  word: VocabWord
  prompt: string          // 화면에 보여줄 문제 텍스트
  promptKo?: string       // 보조 설명
  options: string[]       // 4지선다 (spell 모드는 비어 있음)
  answer: string
  play?: { audio_url?: string; tts?: string }  // 자동/수동 재생 대상
  hints: string[]         // 3단계 힌트
}

function shuffle<T>(arr: T[], seed: number): T[] {
  const a = arr.slice()
  let s = (seed || 1) >>> 0
  for (let i = a.length - 1; i > 0; i--) {
    // ⚠️ 2^31 모듈러 LCG의 **하위 비트는 주기가 짧다**(s % 4는 사실상 4주기로 반복).
    //    그대로 j = s % (i+1)을 쓰면 4지선다에서 정답 위치가 규칙적으로 몰려
    //    아이가 내용이 아니라 "위치"를 외워버린다(v1.4.16 스모크에서 18문항 연속 편향으로 적발).
    //    → xorshift로 비트를 섞고 상위 비트를 쓴다.
    s ^= s << 13; s >>>= 0
    s ^= s >>> 17
    s ^= s << 5; s >>>= 0
    const j = Math.floor((s / 4294967296) * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}
function hashOf(str: string): number {
  let h = 0
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 2147483647
  return h
}

/** 같은 팩의 다른 단어들에서 한국어 오답을 뽑는다 — 같은 의미장이라 자연스럽게 헷갈린다. */
function koDistractors(pack: VocabPack, w: VocabWord, seed: number): string[] {
  const pool = pack.words.filter(x => x.w !== w.w && x.ko !== w.ko).map(x => x.ko)
  return shuffle(pool, seed).slice(0, 3)
}

/** 철자 대장간 — 단어의 일부 글자를 가린다(길이에 비례, 최소 1개). */
function maskWord(w: string, seed: number): { masked: string; missing: string } {
  const letters = w.split('')
  const idxs = letters.map((c, i) => (/[a-z]/i.test(c) ? i : -1)).filter(i => i >= 0)
  const n = Math.max(1, Math.min(3, Math.floor(idxs.length / 4)))
  const pick = shuffle(idxs, seed).slice(0, n).sort((a, b) => a - b)
  const masked = letters.map((c, i) => (pick.includes(i) ? '_' : c)).join('')
  return { masked, missing: pick.map(i => letters[i]).join('') }
}

/** 철자 타일용 미끼 글자 — 정답 글자와 헷갈릴 만한 인접 알파벳 */
function decoyLetters(missing: string, seed: number): string[] {
  const alphabet = 'abcdefghijklmnopqrstuvwxyz'.split('')
  const near = missing.split('').flatMap(ch => {
    const i = alphabet.indexOf(ch.toLowerCase())
    return i < 0 ? [] : [alphabet[(i + 3) % 26], alphabet[(i + 20) % 26]]
  })
  const n = Math.max(2, Math.min(4, missing.length + 1))
  return shuffle(Array.from(new Set(near)), seed).slice(0, n)
}

function playOf(w: VocabWord): { audio_url?: string; tts?: string } {
  return { audio_url: w.audio_url, tts: w.tts || w.w }
}
function playExOf(w: VocabWord): { audio_url?: string; tts?: string } {
  return { audio_url: w.audio_ex_url || w.audio_url, tts: w.ex }
}

export function buildQuestion(pack: VocabPack, w: VocabWord, mode: VocabMode, nonce: number): VocabQuestion {
  const seed = hashOf(w.w + mode) + nonce
  const base = { id: `${pack.pack_id}:${w.w}:${mode}`, mode, word: w }
  const hint3 = [
    `${w.pos === 'n' ? '이름을 나타내는 말(명사)' : w.pos === 'v' ? '움직임을 나타내는 말(동사)' : w.pos === 'adj' ? '꾸며주는 말(형용사)' : w.pos === 'adv' ? '동사를 돕는 말(부사)' : '기능을 하는 말'}이야.`,
    `첫 글자는 "${w.w[0]}" 로 시작해.`,
    w.hint_ko,
  ]
  switch (mode) {
    case 'meaning': {
      const opts = shuffle([w.ko, ...koDistractors(pack, w, seed)], seed)
      return { ...base, prompt: w.w, promptKo: '무슨 뜻일까?', options: opts, answer: w.ko, play: playOf(w), hints: hint3 }
    }
    case 'listen': {
      const opts = shuffle([w.w, ...w.distractors.slice(0, 3)], seed)
      return { ...base, prompt: '🔊', promptKo: '잘 듣고 어떤 단어인지 골라!', options: opts, answer: w.w, play: playOf(w), hints: hint3 }
    }
    case 'gap': {
      const re = new RegExp(`\\b${w.w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i')
      const blanked = re.test(w.ex) ? w.ex.replace(re, '_____') : w.ex
      const opts = shuffle([w.w, ...w.distractors.slice(0, 3)], seed)
      return { ...base, prompt: blanked, promptKo: w.ex_ko, options: opts, answer: w.w, play: playExOf(w), hints: hint3 }
    }
    case 'spell': {
      // v1.4.19: 빈칸 타이핑 → **글자 타일 조립**. 모바일에서 키보드가 올라오지 않고, 손이 하는 일이 달라진다.
      const { masked, missing } = maskWord(w.w, seed)
      const pool = shuffle([...missing.split(''), ...decoyLetters(missing, seed)], seed + 7)
      return {
        ...base, prompt: masked, promptKo: `${w.ko} — 빠진 글자를 순서대로 눌러!`,
        options: pool, answer: missing, play: playOf(w), hints: hint3,
      }
    }
    case 'speak': {
      // 출력 가설(원리 10). 채점은 아이 스스로 — 정직하게 고르게 하고 감점은 없다.
      return {
        ...base, prompt: w.w, promptKo: `듣고 세 번 따라 말해봐! (${w.ko})`,
        options: [], answer: w.w, play: playOf(w), hints: hint3,
      }
    }
    case 'recall':
    default: {
      const opts = shuffle([w.w, ...w.distractors.slice(0, 3)], seed)
      return { ...base, prompt: w.ko, promptKo: '영어로는?', options: opts, answer: w.w, play: playOf(w), hints: hint3 }
    }
  }
}

/** 한 팩의 플레이 문항 목록.
 *  · 모르는 단어  = 서로 다른 모드 2문항 (교차 연습)
 *  · 아는 단어    = 확인용 1문항 (지루하지 않게 딱 한 번)
 *  · 같은 단어가 연달아 나오지 않도록 섞는다.
 *  · 총 문항 수는 28개를 넘지 않게 자른다(집중 15~20분 안에 끝나야 한다). */
export const MAX_QUESTIONS = 28

/** v1.4.19 — 그 티어에서 열린 모드만으로 짝을 만든다.
 *  같은 단어를 **서로 다른 두 방식**으로 인출하게 해야 교차 연습이 실제로 일어난다
 *  (v1.4.18까지는 이름만 다르고 83%가 '4개 중 탭'이었다). */
function modePairsFor(tier: number): VocabMode[][] {
  const avail = modesForTier(tier)
  const taps = TAP_MODES.filter(m => avail.includes(m))
  const acts = ACTIVE_MODES.filter(m => avail.includes(m))
  if (!acts.length) return taps.length > 1 ? [[taps[0], taps[1]]] : [['meaning', 'listen']]
  // ★핵심 규칙★ 한 단어의 두 문항은 **반드시 서로 다른 종류의 행동**이어야 한다.
  //   고르기(탭) 하나 + 조립/말하기 하나 → 팩 전체의 탭 비율이 자동으로 50%가 된다.
  //   (v1.4.18까지는 이름만 다르고 83%가 탭이었다 — Dio님이 "진부하다"고 느낀 실체.)
  const pairs: VocabMode[][] = []
  for (const t of taps) for (const a of acts) pairs.push([t, a])
  return pairs
}

/** 한 팩의 플레이 문항 목록.
 *  · 모르는 단어  = 서로 다른 모드 2문항 (교차 연습)
 *  · 아는 단어    = 확인용 1문항 (지루하지 않게 딱 한 번)
 *  · 같은 단어가 연달아 나오지 않도록 섞는다.
 *  · 총 문항 수는 28개를 넘지 않게 자른다(집중 15~20분 안에 끝나야 한다). */
export function buildSession(pack: VocabPack, knownWords: string[]): VocabQuestion[] {
  const known = new Set(knownWords)
  const pairs = modePairsFor(pack.tier)
  const avail = modesForTier(pack.tier)
  const confirmModes: VocabMode[] = avail.includes('recall') ? ['meaning', 'recall'] : ['meaning', 'listen']
  const qs: VocabQuestion[] = []
  pack.words.forEach((w, i) => {
    if (known.has(w.w)) {
      qs.push(buildQuestion(pack, w, confirmModes[i % confirmModes.length], i))
    } else {
      pairs[i % pairs.length].forEach((m, k) => qs.push(buildQuestion(pack, w, m, i * 10 + k)))
    }
  })
  // 같은 단어가 붙어 나오지 않도록 재배치
  const mixed = shuffle(qs, hashOf(pack.pack_id))
  for (let i = 1; i < mixed.length; i++) {
    if (mixed[i].word.w === mixed[i - 1].word.w) {
      const j = mixed.findIndex((q, k) => k > i && q.word.w !== mixed[i - 1].word.w && q.word.w !== (mixed[i + 1]?.word.w))
      if (j > 0) { const t = mixed[i]; mixed[i] = mixed[j]; mixed[j] = t }
    }
  }
  return mixed.slice(0, MAX_QUESTIONS)
}

/** 팩 결과 → 별점 (모듈과 같은 기준: 90+ ★★★ / 70+ ★★ / 그 외 0) */
export function starsFor(pct: number): number {
  if (pct >= 90) return 3
  if (pct >= 70) return 2
  return 0
}

/** 복습 카드 시드 — 팩의 12단어를 라이트너에 넣는다.
 *  아는 단어(사전 스캔 통과)는 박스 3부터 시작해 불필요한 반복을 건너뛴다. */
export function reviewCardsFor(pack: VocabPack, knownWords: string[]): {
  card_id: string; card_front: string; card_back: string; box: number; tts: string
}[] {
  const known = new Set(knownWords)
  return pack.words.map(w => ({
    card_id: `vocab:${w.w}`,
    card_front: w.w,
    card_back: `${w.ko}\n${w.ex}`,
    box: known.has(w.w) ? 3 : 1,
    tts: w.tts || w.w,
  }))
}

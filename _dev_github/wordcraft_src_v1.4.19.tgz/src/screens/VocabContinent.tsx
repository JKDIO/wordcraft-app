// v1.4.16 단어 대륙 🗺️ — 어휘 엔진 화면.
// 흐름: 대륙 지도(티어 아코디언) → 팩 선택 → ① 사전 스캔 → ② 학습 카드 → ③ 게임 5종 → ④ 결과
// 기록: activity_type='vocab', module_id=<pack_id> (기존 스키마 그대로 — L17 additive)
import { useEffect, useMemo, useRef, useState } from 'react'
import {
  loadVocab, buildSession, packStates, isTierOpen, tierDoneCount, starsFor, reviewCardsFor,
  MODE_LABEL, MODE_EMOJI, newModeAtTier,
  type VocabData, type VocabPack, type VocabQuestion, type VocabWord,
} from '../lib/vocab'
import { playClip, stopAudio } from '../lib/audio'
import type { LocalState } from '../lib/store'

export interface VocabResult {
  packId: string
  total: number
  correct: number
  pct: number
  stars: number
  known: string[]
  pack: VocabPack
}

const OPEN_KEY = 'wordcraft_vocab_tier_open_v1'

export function VocabContinent(props: {
  state: LocalState
  onAnswer: (packId: string, q: VocabQuestion, correct: boolean, ms: number) => void
  onPackDone: (r: VocabResult) => void
  onExit: () => void
}) {
  const [data, setData] = useState<VocabData | null>(null)
  const [err, setErr] = useState(false)
  const [pack, setPack] = useState<VocabPack | null>(null)

  useEffect(() => {
    loadVocab().then(setData).catch(() => setErr(true))
    return () => stopAudio()
  }, [])

  if (err) return (
    <div className="center-box">
      <div className="diag-big">🗺️</div>
      <h2>단어 대륙에 안개가 꼈어</h2>
      <p>지도를 못 불러왔어. 잠시 뒤에 다시 들어와 줘!</p>
      <button className="btn ghost wide" onClick={props.onExit}>← 월드맵으로</button>
    </div>
  )
  if (!data) return <div className="center-box"><div className="diag-big">🗺️</div><p>단어 대륙 지도를 펼치는 중…</p></div>

  if (pack) return (
    <PackSession
      pack={pack}
      onAnswer={props.onAnswer}
      onDone={r => { props.onPackDone(r); setPack(null) }}
      onExit={() => setPack(null)}
    />
  )

  return <ContinentMap data={data} state={props.state} onPick={setPack} onExit={props.onExit} />
}

// ── 대륙 지도 ────────────────────────────────────────────────
function ContinentMap(props: {
  data: VocabData; state: LocalState
  onPick: (p: VocabPack) => void; onExit: () => void
}) {
  const { data, state } = props
  const [open, setOpen] = useState<Record<number, boolean>>(() => {
    try { const raw = localStorage.getItem(OPEN_KEY); if (raw) return JSON.parse(raw) as Record<number, boolean> } catch { /* */ }
    // 저장값이 없으면 "지금 할 티어"만 펼친다
    const init: Record<number, boolean> = {}
    let picked = false
    for (const t of data.tiers) {
      const done = tierDoneCount(state.progress, t)
      const isCur = !picked && isTierOpen(state.progress, data.tiers, t.tier) && done < t.packs.length
      if (isCur) picked = true
      init[t.tier] = isCur
    }
    return init
  })
  useEffect(() => { try { localStorage.setItem(OPEN_KEY, JSON.stringify(open)) } catch { /* */ } }, [open])

  const totalDone = data.tiers.reduce((a, t) => a + tierDoneCount(state.progress, t), 0)
  const totalWords = totalDone * 12

  return (
    <div className="worldmap" style={{ paddingBottom: 70 }}>
      <header className="topbar">
        <div className="topbar-left">
          <button className="btn ghost" style={{ padding: '4px 10px' }} onClick={props.onExit}>←</button>
          <div><b>🗺️ 단어 대륙</b><span className="level-tag">2,400 단어의 땅</span></div>
        </div>
        <div className="topbar-right" style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <button className="btn ghost" style={{ padding: '4px 10px', fontSize: 12 }}
            onClick={() => { location.hash = '/dex' }}>🗂️ 도감</button>
          <span className="xp-chip">📚 {totalWords.toLocaleString()}</span>
        </div>
      </header>

      <div style={{ background: '#0f1a28', border: '1px solid #21324a', borderRadius: 14, padding: 12, margin: '8px 0 12px' }}>
        <div style={{ height: 8, background: '#1b2a3d', borderRadius: 99, overflow: 'hidden' }}>
          <div style={{ width: `${Math.round((totalDone / 200) * 100)}%`, height: '100%', background: 'linear-gradient(90deg,#4a9eff,#3ddc84)' }} />
        </div>
        <p style={{ margin: '8px 0 0', fontSize: 13, opacity: 0.85 }}>
          {totalDone === 0
            ? '첫 발자국을 찍어보자! 티어 1은 네가 이미 아는 단어들이야 — 워밍업이지 시험이 아니야 😎'
            : `${totalDone}/200 구역 정복 · 잡은 단어 ${totalWords.toLocaleString()}개. 이 속도면 중학교 단어는 이미 네 거야.`}
        </p>
      </div>

      {data.tiers.map(t => {
        const unlocked = isTierOpen(state.progress, data.tiers, t.tier)
        const done = tierDoneCount(state.progress, t)
        const isOpen = open[t.tier] !== false && unlocked
        const st = packStates(state.progress, data.tiers, t)
        return (
          <section key={t.tier} className="world">
            <h2
              className="world-title"
              style={{ cursor: unlocked ? 'pointer' : 'default', display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', opacity: unlocked ? 1 : 0.55 }}
              onClick={() => unlocked && setOpen(p => ({ ...p, [t.tier]: !isOpen }))}
            >
              <span style={{ display: 'inline-block', width: 14, transform: isOpen ? 'rotate(90deg)' : 'none', opacity: 0.8 }}>▶</span>
              {unlocked ? '🏳️' : '🔒'} T{t.tier} — {t.name_ko}
              <span style={{ fontSize: 12, fontWeight: 400, opacity: 0.75 }}>{done}/{t.packs.length}</span>
            </h2>

            {!unlocked && (
              <p className="world-locked-note">앞 구역을 {Math.ceil(t.packs.length * 0.8)}개 정복하면 열려! 지금 구역부터 차근차근 💪</p>
            )}

            {unlocked && !isOpen && (
              <button
                onClick={() => setOpen(p => ({ ...p, [t.tier]: true }))}
                style={{ display: 'block', width: '100%', textAlign: 'left', cursor: 'pointer', background: '#0f1a28', border: '1px solid #21324a', borderRadius: 14, padding: '10px 12px', margin: '4px 0 10px', color: '#eaf1fa', font: 'inherit' }}
              >
                <div style={{ height: 6, background: '#1b2a3d', borderRadius: 99, overflow: 'hidden', marginBottom: 8 }}>
                  <div style={{ width: `${Math.round((done / t.packs.length) * 100)}%`, height: '100%', background: done === t.packs.length ? '#3ddc84' : '#4a9eff', borderRadius: 99 }} />
                </div>
                <span style={{ fontSize: 12, opacity: 0.85 }}>{t.concept_ko} · {done * 12}단어 확보</span>
              </button>
            )}

            {unlocked && isOpen && (
              <>
                <p style={{ fontSize: 12, opacity: 0.7, margin: '2px 0 8px' }}>{t.concept_ko}</p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(150px,1fr))', gap: 8 }}>
                  {t.packs.map(pid => {
                    const p = props.data.packs[pid]
                    if (!p) return null
                    const s = st[pid]
                    return (
                      <button
                        key={pid}
                        disabled={s === 'locked'}
                        onClick={() => props.onPick(p)}
                        style={{
                          textAlign: 'left', cursor: s === 'locked' ? 'default' : 'pointer', font: 'inherit',
                          background: s === 'done' ? '#0e2a1c' : s === 'open' ? '#12243a' : '#141c27',
                          border: `1px solid ${s === 'done' ? '#2c6b48' : s === 'open' ? '#2f5c8f' : '#232c3a'}`,
                          borderRadius: 12, padding: '10px 11px', color: s === 'locked' ? '#5d6b7d' : '#eaf1fa',
                        }}
                      >
                        <div style={{ fontSize: 20, lineHeight: 1.1 }}>{s === 'locked' ? '🔒' : p.emoji}</div>
                        <div style={{ fontSize: 13, fontWeight: 700, marginTop: 4 }}>{p.title_ko}</div>
                        <div style={{ fontSize: 11, opacity: 0.7, marginTop: 2 }}>{p.theme_ko} · 12단어</div>
                        <div style={{ fontSize: 11, marginTop: 6, opacity: 0.9 }}>
                          {s === 'done' ? '✅ 정복' : s === 'open' ? '▶ 도전' : '잠김'}
                        </div>
                      </button>
                    )
                  })}
                </div>
              </>
            )}
          </section>
        )
      })}
    </div>
  )
}

// ── 팩 세션 ──────────────────────────────────────────────────
type Phase = 'scan' | 'learn' | 'play' | 'result'

function PackSession(props: {
  pack: VocabPack
  onAnswer: (packId: string, q: VocabQuestion, correct: boolean, ms: number) => void
  onDone: (r: VocabResult) => void
  onExit: () => void
}) {
  const { pack } = props
  const [phase, setPhase] = useState<Phase>('scan')
  const [known, setKnown] = useState<string[]>([])
  const [scanIdx, setScanIdx] = useState(0)
  const [learnIdx, setLearnIdx] = useState(0)
  const [qs, setQs] = useState<VocabQuestion[]>([])
  const [qi, setQi] = useState(0)
  const [correct, setCorrect] = useState(0)
  const [picked, setPicked] = useState<string | null>(null)
  const [tiles, setTiles] = useState<string[]>([])   // v1.4.19 철자 대장간 — 누른 글자 타일 순서
  const [hintLv, setHintLv] = useState(0)
  const startedAt = useRef<number>(Date.now())

  useEffect(() => () => stopAudio(), [])

  const unknown = useMemo(() => pack.words.filter(w => !known.includes(w.w)), [pack, known])

  // ① 사전 스캔 — "아는 단어는 건너뛴다". 지루함이 이탈의 1순위 원인이라 반드시 먼저 거른다.
  if (phase === 'scan') {
    const w = pack.words[scanIdx]
    const next = (isKnown: boolean) => {
      if (isKnown) setKnown(k => [...k, w.w])
      if (scanIdx + 1 >= pack.words.length) {
        const rest = pack.words.filter(x => !(isKnown ? [...known, w.w] : known).includes(x.w))
        setPhase(rest.length ? 'learn' : 'play')
        if (!rest.length) { setQs(buildSession(pack, isKnown ? [...known, w.w] : known)); startedAt.current = Date.now() }
      } else setScanIdx(scanIdx + 1)
    }
    return (
      <div className="center-box">
        <SessionTop pack={pack} onExit={props.onExit} label={`사전 스캔 ${scanIdx + 1}/${pack.words.length}`} />
        {scanIdx === 0 && newModeAtTier(pack.tier) && (
          <div style={{
            background: '#241f10', border: '1px solid #6b5a15', borderRadius: 12,
            padding: '9px 12px', margin: '6px 0 2px', fontSize: 13,
          }}>
            🔓 <b>새로운 사냥법 해금!</b> 이 구역부터 <b>{newModeAtTier(pack.tier)!.name}</b>이(가) 나온다
          </div>
        )}
        <p style={{ opacity: 0.8, marginTop: 4 }}>이미 아는 단어는 건너뛸 거야. <b>솔직하게</b> 골라 — 맞히기 시험 아니야!</p>
        <div style={{ background: '#0f1a28', border: '1px solid #21324a', borderRadius: 16, padding: '22px 16px', margin: '14px 0' }}>
          <div style={{ fontSize: 30, fontWeight: 800, letterSpacing: 0.5 }}>{w.w}</div>
          <div style={{ opacity: 0.6, fontSize: 13, marginTop: 4 }}>/{w.ipa}/</div>
          <button className="btn ghost" style={{ marginTop: 10 }} onClick={() => playClip({ audio_url: w.audio_url, tts: w.tts || w.w })}>🔊 소리</button>
        </div>
        <button className="btn primary wide" onClick={() => next(true)}>😎 알아요 — 넘어가기</button>
        <button className="btn secondary wide" onClick={() => next(false)}>🤔 몰라요 — 배울래</button>
      </div>
    )
  }

  // ② 학습 카드 — 모르는 단어만
  if (phase === 'learn') {
    const w = unknown[learnIdx]
    if (!w) { setPhase('play'); setQs(buildSession(pack, known)); startedAt.current = Date.now(); return null }
    const last = learnIdx + 1 >= unknown.length
    return (
      <div className="center-box">
        <SessionTop pack={pack} onExit={props.onExit} label={`새 단어 ${learnIdx + 1}/${unknown.length}`} />
        <WordCard w={w} />
        <button className="btn primary wide" onClick={() => {
          if (last) { setPhase('play'); setQs(buildSession(pack, known)); startedAt.current = Date.now() }
          else setLearnIdx(learnIdx + 1)
        }}>{last ? '⚔️ 사냥 시작!' : '다음 →'}</button>
      </div>
    )
  }

  // ③ 게임
  if (phase === 'play') {
    const q = qs[qi]
    if (!q) { setPhase('result'); return null }
    const answered = picked !== null
    const isRight = answered && picked === q.answer
    const submit = (choice: string) => {
      if (answered) return
      const ok = choice.trim().toLowerCase() === q.answer.trim().toLowerCase()
      setPicked(ok ? q.answer : choice)
      if (ok) setCorrect(c => c + 1)
      props.onAnswer(pack.pack_id, q, ok, Date.now() - startedAt.current)
      if (!ok) playClip({ audio_url: q.word.audio_url, tts: q.word.tts || q.word.w })
    }
    const advance = () => {
      setPicked(null); setTiles([]); setHintLv(0); startedAt.current = Date.now()
      if (qi + 1 >= qs.length) setPhase('result'); else setQi(qi + 1)
    }
    return (
      <div className="center-box">
        <SessionTop pack={pack} onExit={props.onExit} label={`${MODE_EMOJI[q.mode]} ${MODE_LABEL[q.mode]} ${qi + 1}/${qs.length}`} />
        <div style={{ height: 6, background: '#1b2a3d', borderRadius: 99, overflow: 'hidden', margin: '6px 0 12px' }}>
          <div style={{ width: `${Math.round((qi / qs.length) * 100)}%`, height: '100%', background: '#4a9eff' }} />
        </div>

        <div style={{ background: '#0f1a28', border: '1px solid #21324a', borderRadius: 16, padding: '20px 14px' }}>
          <div style={{ fontSize: q.mode === 'gap' ? 19 : 28, fontWeight: 800, lineHeight: 1.35 }}>{q.prompt}</div>
          {q.promptKo && <div style={{ opacity: 0.75, fontSize: 14, marginTop: 8 }}>{q.promptKo}</div>}
          {q.play && <button className="btn ghost" style={{ marginTop: 12 }} onClick={() => playClip(q.play!)}>🔊 다시 듣기</button>}
        </div>

        {q.mode === 'spell' ? (
          /* v1.4.19 철자 대장간 — 키보드 대신 글자 타일. 손이 하는 일이 '탭 고르기'와 달라진다. */
          <div style={{ margin: '14px 0' }}>
            <div style={{
              fontSize: 26, fontWeight: 800, letterSpacing: 3, minHeight: 38,
              color: tiles.length ? '#eaf1fa' : '#4a5768',
            }}>{tiles.length ? tiles.join(' ') : '· · ·'}</div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center', margin: '12px 0' }}>
              {q.options.map((ch, k) => (
                <button key={ch + k} disabled={answered}
                  onClick={() => {
                    const next = [...tiles, ch]
                    setTiles(next)
                    if (next.length >= q.answer.length) submit(next.join(''))
                  }}
                  style={{
                    width: 48, height: 48, fontSize: 22, fontWeight: 800, font: 'inherit',
                    background: '#12243a', border: '2px solid #2f5c8f', borderRadius: 12,
                    color: '#eaf1fa', cursor: answered ? 'default' : 'pointer',
                  }}>{ch}</button>
              ))}
            </div>
            {!answered && tiles.length > 0 && (
              <button className="btn ghost" onClick={() => setTiles([])}>↩ 다시</button>
            )}
          </div>
        ) : q.mode === 'speak' ? (
          /* v1.4.19 소리 지르기 — 출력(원리 10). 채점은 아이 스스로, 감점 없음. */
          <div style={{ margin: '14px 0' }}>
            <p style={{ fontSize: 13, opacity: .8 }}>🔊를 누르고 <b>세 번</b> 크게 따라 말해봐!</p>
            {!answered && (
              <div style={{ display: 'grid', gap: 8, marginTop: 10 }}>
                <button className="btn primary" onClick={() => submit(q.answer)}>📣 말했어! 다음</button>
                <button className="btn ghost" onClick={() => submit('__skip__')}>지금은 소리 못 내 (조용히 넘기기)</button>
              </div>
            )}
          </div>
        ) : (
          <div style={{ display: 'grid', gap: 8, margin: '14px 0' }}>
            {q.options.map(o => {
              const isAns = o === q.answer
              const chosen = picked === o
              const bg = !answered ? '#12243a' : isAns ? '#0e3a24' : chosen ? '#3a1420' : '#141c27'
              const bd = !answered ? '#2f5c8f' : isAns ? '#2c8b58' : chosen ? '#7a2740' : '#232c3a'
              return (
                <button key={o} disabled={answered} onClick={() => submit(o)}
                  style={{ background: bg, border: `1px solid ${bd}`, borderRadius: 12, padding: '13px 12px', fontSize: 16, color: '#eaf1fa', font: 'inherit', cursor: answered ? 'default' : 'pointer', textAlign: 'left' }}>
                  {o}{answered && isAns ? '  ✓' : ''}
                </button>
              )
            })}
          </div>
        )}

        {!answered && (
          <div style={{ margin: '4px 0 10px' }}>
            {hintLv < 3
              ? <button className="btn ghost" onClick={() => setHintLv(hintLv + 1)}>💡 힌트 {hintLv + 1}단계</button>
              : null}
            {hintLv > 0 && (
              <div style={{ background: '#241f10', border: '1px solid #5b4a15', borderRadius: 10, padding: '8px 10px', marginTop: 8, fontSize: 13, textAlign: 'left' }}>
                {q.hints.slice(0, hintLv).map((h, i) => <div key={i}>💡 {h}</div>)}
              </div>
            )}
          </div>
        )}

        {answered && (
          <div style={{ background: isRight ? '#0e2a1c' : '#241a1f', border: `1px solid ${isRight ? '#2c6b48' : '#5b2740'}`, borderRadius: 12, padding: '12px 12px', textAlign: 'left' }}>
            <b>{isRight ? '🎯 명중!' : '💫 리스폰! (감점 없어)'}</b>
            <div style={{ marginTop: 6, fontSize: 15 }}><b>{q.word.w}</b> <span style={{ opacity: 0.7 }}>/{q.word.ipa}/</span> — {q.word.ko}</div>
            <div style={{ marginTop: 4, fontSize: 14, opacity: 0.9 }}>{q.word.ex}</div>
            <div style={{ fontSize: 13, opacity: 0.7 }}>{q.word.ex_ko}</div>
            <button className="btn primary wide" style={{ marginTop: 10 }} onClick={advance}>{qi + 1 >= qs.length ? '결과 보기 →' : '다음 →'}</button>
          </div>
        )}
      </div>
    )
  }

  // ④ 결과
  const total = qs.length || 1
  const pct = Math.round((correct / total) * 100)
  const stars = starsFor(pct)
  return (
    <div className="center-box">
      <div className="diag-big">{stars === 3 ? '👑' : stars === 2 ? '🏅' : '⛏️'}</div>
      <h2>{pack.emoji} {pack.title_ko} 정복!</h2>
      <div style={{ fontSize: 26, margin: '6px 0' }}>{'★'.repeat(stars)}<span style={{ opacity: 0.25 }}>{'★'.repeat(3 - stars)}</span></div>
      <p style={{ fontSize: 16 }}>{correct}/{total} 정답 · {pct}%</p>
      <p style={{ opacity: 0.85, fontSize: 14 }}>
        {stars === 3 ? '전략이 좋았어. 헷갈리는 걸 끝까지 붙잡고 늘어진 결과야 👏'
          : stars === 2 ? '탄탄해! 놓친 단어는 복습 광산에서 다시 만날 거야 ⛏️'
            : '오늘 만난 12단어가 전부 복습 카드로 들어갔어. 내일 다시 만나면 훨씬 쉬워질 거야 💪'}
      </p>
      <p style={{ opacity: 0.7, fontSize: 13 }}>이 팩의 12단어가 복습 광산에 저장됐어{known.length ? ` (이미 알던 ${known.length}개는 건너뛰기 처리)` : ''}.</p>
      <button className="btn primary wide" onClick={() => props.onDone({ packId: pack.pack_id, total, correct, pct, stars, known, pack })}>지도로 돌아가기 →</button>
    </div>
  )
}

function SessionTop(props: { pack: VocabPack; label: string; onExit: () => void }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', gap: 8, marginBottom: 6 }}>
      <button className="btn ghost" style={{ padding: '4px 10px' }} onClick={() => { stopAudio(); props.onExit() }}>← 나가기</button>
      <span style={{ fontSize: 12, opacity: 0.8 }}>{props.pack.emoji} {props.pack.title_ko}</span>
      <span style={{ fontSize: 12, opacity: 0.8 }}>{props.label}</span>
    </div>
  )
}

function WordCard(props: { w: VocabWord }) {
  const { w } = props
  useEffect(() => { playClip({ audio_url: w.audio_url, tts: w.tts || w.w }) }, [w.w])
  return (
    <div style={{ background: '#0f1a28', border: '1px solid #21324a', borderRadius: 16, padding: '20px 16px', margin: '12px 0', textAlign: 'left' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' }}>
        <span style={{ fontSize: 30, fontWeight: 800 }}>{w.w}</span>
        <span style={{ opacity: 0.6, fontSize: 14 }}>/{w.ipa}/</span>
        <span style={{ fontSize: 11, background: '#1b2a3d', borderRadius: 8, padding: '2px 8px' }}>{w.pos}</span>
      </div>
      <div style={{ fontSize: 19, marginTop: 8 }}>{w.ko}</div>
      <div style={{ marginTop: 14, borderTop: '1px solid #1b2a3d', paddingTop: 12 }}>
        <div style={{ fontSize: 16 }}>{w.ex}</div>
        <div style={{ fontSize: 13, opacity: 0.7, marginTop: 4 }}>{w.ex_ko}</div>
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
        <button className="btn ghost" onClick={() => playClip({ audio_url: w.audio_url, tts: w.tts || w.w })}>🔊 단어</button>
        <button className="btn ghost" onClick={() => playClip({ audio_url: w.audio_ex_url || w.audio_url, tts: w.ex })}>🔊 예문</button>
      </div>
    </div>
  )
}

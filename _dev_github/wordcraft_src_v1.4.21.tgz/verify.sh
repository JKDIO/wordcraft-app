#!/usr/bin/env bash
# WordCraft 배포 전 검증 일괄 실행 (v1.4.21 신설)
#
# 왜 스크립트로 묶었나: v1.4.17의 관제실 XP 봉합이 v1.4.18에서 조용히 사라진 뒤
# 두 릴리스 동안 아무도 눈치채지 못했다(L27). 검사는 "기억해서 돌리는 것"이 아니라
# **한 줄로 항상 돌아가는 것**이어야 한다.
#
# 사용: bash verify.sh   (실패하면 0이 아닌 코드로 끝난다)
set -euo pipefail
cd "$(dirname "$0")"
export PATH=$PATH:/root/.bun/bin
TSC=/home/claude/.npm-global/bin/tsc

echo "── ① 타입 검사 ──"
$TSC -p tsconfig.json && echo "  통과"

echo "── ② 검사용 번들 생성 ──"
mkdir -p .verify
cat > .verify/vocab_entry.ts <<'EOF'
import * as V from '../src/lib/vocab'
// @ts-ignore
globalThis.V = V
EOF
cat > .verify/xp_entry.ts <<'EOF'
import * as X from '../src/lib/xp'
// @ts-ignore
globalThis.X = X
EOF
cat > .verify/badge_entry.ts <<'EOF'
import * as B from '../src/lib/badges'
// @ts-ignore
globalThis.B = B
EOF
bun build .verify/vocab_entry.ts  --outdir .verify/out --target node --format esm >/dev/null
bun build .verify/xp_entry.ts     --outdir .verify/out --target node --format esm >/dev/null
bun build .verify/badge_entry.ts  --outdir .verify/out --target node --format esm >/dev/null
cp .verify/out/vocab_entry.js ./_measure_entry_out.js
cp .verify/out/xp_entry.js    ./_xp_entry_out.js
cp .verify/out/badge_entry.js ./_b_entry_out.js
echo "  완료"

echo "── ③ XP 패리티 (앱=관제실=기기병합, L12·L27) ──"
node xp_parity.mjs

echo "── ④ 뱃지 판정 (단일 규칙, 경계값, 도달 가능성) ──"
node badge_check.mjs

echo "── ⑤ 문항 입력 방식·정답 위치·무결성 (L24·L26) ──"
node measure20.mjs | tail -12

echo "── ⑥ 골렘·속사 무결성 ──"
node golem_check.mjs

echo "── ⑦ 배포물 버전 3자 대조 (L25) ──"
if [ -f dist/main.js ]; then
  B=$(grep -o '1\.4\.[0-9]\{1,2\}' dist/main.js | sort -u | tr '\n' ' ')
  V=$(python3 -c "import json;print(json.load(open('dist/version.json'))['version'])")
  S=$(grep -o "'1\.4\.[0-9]*'" src/lib/version.ts | tr -d "'")
  echo "  번들:$B / version.json:$V / 소스:$S"
  [ "$(echo $B | tr -d ' ')" = "$V" ] && [ "$V" = "$S" ] && echo "  일치" || { echo "  ★불일치★"; exit 1; }
else
  echo "  dist 없음 — 빌드 후 다시 실행할 것"
fi

echo
echo "✅ 배포 전 검증 전 항목 통과"

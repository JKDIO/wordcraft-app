import { useEffect, useState } from 'react'
import { getDailyActiveSec, ATTENDANCE_MIN_SEC, type LocalState } from '../lib/store'
import { db } from '../lib/supabase'
import { levelProgress, levelTitle } from '../lib/xp'
import { moduleOrder } from '../lib/content'
import { BADGE_DEFS, BADGE_GROUPS, GROUP_EMOJI, type BadgeGroup } from '../lib/badges'
import { todayStr } from '../lib/leitner'
import { BadgeLoadout } from './BadgeLoadout'   // v1.4.28 ⚔️ 룬 장비창

const DOW = ['월', '화', '수', '목', '금', '토', '일']

export function Profile(props: { state: LocalState; worldsReady?: boolean }) {
  const s = props.state
  // v1.4.23: 승인 전에는 월드 7~10이 '클리어 n/28' 분모에 들어가지 않는다
  const ORDER_V = moduleOrder(props.worldsReady)
  const lp = levelProgress(s.xp)
  const onSeg = Math.min(10, Math.round((lp.cur / lp.need) * 10))
  const [badges, setBadges] = useState<string[]>([])
  const [reveal, setReveal] = useState<string | null>(null)
  // v1.4.27 — 뱃지 59개. 카테고리를 접었다 폈다 한다.
  // 기본값은 "하나라도 딴 카테고리는 펼치고, 아직 0개인 곳은 접는다" —
  // 아이가 화면을 열자마자 **자기가 이룬 것**을 먼저 보게 하려는 것. 안 딴 곳은 스스로 열어 보게 둔다.
  const [openGroups, setOpenGroups] = useState<Record<string, boolean> | null>(null)

  useEffect(() => {
    if (!s.learnerId) return
    db.select('badges', `learner_id=eq.${s.learnerId}&select=badge_id&order=earned_at.desc&limit=1000`)
      .then(rows => setBadges((rows as { badge_id: string }[]).map(r => r.badge_id)))
      .catch(() => {})
  }, [s.learnerId])

  const completed = ORDER_V.filter(id => {
    const p = s.progress[id]
    return p && (p.status === 'completed' || p.status === 'mastered')
  }).length

  /** 기본 펼침 상태 — 하나라도 딴 카테고리만 펼친다 */
  function defaultOpen(): Record<string, boolean> {
    const out: Record<string, boolean> = {}
    for (const g of BADGE_GROUPS) {
      out[g] = Object.entries(BADGE_DEFS).some(([id, b]) => b.group === g && badges.includes(id))
    }
    return out
  }
  const groupOpen = (g: BadgeGroup) => (openGroups ?? defaultOpen())[g] ?? false

  // 오늘 학습시간 (출석 15분 판정용) — 30초마다 새로고침해 진행분 표시
  const [dailySec, setDailySec] = useState(() => getDailyActiveSec())
  useEffect(() => {
    const t = setInterval(() => setDailySec(getDailyActiveSec()), 30000)
    return () => clearInterval(t)
  }, [])
  const dailyMin = Math.floor(dailySec / 60)
  const needMin = Math.max(1, Math.ceil((ATTENDANCE_MIN_SEC - dailySec) / 60))

  // 이번 주(월~일) 출석 칩 (시안 07) — KST 날짜 기준
  const todayS = todayStr()
  const base = new Date(todayS + 'T12:00:00Z')
  const mondayOffset = (base.getUTCDay() + 6) % 7
  const week = Array.from({ length: 7 }, (_, k) => {
    const d = new Date(base)
    d.setUTCDate(base.getUTCDate() - mondayOffset + k)
    return d.toISOString().slice(0, 10)
  })
  const attendance = s.attendance || []

  return (
    <div className="profile">
      {/* 레벨 카드 (시안 05): 72×72 골드 블록 + 세그먼트 바 + 다음 레벨 안내문 */}
      <div className="wc-lv-card">
        <div className="wc-lv-big">LV.{lp.level}</div>
        <h3>{s.nickname}</h3>
        <p className="wc-lv-title">{levelTitle(lp.level)}</p>
        <div className="xpbar-seg">
          {Array.from({ length: 10 }, (_, k) => <i key={k} className={k < onSeg ? 'on' : ''} />)}
        </div>
        <div className="xp-meta"><span>{lp.cur} / {lp.need} XP</span><span>다음 레벨 -{lp.need - lp.cur}</span></div>
        <p className="note wc-lv-note">{lp.need - lp.cur} XP만 더 캐면 레벨 {lp.level + 1}! 계속 파보자 ⛏️</p>
      </div>

      {/* 스트릭 히어로 (시안 07): 골드 테두리 + 불꽃 + 밈 문구. 출석 = 하루 15분 이상 학습 (7/16 규칙) */}
      <div className="wc-streak-hero">
        <span className="wc-flame">🔥</span>
        <h3>{s.streak_days}일 연속!</h3>
        <p className="note">{
          attendance.includes(todayS)
            ? `오늘 출석 완료! 내일도 15분 캐면 ${s.streak_days + 1}일 🔥`
            : dailyMin > 0
              ? `오늘 ${dailyMin}분 채굴 중 — ${needMin}분만 더 캐면 출석 도장 쾅! ⛏️`
              : '하루 15분 캐면 출석 불꽃이 켜져! 오늘도 지펴보자 🔥'
        }</p>
      </div>
      <div className="wc-week">
        {week.map((d, k) => {
          const done = attendance.includes(d)
          const isToday = d === todayS
          const future = d > todayS
          const cls = done ? 'is-done' : isToday ? 'is-today' : future ? 'is-future' : ''
          const mark = done ? '✓' : isToday ? '!' : '·'
          return <div key={d} className={`wc-day ${cls}`}>{DOW[k]}<b>{mark}</b></div>
        })}
      </div>

      <div className="stat-row">
        <div className="stat-tile"><b>⭐ {s.xp}</b><span>총 XP</span></div>
        <div className="stat-tile"><b>🔥 {s.streak_days}</b><span>연속 출석</span></div>
        <div className="stat-tile"><b>🗺️ {completed}/{ORDER_V.length}</b><span>클리어</span></div>
        <div className="stat-tile"><b>⛏️ {s.reviewTotal || 0}</b><span>복습 채굴</span></div>
      </div>

      {/* 뱃지 도감 (시안 08 + v1.2.0): 미획득 뱃지는 탭하면 획득 조건·진행도 공개 → 목표 삼기 */}
      <h3 className="section-title wc-dex-head">🏆 뱃지 도감 <span className="wc-dex-count">{badges.length}/{Object.keys(BADGE_DEFS).length}</span></h3>
      {/* v1.4.28 ⚔️ 룬 장비창 — 도감(59칸 목록)보다 먼저, '지금 내가 얼마나 강해졌는가'를 한 그림으로 */}
      <BadgeLoadout earned={badges} onPickGroup={g => {
        // 슬롯을 누르면 그 카테고리만 펼치고 그 자리로 데려간다
        const next: Record<string, boolean> = {}
        for (const x of BADGE_GROUPS) next[x] = x === g
        setOpenGroups(next)
        setTimeout(() => document.getElementById(`bg-${BADGE_GROUPS.indexOf(g)}`)?.scrollIntoView({ block: 'start', behavior: 'smooth' }), 60)
      }} />
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, margin: '2px 2px 4px' }}>
        <p className="wc-dex-hint" style={{ margin: 0 }}>🔍 물음표 뱃지를 탭하면 획득 조건이 보여!</p>
        <button
          onClick={() => {
            const anyOpen = BADGE_GROUPS.some(g => groupOpen(g))
            const next: Record<string, boolean> = {}
            for (const g of BADGE_GROUPS) next[g] = !anyOpen
            setOpenGroups(next)
          }}
          style={{ background: 'none', border: 'none', color: 'var(--text-2)', fontSize: 12, padding: '2px 4px', whiteSpace: 'nowrap' }}>
          {BADGE_GROUPS.some(g => groupOpen(g)) ? '전체 접기' : '전체 펼치기'}
        </button>
      </div>
      {/* v1.4.27 — 뱃지가 59개. 성격별 10개 카테고리로 끊고 **접었다 폈다** 할 수 있게 했다.
          아이가 "나는 읽기가 4/4구나"처럼 자기 강약점을 스스로 읽을 수 있어야 하기 때문이다. */}
      {BADGE_GROUPS.map(g => {
        const ids = Object.entries(BADGE_DEFS).filter(([, b]) => b.group === g)
        if (!ids.length) return null
        const got = ids.filter(([id]) => badges.includes(id)).length
        const open = groupOpen(g)
        const pct = Math.round((got / ids.length) * 100)
        return (
          <div key={g} id={`bg-${BADGE_GROUPS.indexOf(g)}`}>
            {/* ⚠️ app.css는 배포본과 크기가 어긋나 있는 이월 과제라 새 클래스를 추가하지 않는다(인라인 스타일). */}
            <button
              onClick={() => setOpenGroups({ ...(openGroups ?? defaultOpen()), [g]: !open })}
              style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: 8, textAlign: 'left',
                margin: '12px 0 6px', padding: '9px 11px', fontSize: 13, fontWeight: 800,
                background: got ? 'linear-gradient(90deg, rgba(245,197,66,.14), rgba(245,197,66,.03))' : 'var(--bg-1)',
                border: `1px solid ${got === ids.length ? 'var(--gold)' : 'var(--wc-surface-border)'}`,
                borderRadius: 'var(--radius)', color: 'var(--wc-text)',
              }}>
              <span style={{ fontSize: 15 }}>{GROUP_EMOJI[g]}</span>
              <span style={{ flex: 1 }}>{g}{got === ids.length && ids.length > 0 ? ' ✅' : ''}</span>
              <span style={{ width: 46, height: 5, background: '#1b2a3d', borderRadius: 99, overflow: 'hidden' }}>
                <i style={{ display: 'block', height: '100%', width: `${pct}%`, background: got === ids.length ? '#3ddc84' : '#4a9eff' }} />
              </span>
              <span style={{ fontSize: 11.5, opacity: 0.65, fontVariantNumeric: 'tabular-nums' }}>{got}/{ids.length}</span>
              <span style={{ fontSize: 11, opacity: 0.55 }}>{open ? '▲' : '▼'}</span>
            </button>
            {open && <div className="badge-grid">
              {ids.map(([id, b]) => {
                const isGot = badges.includes(id)
                const revealed = reveal === id
                if (isGot) return (
                  <div key={id} className="badge-card got">
                    <span className="badge-emoji">{b.emoji}</span>
                    <b>{b.name}</b>
                    <span className="badge-desc">{b.desc}</span>
                  </div>
                )
                const prog = b.progress ? b.progress(s) : null
                return (
                  <button key={id} className={`badge-card silhouette ${revealed ? 'revealed' : ''}`}
                    onClick={() => setReveal(revealed ? null : id)}>
                    <span className="badge-emoji">{revealed ? b.emoji : '❓'}</span>
                    <b>{revealed ? b.name : '???'}</b>
                    {revealed && (
                      <span className="badge-hint">
                        🎯 {b.hint}
                        {prog && prog.max > 1 && (
                          <span className="badge-prog">
                            <i style={{ width: `${Math.round((prog.cur / prog.max) * 100)}%` }} />
                            <em>{prog.cur}/{prog.max}</em>
                          </span>
                        )}
                      </span>
                    )}
                    {!revealed && <span className="badge-desc dim">탭해서 조건 보기</span>}
                  </button>
                )
              })}
            </div>}
          </div>
        )
      })}
    </div>
  )
}

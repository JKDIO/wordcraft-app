#!/usr/bin/env bash
# WordCraft 프로덕션 빌드 — bun 번들 + 정적 자산 + 콘텐츠 동기화
set -euo pipefail
cd "$(dirname "$0")"
export PATH=$PATH:/root/.bun/bin
# ★2026-09-03 (v1.4.47)★ verify.sh 와 같은 이유로 컨테이너 절대경로를 환경변수로 열었다.
#   노트북에서는 이 스크립트가 첫 줄에서 죽어 **빌드를 한 번도 못 돌렸다.**
#   기본값은 그대로라 컨테이너 동작은 변하지 않는다:  TSC=... BUN_BIN=... bash build.sh
TSC=${TSC:-/home/claude/.npm-global/bin/tsc}
BUN_BIN=${BUN_BIN:-bun}
CONTENT_SRC=${CONTENT_SRC:-/home/claude/work/Yehan_English_App/04_CONTENT}

# 타입 검사 (G-ENC 이전 단계 — 코드 정합)
$TSC -p tsconfig.json

# 번들 (bunfig.toml: jsx=react-jsx 필수 — SMOKE_LOG 봉합 결함 참조)
NODE_ENV=production $BUN_BIN build src/main.tsx --outdir dist --minify --define process.env.NODE_ENV='"production"'

# 정적 자산
cp index.html dist/
cp -r public/* dist/
# ★CSS 합치기 (CI wc-build.yml 과 같은 규칙)★ app.css 뒤에 css.d/*.css 를 순서대로 이어 붙인다.
#   이걸 빠뜨리면 dist 에는 신규 CSS가 없어서 스모크가 "옛 화면"을 보게 된다.
rm -rf dist/css.d
for f in public/css.d/*.css; do printf '
/* %s */
' "$(basename "$f")" >> dist/app.css; cat "$f" >> dist/app.css; done
echo "  css.d merged: $(ls public/css.d/*.css | wc -l) files"

# 콘텐츠 (04_CONTENT → dist/content)
mkdir -p dist/content/modules dist/content/diagnostics
[ -d "$CONTENT_SRC/modules" ] && cp "$CONTENT_SRC"/modules/*.json dist/content/modules/ 2>/dev/null || true
[ -d "$CONTENT_SRC/diagnostics" ] && cp "$CONTENT_SRC"/diagnostics/*.json dist/content/diagnostics/ 2>/dev/null || true

echo "── 빌드 완료 ──"
ls dist/ && du -h dist/main.js
gzip -c dist/main.js | wc -c | awk '{print "main.js gzip: " $1 " bytes"}'

/* reading_check.mjs — 📚 이야기 서고(월드 10) 콘텐츠 전수 검사 (v1.4.47 신설)
 *
 * 이 검사가 있는 이유: 읽기·쓰기 문항은 **정답이 하나로 딱 떨어지지 않는 유일한 영역**이라
 * "돌려 보니 되더라"로는 품질을 보증할 수 없다. 그래서 사람이 눈으로 볼 수밖에 없는 것과
 * 기계가 반드시 잡아야 하는 것을 나눠 두고, 후자만 여기서 전수로 본다.
 *
 * ★기계가 잡는 것★
 *   ① 지어낸 단어 금지 — 아이에게 '배울 단어'로 제시되는 것(빈칸 보기·단어 칩)은
 *      전부 vocab.json 에 실제로 있어야 한다. 설계 문서 A·B·C 공통 규칙이다.
 *   ② 진도 오염 금지 — RD/WF 모듈이 MODULE_ORDER·EXT_MODULE_ORDER 에 섞여 들어가면
 *      예한이 화면의 "클리어 n/52" 분모가 조용히 바뀐다(Dio님 2026-09-03 지시).
 *   ③ 지문 없는 독해 금지 — quiz 스텝에 passage 가 없으면 그건 독해가 아니라 암기 문제다.
 *   ④ 정답 위치 쏠림 — 4지선다에서 정답이 한 자리에 몰리면 아이가 내용을 안 보고 찍는다(L24).
 *   ⑤ 말투 — 아이가 읽는 한국어가 존댓말이면 화자가 갈라진다(D47-3과 같은 병).
 *   ⑥ 문항 id 중복 — 중복되면 answer_events 에서 두 문항이 한 문항으로 합쳐진다.
 *
 * ★기계가 못 잡는 것(정직 표기)★
 *   추론 문항의 정답이 정말 '가장 그럴듯한 추론'인지, 해설이 실제로 옳은지는 사람이 봐야 한다.
 *   이 검사가 통과했다고 내용이 옳다는 뜻이 아니다.
 *
 * 사용: node reading_check.mjs [content.json 경로]   (기본 public/content.json)
 */
import { readFileSync } from 'node:fs'

const CONTENT = process.argv[2] || 'public/content.json'
const RD = ['RD1', 'RD2', 'RD3', 'RD4', 'RD5', 'RD6']
const WF = ['WF1', 'WF2', 'WF3', 'WF4', 'WF5', 'WF6']
const ALL = [...RD, ...WF]

let fail = 0
const ok = (cond, label, extra = '') => {
  if (cond) console.log(`  ✓ ${label}`)
  else { console.log(`  ✗ ${label} ${extra}`); fail++ }
}

const content = JSON.parse(readFileSync(CONTENT, 'utf8'))
const vocab = JSON.parse(readFileSync('public/vocab.json', 'utf8'))
const VOCAB = new Set()
for (const id in vocab.packs) for (const w of vocab.packs[id].words) VOCAB.add(w.w.toLowerCase())

const mods = ALL.map(id => content.modules?.[id]).filter(Boolean)

console.log('── ① 모듈이 다 있는가 ──')
ok(mods.length === ALL.length, `모듈 12개 (읽기 6 + 쓰기 6)`, `실제 ${mods.length}개`)
ok(mods.every(m => m.world === 10), '전부 월드 10(이야기 서고)에 있다')

console.log('── ② 진도 오염 금지 (Dio님 2026-09-03 지시) ──')
{
  const src = readFileSync('src/lib/content.ts', 'utf8')
  const base = src.match(/export const MODULE_ORDER = \[(.*?)\]/s)?.[1] ?? ''
  const ext = src.match(/export const EXT_MODULE_ORDER = \[(.*?)\]/s)?.[1] ?? ''
  const leaked = ALL.filter(id => base.includes(`'${id}'`) || ext.includes(`'${id}'`))
  ok(leaked.length === 0, '★RD/WF가 진도 배열에 섞이지 않았다 (클리어 n/52 분모 보존)', leaked.join(','))
  ok(/export const WRITE_MODULE_ORDER/.test(src), 'WRITE_MODULE_ORDER 가 따로 있다')
  const wm = readFileSync('src/screens/WorldMap.tsx', 'utf8')
  ok(/isWriteModule/.test(wm), '월드맵이 isWriteModule 로 순서 잠금을 건너뛴다')
  /* ★2026-09-03 신설★ 진도에서 뺀 것과 제목을 못 읽는 것은 다른 문제다.
     ORDER_V(진도 배열)만 돌리면 서고 카드가 `RD4`·`WF1` 같은 id 로 뜬다 — 실제로 그렇게 배포됐었다. */
  // 문자열이 '있는지'가 아니라 **실제로 그걸로 도는지**를 본다.
  // (선언만 남기고 forEach 를 ORDER_V 로 되돌려도 통과하면 게이트가 아니다 — 실제로 그랬다)
  ok(/META_IDS\.forEach\(/.test(wm) && /WRITE_MODULE_ORDER/.test(wm),
    '★월드맵이 서고 모듈의 제목·이모지도 불러온다 (카드에 id 가 그대로 뜨지 않는다)')
  ok(!/ORDER_V\.forEach\(/.test(wm), '메타 로딩이 진도 배열만 돌지 않는다')
  ok(/\[props\.worldsReady, props\.writingReady\]/.test(wm),
    '메타 로딩이 writingReady 변화에도 다시 돈다')
}

console.log('── ③ 읽기: 지문 없는 독해 금지 ──')
for (const id of RD) {
  const m = content.modules?.[id]; if (!m) continue
  const quizzes = m.steps.filter(s => s.type === 'quiz')
  ok(quizzes.length >= 3, `${id} 지문 3개 이상`, `${quizzes.length}개`)
  ok(quizzes.every(q => q.passage && typeof q.passage.en === 'string' && q.passage.en.trim().length > 60),
    `${id} 모든 quiz 스텝에 지문이 붙어 있다`)
  for (const q of quizzes) {
    const sents = (q.passage?.en || '').split(/(?<=[.!?])\s+/).filter(Boolean).length
    if (!(sents >= 3 && sents <= 8)) { console.log(`  ✗ ${id} 지문 문장 수 ${sents} (3~8 이어야 한다)`); fail++ }
  }
}

console.log('── ④ 쓰기: 자유 작문과 빈칸이 둘 다 있는가 ──')
for (const id of WF) {
  const m = content.modules?.[id]; if (!m) continue
  const cloze = m.steps.filter(s => s.type === 'game' && s.kind === 'choice')
  const free = m.steps.filter(s => s.type === 'write_free')
  ok(cloze.length >= 1 && cloze[0].items.length >= 5, `${id} 빈칸 5문항 이상`)
  ok(free.length >= 1 && free[0].items.length >= 2, `${id} 자유 작문 2문항 이상`)
}

console.log('── ⑤ ★지어낸 단어 금지 — 배울 단어는 전부 vocab.json 에 있어야 한다★ ──')
{
  const bad = []
  for (const id of WF) {
    const m = content.modules?.[id]; if (!m) continue
    for (const s of m.steps) {
      if (s.type === 'game' && s.kind === 'choice') {
        for (const it of s.items) for (const c of it.choices) {
          const w = String(c).toLowerCase().trim()
          if (/^[a-z][a-z'-]*$/.test(w) && !VOCAB.has(w)) bad.push(`${it.id}:${c}`)
        }
      }
      if (s.type === 'write_free') {
        for (const it of s.items) for (const w of (it.words_ko || [])) {
          if (!VOCAB.has(String(w).toLowerCase().trim())) bad.push(`${it.id}:${w}`)
        }
      }
    }
  }
  ok(bad.length === 0, '빈칸 보기·단어 칩이 전부 vocab.json 의 실제 단어다', bad.slice(0, 8).join(' '))
}

console.log('── ⑥ 정답 위치 쏠림 (L24) ──')
{
  const hist = [0, 0, 0, 0]
  let n = 0
  for (const m of mods) for (const s of m.steps) {
    const items = s.type === 'quiz' ? s.questions : (s.type === 'game' && s.kind === 'choice' ? s.items : [])
    for (const it of items) { if (it.choices?.length === 4) { hist[it.answer_idx]++; n++ } }
  }
  const pct = hist.map(h => (h / n * 100))
  console.log(`  분포: ${pct.map((p, i) => `${i}:${p.toFixed(1)}%`).join(' ')} (총 ${n}문항)`)
  ok(n >= 60, '4지선다 60문항 이상', `${n}문항`)
  ok(Math.min(...pct) >= 12 && Math.max(...pct) <= 40, '어느 자리도 12%~40% 밖으로 벗어나지 않는다')
}

console.log('── ⑦ 말투: 아이가 읽는 한국어는 반말 ──')
{
  const bad = []
  for (const m of mods) {
    const texts = []
    for (const s of m.steps) {
      if (s.type === 'quiz') { for (const q of s.questions) texts.push(q.q_ko, q.explain_ko) }
      if (s.type === 'game' && s.kind === 'choice') { for (const it of s.items) texts.push(it.q_ko, it.explain_ko) }
      if (s.type === 'write_free') { for (const it of s.items) texts.push(it.prompt_ko, it.hint_ko) }
      if (s.type === 'story') { for (const l of s.lines) texts.push(l.text_ko) }
    }
    for (const t of texts.filter(Boolean)) {
      if (/(요|니다)[.!?]?$/.test(String(t).trim())) bad.push(`${m.module_id}: ${String(t).slice(0, 40)}`)
    }
  }
  ok(bad.length === 0, '존댓말 문장이 없다 (화자가 갈라지지 않는다)', bad.slice(0, 5).join(' | '))
}

console.log('── ⑧ 문항 id 중복 금지 ──')
{
  const seen = new Map()
  const dup = []
  for (const m of mods) for (const s of m.steps) {
    const items = s.type === 'quiz' ? s.questions
      : (s.type === 'game' && s.kind === 'choice') ? s.items
        : s.type === 'write_free' ? s.items : []
    for (const it of items) {
      if (seen.has(it.id)) dup.push(it.id); else seen.set(it.id, m.module_id)
    }
  }
  ok(dup.length === 0, `문항 id ${seen.size}개 전부 유일하다`, dup.slice(0, 5).join(','))
}

console.log('── ⑨ 마크다운·빈 필드 혼입 금지 ──')
{
  const bad = []
  const walk = (o, path) => {
    if (typeof o === 'string') {
      if (/\*\*|```/.test(o)) bad.push(`${path}: 마크다운`)
      if (!o.trim()) bad.push(`${path}: 빈 문자열`)
    } else if (Array.isArray(o)) o.forEach((x, i) => walk(x, `${path}[${i}]`))
    else if (o && typeof o === 'object') for (const k in o) walk(o[k], `${path}.${k}`)
  }
  for (const m of mods) walk(m, m.module_id)
  ok(bad.length === 0, '본문에 마크다운 강조·빈 문자열이 없다', bad.slice(0, 5).join(' | '))
}

console.log(fail === 0 ? '\n✅ reading_check 통과' : `\n✗ reading_check 실패 ${fail}건`)
process.exit(fail === 0 ? 0 : 1)

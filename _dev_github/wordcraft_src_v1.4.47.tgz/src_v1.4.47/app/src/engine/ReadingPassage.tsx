// 읽기 지문 — 문단 독해 문항 위에 계속 떠 있는 지문 상자 (v1.4.47, 2026-09-03)
//
// 왜 별도로 두나: 지문을 `story` 스텝으로 보여 주면 **문제로 넘어가는 순간 사라진다.**
// 문단 독해는 "읽은 것을 기억하는지"가 아니라 "읽고 찾아내는지"를 보는 활동이라,
// 지문이 눈앞에 없으면 그건 독해 문제가 아니라 암기 문제가 된다.
// 그래서 같은 quiz 스텝의 모든 문항에 같은 지문이 따라붙는다(StepRunner.flatten).
//
// 번역은 일부러 넣지 않는다. 한국어 뜻이 옆에 있으면 아이는 영어를 읽지 않는다.
// 모르는 단어는 문항의 해설(explain_ko)에서 풀어 준다.
import { useState } from 'react'
import type { Passage } from '../lib/content'

export function ReadingPassage(props: { passage: Passage }) {
  const p = props.passage
  const [open, setOpen] = useState(true)
  return (
    <div className="rd-passage">
      <button
        type="button"
        className="rd-passage-head"
        onClick={() => setOpen(!open)}
        aria-expanded={open}
      >
        <span className="rd-passage-title">📖 {p.title_ko || '지문'}</span>
        <span className="rd-passage-toggle">{open ? '접기 ▲' : '펼치기 ▼'}</span>
      </button>
      {open && (
        <div className="rd-passage-body">
          {p.en.split('\n').filter(Boolean).map((line, i) => (
            <p key={i}>{line}</p>
          ))}
        </div>
      )}
    </div>
  )
}

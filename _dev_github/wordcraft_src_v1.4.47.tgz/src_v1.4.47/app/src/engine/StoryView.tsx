// 스토리 대사 뷰 — StepRunner 에서 분리 (v1.4.47, 2026-09-03)
// 분리 이유: ① StepRunner 가 LEAN 상한(300줄)에 붙어 새 기능을 못 받는 상태였다
//            ② 이건 '탭하면 한 줄씩 나오는 말풍선'이지 스텝 실행기가 아니다 — 역할이 다르다
import { useState } from 'react'
import type { StoryLine } from '../lib/content'

export function StoryView(props: { lines: StoryLine[]; onNext: () => void }) {
  const [shown, setShown] = useState(1)
  const all = props.lines.length
  return (
    <div className="story" onClick={() => (shown < all ? setShown(shown + 1) : props.onNext())}>
      {props.lines.slice(0, shown).map((l, i) => (
        <div key={i} className="story-line">
          <span className="story-emoji">{l.emoji || '💬'}</span>
          <div className="story-bubble">
            <span className="story-speaker">{l.speaker}</span>
            <p>{l.text_ko}{l.text_en ? <em className="story-en"> {l.text_en}</em> : null}</p>
          </div>
        </div>
      ))}
      <p className="tap-hint">{shown < all ? '탭해서 계속…' : '탭해서 시작! ▶'}</p>
    </div>
  )
}

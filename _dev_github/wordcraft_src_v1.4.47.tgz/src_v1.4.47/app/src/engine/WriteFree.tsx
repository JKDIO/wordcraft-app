import { useMemo, useRef, useState } from 'react'
import type { WriteFreeItem } from '../lib/content'
import { loadLocal } from '../lib/store'
import { gradeWriting, wordCount, DEFAULT_MIN_WORDS, type WriteGradeResult } from '../lib/writeGrade'
import { XP } from '../lib/xp'

/* ─── ✍️ 자유 작문 스텝 (v1.4.47) ──────────────────────────────────────────
   이 화면이 지금까지의 문항과 다른 점:

   1. **정답이 없다.** 그래서 ⭕❌ 를 보여주지 않는다. 아이가 쓴 것을 읽고 반응할 뿐이다.
   2. **채점이 느리다**(모델 왕복 2~5초). 그동안 화면이 죽은 것처럼 보이면 아이는 다시 누른다 →
      그래서 제출 버튼을 즉시 잠그고 "읽는 중"을 명시한다.
   3. **실패해도 넘어간다.** 인터넷이 끊겨도 XP를 주고 다음으로 보낸다(writeGrade.localFallback).
      학습을 채점 서버의 가용성에 인질로 잡히게 하지 않는다.

   ★빈 화면 공포★ — 초6에게 빈 입력창은 그 자체로 벽이다. 그래서 세 가지를 준다:
   시작 틀(starter_en) · 단어 칩(words_ko, 탭하면 들어간다) · 접어둔 힌트(hint_ko).
   전부 **선택**이다. 아무것도 안 쓰고 자기 문장으로 써도 된다. */

type Phase = 'writing' | 'grading' | 'result'

export function WriteFree(props: {
  items: WriteFreeItem[]
  moduleId: string
  prompt_ko?: string
  /** 한 문항 채점이 끝날 때마다. is_correct 는 '맞았다'가 아니라 **'성의 있게 썼다'** 이다. */
  onAnswer: (item: WriteFreeItem, r: WriteGradeResult, text: string, ms: number) => void
  onFinish: () => void
}) {
  const [i, setI] = useState(0)
  const [text, setText] = useState('')
  const [phase, setPhase] = useState<Phase>('writing')
  const [result, setResult] = useState<WriteGradeResult | null>(null)
  const [hintOpen, setHintOpen] = useState(false)
  const startedAt = useRef(Date.now())
  const taRef = useRef<HTMLTextAreaElement | null>(null)

  const item = props.items[i]
  const learnerId = useMemo(() => loadLocal().learnerId, [])
  const minWords = item?.min_words ?? DEFAULT_MIN_WORDS
  const n = wordCount(text)

  if (!item) return null

  /** 단어 칩 — 커서 위치가 아니라 항상 끝에 붙인다(모바일에서 커서 추적이 불안정하다). */
  function addWord(w: string) {
    setText(t => (t.trim() ? `${t.replace(/\s+$/, '')} ${w}` : w))
    taRef.current?.focus()
  }

  async function submit() {
    if (phase !== 'writing' || !text.trim()) return
    setPhase('grading')
    const ms = Date.now() - startedAt.current
    const r = await gradeWriting({
      learnerId: learnerId || '', moduleId: props.moduleId, questionId: item.id,
      promptKo: item.prompt_ko, text: text.trim(),
    })
    setResult(r)
    setPhase('result')
    // 상한에 걸린 제출은 기록하지 않는다 — 채점이 이뤄지지 않았는데 문항을 푼 것으로 세면 지표가 거짓이 된다(L28).
    if (!r.capped) props.onAnswer(item, r, text.trim(), ms)
  }

  function nextItem() {
    if (i + 1 >= props.items.length) { props.onFinish(); return }
    setI(i + 1); setText(''); setResult(null); setHintOpen(false)
    setPhase('writing'); startedAt.current = Date.now()
  }

  return (
    <div className="writefree">
      {props.prompt_ko && <p className="wf-section">{props.prompt_ko}</p>}
      <div className="wf-mission">
        <span className="wf-badge">✍️ 작문 {i + 1}/{props.items.length}</span>
        <h3>{item.prompt_ko}</h3>
        {item.starter_en && <p className="wf-starter">이렇게 시작해도 좋아 — <b>{item.starter_en}</b></p>}
      </div>

      {phase === 'writing' && (
        <>
          <textarea
            ref={taRef}
            className="wf-input"
            value={text}
            onChange={(e: { target: { value: string } }) => setText(e.target.value)}
            placeholder="영어로 자유롭게 써봐. 틀려도 괜찮아!"
            rows={5}
            maxLength={1200}
            autoCapitalize="sentences"
            autoCorrect="off"
            spellCheck={false}
          />
          <div className="wf-meter">
            <span className={n >= minWords ? 'ok' : ''}>{n}단어</span>
            <span className="wf-meter-hint">{n >= minWords ? '충분해! 더 써도 좋아' : `${minWords}단어쯤이면 딱 좋아 (적어도 괜찮아)`}</span>
          </div>

          {!!item.words_ko?.length && (
            <div className="wf-words">
              {item.words_ko.map(w => (
                <button key={w} type="button" className="wf-word" onClick={() => addWord(w)}>{w}</button>
              ))}
            </div>
          )}

          {item.hint_ko && (
            hintOpen
              ? <p className="wf-hint">💡 {item.hint_ko}</p>
              : <button type="button" className="btn ghost wf-hint-btn" onClick={() => setHintOpen(true)}>💡 힌트 보기</button>
          )}

          <button className="btn primary wide" disabled={!text.trim()} onClick={() => void submit()}>
            다 썼어! 보여줄게 →
          </button>
        </>
      )}

      {phase === 'grading' && (
        <div className="wf-grading">
          <div className="wf-quill">✍️</div>
          <p>네가 쓴 글을 읽는 중…</p>
          <p className="wf-grading-sub">몇 초만 기다려 줘</p>
        </div>
      )}

      {phase === 'result' && result && (
        <div className={`wf-result ${result.xp > 0 ? 'good' : 'retry'}`}>
          <p className="wf-mine">{text.trim()}</p>
          {result.xp > 0 && <div className="wf-xp">+{XP.writeFree} XP</div>}
          <p className="wf-feedback">{result.feedback_ko}</p>
          {/* 채점을 못 했다는 사실을 숨기지 않는다. 다만 아이 말투로 적는다(L47 정직 + 아이 배려) */}
          {result.fallback && <p className="wf-note">⚠️ 지금은 자세한 피드백을 못 만들었어. 아빠가 읽어볼 거야.</p>}
          {result.xp === 0 && !result.capped && (
            <button className="btn secondary wide" onClick={() => { setPhase('writing'); setResult(null) }}>
              다시 써볼래 ✏️
            </button>
          )}
          <button className="btn primary wide" onClick={nextItem}>
            {i + 1 >= props.items.length ? '좋아, 계속 →' : '다음 작문 →'}
          </button>
        </div>
      )}
    </div>
  )
}

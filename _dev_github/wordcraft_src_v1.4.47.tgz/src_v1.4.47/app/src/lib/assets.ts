// 데이터 파일 경로 해석 — v1.4.47 (2026-09-03)
//
// 왜 필요한가: 이 앱은 지금까지 `fetch('/content.json')` 처럼 **슬래시로 시작하는 절대 경로**를 썼다.
// 그러면 앱이 사이트 루트가 아닌 곳(예: 파일럿용 `/pilot/`)에 올라갔을 때
// **루트에 있는 옛날 파일을 읽는다.** 화면은 새 버전인데 콘텐츠는 옛 버전이 되는,
// 겉으로는 멀쩡해 보이는 종류의 사고다.
//
// `document.baseURI` 는 문서에 `<base href>` 가 있으면 그것을, 없으면 현재 문서 URL을 돌려준다.
//   · 루트 배포(`/index.html`)      → 지금까지와 완전히 동일하게 동작한다
//   · 예한이 APK(server.url = 오리진) → 동일
//   · 파일럿(`/pilot/` + <base>)     → `/pilot/content.json` 을 읽는다
//
// ★새 데이터 파일을 추가할 때는 반드시 이 함수를 거친다.★
// `verify.sh` 가 소스에 `fetch('/…')` 가 되살아나는지 감시한다.
export const assetUrl = (p: string): string => new URL(p, document.baseURI).href

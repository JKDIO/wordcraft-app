// 자유 작문 채점 — 규칙 단일 원천 (v1.4.47 신설, CONTRACT §16)
//
// 이 파일이 있는 이유는 rewards.ts·review.ts 와 같다: **판정 규칙을 화면에 복사하지 않기 위해서다**(L27·L51).
// "몇 XP를 주는가"·"성의 있는 시도인가"를 WriteFree.tsx 안에 적으면, 다음에 규칙이 바뀔 때
// 관제실과 갈라진다. 소비자는 이 파일의 함수만 부른다.
//
// 채점의 진짜 판정자는 서버(Edge Function `write-grade`)다. 여기 있는 것은
//   ① 서버에 보낼 것을 고르고 ② 서버가 죽었을 때 아이를 세워두지 않는 폴백
// 두 가지뿐이다.
import { invokeFunction } from './supabase'
import { XP } from './xp'

export interface WriteGradeResult {
  /** 0 또는 XP.writeFree. 이 값이 곧 answer_events 의 XP와 같아야 한다. */
  xp: number
  /** 아이가 읽는 피드백 (한국어) */
  feedback_ko: string
  confidence_flag: 'high' | 'medium' | 'low'
  /** 서버가 모델 채점에 실패해 규칙 폴백으로 판정했는가 */
  fallback: boolean
  /** 감사 로그가 실제로 남았는가. false면 아빠 화면에서 이 제출을 볼 수 없다. */
  logged: boolean
  /** 오늘 채점 상한(서버 30회)에 걸렸는가 */
  capped: boolean
}

/** 권장 단어 수 기본값 — 저작에서 min_words 를 안 적었을 때. 강제가 아니라 안내다. */
export const DEFAULT_MIN_WORDS = 8

/** 영어 단어 수 세기 (안내 문구·로컬 폴백 판정에 함께 쓴다 — 두 곳이 다르게 세면 안 된다) */
export function wordCount(text: string): number {
  return (text.trim().match(/[A-Za-z][A-Za-z']*/g) ?? []).length
}

/**
 * 이 글이 '영어 단어로 보이는가' — 서버 `ruleFallback` 과 **같은 규칙**이어야 한다.
 * 온라인이냐 오프라인이냐에 따라 같은 글의 판정이 갈리면 안 된다.
 * "짧아서 무성의"는 절대 아니다(§C-3 판정 절차 1). 거르는 것은 키보드 낙서뿐이다.
 */
export function looksLikeWords(text: string): boolean {
  const words = (text.toLowerCase().match(/[a-z']+/g) ?? []).filter(w => w.length > 1)
  /* ★"모음이 있으면 단어"는 틀렸다★ — 2026-08-30 write_check 가 잡았다:
     `asdfjkl` 에도 a 가 있어서 키보드 낙서가 성의 있는 글로 통과했다.
     영어 단어는 **자음이 다섯 개나 연달아 오지 않는다**(strength 의 'ngth' 도 넷이다).
     그래서 두 조건을 함께 본다: 모음이 있고 + 자음 5연속이 없다.
     ★관대한 쪽으로 기운 판정이다★ — 이건 채점 서버가 죽었을 때만 쓰는 폴백이고,
     진짜 글을 낙서로 오해해 XP를 안 주는 쪽이 그 반대보다 훨씬 나쁘기 때문이다. */
  return words.some(w => /[aeiouy]/.test(w) && !/[^aeiouy]{5}/.test(w))
}

/** 서버 없이 내리는 최소 판정 — **오프라인·서버 장애 전용**이다. */
export function localFallback(text: string): WriteGradeResult {
  const looksReal = looksLikeWords(text)
  return looksReal
    ? {
      xp: XP.writeFree,
      feedback_ko: '지금 인터넷이 느려서 피드백을 못 받아왔어. 그래도 쓴 건 잘 저장됐으니까 걱정 마! 👍',
      confidence_flag: 'low', fallback: true, logged: false, capped: false,
    }
    : {
      xp: 0,
      feedback_ko: '앗, 아직 안 쓴 것 같아! 짧아도 좋으니까 영어로 한 문장만 써볼까?',
      confidence_flag: 'low', fallback: true, logged: false, capped: false,
    }
}

/**
 * 채점 1회. **절대 throw 하지 않는다** — 채점 실패로 아이의 학습 흐름이 끊기면 안 된다.
 * 실패는 결과 안의 `fallback`·`logged` 로 표면화되고, 관제실이 그 건수를 본다(L47).
 */
export async function gradeWriting(p: {
  learnerId: string; moduleId: string; questionId: string; promptKo: string; text: string
}): Promise<WriteGradeResult> {
  try {
    const r = await invokeFunction('write-grade', {
      learner_id: p.learnerId, module_id: p.moduleId, question_id: p.questionId,
      prompt_ko: p.promptKo, text: p.text,
    }) as Record<string, unknown> | null
    if (!r || typeof r.feedback_ko !== 'string') return localFallback(p.text)
    const xp = Number(r.xp)
    return {
      // 서버가 이상한 값을 줘도 그대로 쓰지 않는다 — 0 또는 규정값만 받는다.
      xp: xp === XP.writeFree ? XP.writeFree : 0,
      feedback_ko: r.feedback_ko,
      confidence_flag: r.confidence_flag === 'medium' || r.confidence_flag === 'low' ? r.confidence_flag : 'high',
      fallback: r.fallback === true,
      logged: r.logged !== false,
      capped: false,
    }
  } catch (e) {
    // 하루 상한(429)은 장애가 아니라 정상 동작이다 — 아이에게 다르게 말해 준다.
    if (String(e).includes('429')) {
      return {
        xp: 0,
        feedback_ko: '오늘 작문은 여기까지야! 내일 또 쓰자 ✍️',
        confidence_flag: 'high', fallback: false, logged: false, capped: true,
      }
    }
    return localFallback(p.text)
  }
}

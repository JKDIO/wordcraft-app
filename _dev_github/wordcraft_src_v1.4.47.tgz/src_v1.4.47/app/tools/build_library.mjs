/* build_library.mjs — 📚 이야기 서고(월드 10) 모듈 12개를 content.json 에 넣는다 (v1.4.47)
 *
 * 왜 스크립트로 만드나: 문항을 손으로 JSON 에 붙여 넣으면 id 규칙·정답 위치 분포·스텝 구조가
 * 사람마다 달라진다. 저작은 밴드별 원고(bands_*.json)에서 하고, **구조는 여기서 한 번만 정한다.**
 *
 * 공학 제약(지정해서 만든 것):
 *  · 멱등성  같은 원고면 항상 같은 content.json 이 나온다(난수·시각 의존 없음).
 *            이미 들어 있으면 같은 자리에 덮어쓴다 — 두 번 돌려도 모듈이 24개가 되지 않는다.
 *  · 원자성  .tmp 에 쓰고 마지막에 이름을 바꾼다.
 *  · 되돌림  기존 content.json 을 .bak_library_<날짜> 로 먼저 복사한다.
 *  · 한계    기존 52개 모듈은 **읽기만** 한다. 한 글자도 고치지 않는다(Dio님 2026-09-03 지시).
 *  · 관찰성  무엇을 몇 개 넣었는지 마지막 줄에 숫자로 남긴다.
 *
 * 사용: node tools/build_library.mjs <bands_1_3.json> <bands_4_6.json>
 */
import { readFileSync, writeFileSync, copyFileSync, renameSync, mkdirSync } from 'node:fs'

const [, , A, B] = process.argv
if (!A || !B) { console.error('사용: node tools/build_library.mjs <bands_1_3.json> <bands_4_6.json>'); process.exit(2) }

const bands = { ...JSON.parse(readFileSync(A, 'utf8')), ...JSON.parse(readFileSync(B, 'utf8')) }
const CONTENT = 'public/content.json'
const content = JSON.parse(readFileSync(CONTENT, 'utf8'))

const BAND_KO = {
  'elem-core': '초등 기초', 'giu-core': '초등 심화', 'bridge': '중학 연결',
  'ms1': '중1', 'ms2': '중2', 'ms3+': '중3 이상',
}

/* 정답 위치 균형 — 저작자가 무의식적으로 0번에 몰아넣는다(밴드 4·5는 실제로 전부 0이었다).
   앱이 실행 중에 보기를 섞긴 하지만(v1.4.46 C1), 그 장치가 언젠가 꺼져도 안전하도록
   **저작 단계에서도** 고르게 돌려 둔다. 회전값은 문항 순번에서 나오므로 매번 같다(멱등). */
function rotate(item, k) {
  const n = item.choices.length
  if (n !== 4) return item
  const shift = k % 4
  const choices = item.choices.map((_, i) => item.choices[(i + shift) % n])
  const answer_idx = (item.answer_idx - shift + n * 2) % n
  return { ...item, choices, answer_idx }
}

const story = (speaker, emoji, lines) => ({ type: 'story', lines: lines.map(t => ({ speaker, emoji, text_ko: t, text_en: null })) })

let counter = 0
const built = []

for (const n of [1, 2, 3, 4, 5, 6]) {
  const b = bands[String(n)]
  const bandKo = BAND_KO[b.band] || b.band

  /* ── 읽기 RD{n} ── */
  const rd = {
    module_id: `RD${n}`, world: 10, order: n,
    title_ko: b.reading.title_ko, subtitle_ko: b.reading.subtitle_ko, emoji: '📖',
    xp_module_clear: 40, estimated_minutes: 10,
    steps: [
      story('사서 링', '📚', [
        `여긴 이야기 서고야. 여기 책들은 ${bandKo} 낱말로 쓰여 있어.`,
        '규칙은 하나뿐이야 — 지문을 먼저 읽고, 답은 지문 안에서 찾아.',
        '지문은 문제 푸는 내내 위에 있어. 헷갈리면 다시 봐도 돼. 그게 반칙이 아니야.',
      ]),
      ...b.reading.passages.map((p, pi) => ({
        type: 'quiz',
        passage: { title_ko: p.title_ko, en: p.en },
        questions: p.questions.map((q, qi) => rotate({
          id: `RD${n}-P${pi + 1}-Q${qi + 1}`,
          q_ko: q.q_ko, choices: q.choices, answer_idx: q.answer_idx, explain_ko: q.explain_ko,
          meme_correct: q.kind === 'inference' ? '지문 안에서 찾아냈네 📖' : '정확해! 📖',
          meme_wrong: '괜찮아, 지문을 한 번만 더 훑어보자',
        }, counter++)),
      })),
    ],
    review_cards: [
      { card_id: `RD${n}-C01`, front: '영어 지문 문제, 어떻게 푸는 거였지?', back: '지문을 먼저 읽고 답은 지문 안에서 찾기. 지문에 없는 말은 답이 아니야.' },
      { card_id: `RD${n}-C02`, front: '추론 문제에서 조심할 것은?', back: '그럴듯해 보여도 지문에 안 나온 내용이면 오답이야.' },
    ],
  }

  /* ── 쓰기 WF{n} ── */
  const wf = {
    module_id: `WF${n}`, world: 10, order: 6 + n,
    title_ko: b.writing.title_ko, subtitle_ko: b.writing.subtitle_ko, emoji: '✍️',
    xp_module_clear: 40, estimated_minutes: 12,
    steps: [
      story('작가 펜', '✍️', [
        `이제 네가 쓸 차례야. ${bandKo} 낱말로 시작해보자.`,
        '먼저 빈칸을 채우고, 그다음엔 네 이야기를 직접 써.',
        '자유 작문에는 정답이 없어. 짧아도 괜찮고, 틀려도 괜찮아 — 쓴 것 자체가 점수야.',
      ]),
      {
        type: 'game', kind: 'choice', prompt_ko: '빈칸에 딱 맞는 낱말을 골라봐',
        items: b.writing.cloze.map((c, ci) => rotate({
          id: `WF${n}-CL${ci + 1}`,
          q_ko: c.q_ko, choices: c.choices, answer_idx: c.answer_idx, explain_ko: c.explain_ko,
          meme_correct: '딱 맞았어 ✍️', meme_wrong: '괜찮아, 뜻을 하나씩 넣어보자',
        }, counter++)),
      },
      {
        type: 'write_free', prompt_ko: '이번엔 네 문장으로 써보자',
        items: b.writing.free.map((f, fi) => ({
          id: `WF${n}-FR${fi + 1}`,
          prompt_ko: f.prompt_ko, hint_ko: f.hint_ko, starter_en: f.starter_en,
          words_ko: f.words, min_words: f.min_words ?? 8,
        })),
      },
    ],
    review_cards: [
      { card_id: `WF${n}-C01`, front: '자유 작문은 뭘 보는 거였지?', back: '정답이 아니라 시도. 영어 단어로 성의 있게 쓰면 XP를 받아.' },
      { card_id: `WF${n}-C02`, front: '영어로 쓰다 막히면?', back: '짧게 한 문장만 써도 돼. 시작 틀(starter)을 그대로 이어 써도 좋아.' },
    ],
  }

  built.push(rd, wf)
}

/* 기존 52개는 손대지 않는다 — 새 12개만 넣거나 같은 자리에 덮어쓴다 */
const before = Object.keys(content.modules).length
for (const m of built) content.modules[m.module_id] = m
const after = Object.keys(content.modules).length

// 백업은 public/ 밖에 둔다 — public/* 는 통째로 dist 에 복사되므로 백업까지 배포물에 실린다(2026-09-03 실측).
mkdirSync('_bak_content', { recursive: true })
copyFileSync(CONTENT, `_bak_content/content.json.bak_library_${new Date().toISOString().slice(0, 10).replace(/-/g, '')}`)
writeFileSync(`${CONTENT}.tmp`, JSON.stringify(content))
renameSync(`${CONTENT}.tmp`, CONTENT)

const q = built.reduce((a, m) => a + m.steps.reduce((s, st) =>
  s + (st.type === 'quiz' ? st.questions.length : st.type === 'game' ? st.items.length : 0), 0), 0)
const fr = built.reduce((a, m) => a + m.steps.reduce((s, st) => s + (st.type === 'write_free' ? st.items.length : 0), 0), 0)
const pas = built.reduce((a, m) => a + m.steps.filter(s => s.type === 'quiz').length, 0)
console.log(`모듈 ${before} → ${after} (신규/갱신 ${built.length}개) · 지문 ${pas} · 4지선다 ${q} · 자유작문 ${fr}`)

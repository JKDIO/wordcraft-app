#!/usr/bin/env python3
"""기사 갤러리 부위 오버레이 레이어 추출 (v1 · 2026-09-03)

무엇을 하나: **같은 캔버스의 두 그림(베이스 / 장비 착용본)을 비교해, 달라진 부분만
투명 PNG로 떼어낸다.** 그 결과가 앱에서 베이스 위에 겹쳐지는 '장비 한 조각'이다.

왜 이 방식인가: `fal-ai/nano-banana-pro/edit` 이 지시한 부위 외 캔버스를 건드리지 않는다는
것을 2026-09-03에 수치로 확인했다(머리 영역 밖 변경 0px). 그래서 "다시 그린 그림에서
달라진 데만 오려낸다"가 성립한다. 모델이 캔버스를 흔들면 이 전제가 깨지므로,
이 스크립트는 **오염도(부위 밖 변경 비율)를 항상 같이 보고하고 상한을 넘으면 실패한다.**

`tools/pixelize.py` 의 CLI 모양을 준용했다(입력 → 출력 → 옵션 → 미리보기).
※ 그 파일은 HERO_SPEC §6이 "이미 구현됨"이라 적었지만 이 소스 트리에는 없다(2026-09-03 확인).
   그래서 코드를 물려받지 못하고 **모양만** 맞췄다.

공학 제약(지정해서 만든 것):
  · 멱등성  같은 입력이면 항상 같은 바이트가 나온다(난수·시각 의존 없음)
  · 원자성  .tmp 에 쓰고 마지막에 이름을 바꾼다 — 중간에 죽어도 반쪽 파일이 남지 않는다
  · 되돌림  기존 출력이 있으면 --force 없이는 덮어쓰지 않는다(있으면 .bak_<날짜> 로 피신)
  · 관찰성  실패 사유가 마지막 한 줄로 판별된다
  · 한계    캔버스 불일치·오염도 초과·빈 레이어는 전부 0이 아닌 코드로 끝난다

사용:
  python3 tools/overlay_layer.py base.png helm_t3.png out/helm_t3.png \
          --region head --preview

  python3 tools/overlay_layer.py base.png boots_t1.png out/boots_t1.png \
          --region feet --thresh 24 --min-blob 40
"""
import argparse
import os
import shutil
import sys
from datetime import date

import numpy as np
from PIL import Image
from scipy import ndimage

# 슬롯이 캔버스의 어디에 오는가 — 세로 비율(위, 아래). 오염도를 재는 기준이 된다.
# 값의 근거: 896x1200 정본 캔버스에서 파일럿(helm t3)의 변경 바운딩박스가 y 13~257 이었다.
# 넉넉히 잡되, "장비가 엉뚱한 데를 칠했는가"는 잡히도록 둔다.
REGIONS = {
    "head":     (0.00, 0.28),   # helm
    "shoulder": (0.14, 0.42),   # shoulder
    "torso":    (0.14, 0.62),   # chest
    "cloak":    (0.08, 0.95),   # cloak — 등 뒤로 길게 떨어진다
    "hands":    (0.35, 0.75),   # gloves
    "feet":     (0.72, 1.00),   # boots (발목까지)
    # ★2026-09-03 실측으로 추가★ HERO_SPEC t3 의 boots 는 "steel greaves and boots" 라 정강이를 덮는다.
    # feet(0.72~) 로 재면 오염도 28.31%로 실패했는데, 이건 모델 잘못이 아니라 **구역 정의가 옷을 못 따라간 것**이다.
    # 게이트는 의도한 모양을 담아야지, 임의의 선을 지키게 하면 옳은 산출물을 떨어뜨린다.
    "legs":     (0.55, 1.00),   # greaves + boots
    "any":      (0.00, 1.00),   # 오염도 검사를 끄고 싶을 때만
}


def load_rgb(path: str) -> np.ndarray:
    with Image.open(path) as im:
        return np.asarray(im.convert("RGB")).astype(np.int16)


def main() -> int:
    ap = argparse.ArgumentParser(description="베이스와 착용본의 차분으로 장비 레이어를 뽑는다")
    ap.add_argument("base")
    ap.add_argument("equipped")
    ap.add_argument("out")
    ap.add_argument("--region", default="any", choices=sorted(REGIONS))
    ap.add_argument("--thresh", type=int, default=24,
                    help="이 값보다 큰 채널 차이만 '달라졌다'로 본다 (기본 24)")
    ap.add_argument("--min-blob", type=int, default=40,
                    help="이보다 작은 점 덩어리는 노이즈로 버린다 (기본 40px)")
    ap.add_argument("--close", type=int, default=9,
                    help="구멍 메우기 크기. 장비 안쪽이 베이스와 색이 비슷하면 뚫리는데 이걸로 막는다")
    ap.add_argument("--contamination-max", type=float, default=0.05,
                    help="부위 밖 변경이 전체 변경의 이 비율을 넘으면 실패 (기본 5%%)")
    ap.add_argument("--preview", action="store_true", help="자홍색 배경 합성본을 함께 저장한다")
    ap.add_argument("--force", action="store_true", help="기존 출력을 덮어쓴다")
    a = ap.parse_args()

    base, eq = load_rgb(a.base), load_rgb(a.equipped)
    if base.shape != eq.shape:
        print(f"✗ 캔버스가 다르다: base {base.shape[1]}x{base.shape[0]} vs "
              f"equipped {eq.shape[1]}x{eq.shape[0]} — 같은 캔버스여야 겹칠 수 있다")
        return 2
    h, w = base.shape[:2]

    diff = np.abs(base - eq).max(axis=2)
    mask = diff > a.thresh

    # ① 작은 점 덩어리 제거 — 모델이 캔버스 전체에 남기는 미세 노이즈다
    lab, n = ndimage.label(mask)
    if n:
        sizes = ndimage.sum(mask, lab, range(1, n + 1))
        drop = np.isin(lab, (np.nonzero(sizes < a.min_blob)[0] + 1))
        removed = int(drop.sum())
        mask &= ~drop
    else:
        removed = 0

    if not mask.any():
        print("✗ 달라진 곳이 없다 — 장비가 실제로 그려지지 않았거나 두 그림이 같다")
        return 3

    # ② 구멍 메우기 — 투구 안쪽처럼 베이스와 색이 겹치는 데가 반투명으로 뚫리는 것을 막는다
    if a.close > 1:
        st = np.ones((a.close, a.close), bool)
        mask = ndimage.binary_closing(mask, structure=st)
        mask = ndimage.binary_fill_holes(mask)

    # ③ 오염도 — 이 슬롯이 있어야 할 세로 구간 밖을 얼마나 칠했는가
    top, bot = REGIONS[a.region]
    band = np.zeros(h, bool)
    band[int(h * top):int(np.ceil(h * bot))] = True
    outside = int(mask[~band].sum())
    total = int(mask.sum())
    ratio = outside / total

    ys, xs = np.nonzero(mask)
    print(f"캔버스 {w}x{h} · 변경 {total:,}px ({total / (h * w) * 100:.2f}%) · "
          f"노이즈 제거 {removed:,}px")
    print(f"바운딩박스 x {xs.min()}~{xs.max()} · y {ys.min()}~{ys.max()}")
    print(f"부위 '{a.region}'({top:.2f}~{bot:.2f}) 밖 변경 {outside:,}px ({ratio * 100:.2f}%)")
    if ratio > a.contamination_max:
        print(f"✗ 오염도 {ratio * 100:.2f}% > 상한 {a.contamination_max * 100:.2f}% — "
              f"모델이 부위 밖을 다시 그렸다. 프롬프트를 조이고 재생성할 것")
        return 4

    # ④ 알파 — 경계는 차이에 비례해 부드럽게, 안쪽은 불투명하게
    alpha = np.clip((diff - a.thresh) * 4, 0, 255).astype(np.uint8)
    alpha[mask] = 255
    alpha[~mask] = 0
    rgba = np.dstack([eq.astype(np.uint8), alpha])

    # ⑤ 원자적 쓰기 + 되돌림
    os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
    if os.path.exists(a.out):
        if not a.force:
            print(f"✗ 이미 있다: {a.out} — 덮어쓰려면 --force")
            return 5
        shutil.copy2(a.out, f"{a.out}.bak_overlay_{date.today():%Y%m%d}")
    tmp = f"{a.out}.tmp"
    # format 을 명시한다 — .tmp 확장자로는 PIL 이 형식을 못 알아낸다(2026-09-03에 여기서 죽었다)
    Image.fromarray(rgba, "RGBA").save(tmp, format="PNG")
    os.replace(tmp, a.out)

    if a.preview:
        prev = f"{os.path.splitext(a.out)[0]}_on_magenta.png"
        bg = Image.new("RGBA", (w, h), (255, 0, 255, 255))
        Image.alpha_composite(bg, Image.fromarray(rgba, "RGBA")).convert("RGB").save(prev)
        print(f"미리보기: {prev}")

    print(f"✓ 레이어 저장: {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

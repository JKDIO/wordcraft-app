const BUN = process.env.BUN_BIN || '/root/.bun/bin/bun'
/* write_check.mjs — ✍️ 자유 작문 채점기 검사 (v1.4.47 신설)
 *
 * 이 기능은 이 앱에서 **모델이 아이에게 직접 말을 거는 첫 기능**이다. 그래서 검사하는 것도 다르다:
 * "정답을 맞혔는가"가 아니라 **"규칙이 한 곳에만 있는가 · 실패했을 때 아이가 멈추지 않는가"** 를 본다.
 *
 * 특히 XP 15는 세 곳에 나온다 — 앱(xp.ts) · 서버(Edge Function) · 관제실 파생(answerXpOf).
 * 어느 하나만 바뀌면 "아이 화면 XP ≠ 아빠 화면 XP"가 조용히 생긴다(L12·L27에서 두 번 겪은 사고 유형).
 * 그 세 곳이 실제로 같은 값인지 여기서 잡는다.
 *
 * 사용: node write_check.mjs   (실패하면 0이 아닌 코드로 끝난다)
 */
import { execSync } from 'node:child_process'
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs'

mkdirSync('.verify', { recursive: true })
writeFileSync('.verify/wf_entry.ts',
  `import * as W from '../src/lib/writeGrade'\nimport * as X from '../src/lib/xp'\n` +
  `// @ts-ignore\nglobalThis.W = W\n// @ts-ignore\nglobalThis.X = X\n`)
execSync(`${BUN} build .verify/wf_entry.ts --outfile .verify/wf_bundle.js --target node`, { stdio: 'inherit' })
await import('./.verify/wf_bundle.js')
const W = globalThis.W
const X = globalThis.X

let fail = 0
const ok = (cond, label, extra = '') => {
  if (cond) console.log(`  ✓ ${label}`)
  else { console.log(`  ✗ ${label} ${extra}`); fail++ }
}

const src = f => readFileSync(f, 'utf8')
const APP_XP = src('src/lib/xp.ts')
const STEP = src('src/engine/StepRunner.tsx')
const WFUI = src('src/engine/WriteFree.tsx')
const ADMIN = src('src/screens/AdminPage.tsx')
const CONTENT_TS = src('src/lib/content.ts')
const FN_PATH = '../supabase/functions/write-grade/index.ts'

console.log('── ① XP 값이 앱·서버·관제실에서 같은가 (L12) ──')
{
  ok(X.XP.writeFree === 15, 'xp.ts 의 writeFree = 15', `→ ${X.XP.writeFree}`)
  ok(X.answerXpOf('write_free', true) === X.XP.writeFree,
    '성의 있게 썼으면 writeFree XP', `→ ${X.answerXpOf('write_free', true)}`)
  ok(X.answerXpOf('write_free', false) === 0,
    '무성의면 0 (감점 아님 — 그냥 안 준다)', `→ ${X.answerXpOf('write_free', false)}`)

  // ★서버와의 대조★ — 서버가 15가 아닌 값을 주기 시작하면 관제실 파생 XP와 갈라진다.
  ok(existsSync(FN_PATH), '서버 함수 소스 사본이 저장소에 있다 (L40 — 배포본만 있고 소스가 없으면 안 된다)')
  if (existsSync(FN_PATH)) {
    const FN = src(FN_PATH)
    const m = FN.match(/const\s+XP_WRITE\s*=\s*(\d+)/)
    ok(!!m, '서버에 XP_WRITE 상수가 있다')
    ok(m && Number(m[1]) === X.XP.writeFree,
      '★서버 XP_WRITE == 앱 XP.writeFree★', m ? `→ 서버 ${m[1]} vs 앱 ${X.XP.writeFree}` : '')
    ok(/xp\s*!==\s*0\s*&&\s*xp\s*!==\s*XP_WRITE/.test(FN),
      '★서버가 규격 밖 XP를 거부한다 (모델이 100을 말해도 안 받는다)')
    ok(/learner_id|callerOwnsLearner/.test(FN) && /callerOwnsLearner\(authHeader/.test(FN),
      '★서버가 호출자 권한을 확인한다 (D46-1 재발 방지)')
    ok(!/parent_queue/.test(FN.split('return json({')[2] ?? ''),
      '보호자 검토 문구를 아이에게 돌려주지 않는다')
  }
}

console.log('── ② 규칙 복사본이 화면에 되살아나지 않았는가 (L27·L51) ──')
{
  // 화면이 15를 직접 적으면, 다음에 값이 바뀔 때 화면만 옛 숫자를 말한다.
  const hard = WFUI.match(/[^\w.]15\b/g) || []
  ok(hard.length === 0, '★WriteFree.tsx 에 XP 숫자를 직접 적지 않았다 (XP.writeFree 를 부른다)',
    hard.length ? `→ ${hard.length}곳` : '')
  ok(/XP\.writeFree/.test(WFUI), 'WriteFree.tsx 가 xp.ts 의 값을 부른다')
  ok(/from '\.\.\/lib\/writeGrade'/.test(WFUI), '판정은 writeGrade.ts 에 맡긴다')
  // 성의 판정을 화면이 다시 구현하면 서버와 갈라진다.
  ok(!/[aeiou]/.test(WFUI.replace(/[^/]*\/\/.*/g, '').match(/\/\[aeiou\]\//)?.[0] ?? ''),
    '화면이 성의 판정 규칙을 복사하지 않았다')
}

console.log('── ③ 자유 작문이 정답률·스트릭을 오염시키지 않는가 (L28) ──')
{
  // 자유 작문의 is_correct 는 '맞았다'가 아니라 '성의 있게 썼다'이다.
  // 이걸 정답률에 넣으면 **쓰기만 해도 정답률이 오르는** 거짓 지표가 된다.
  const statsBlock = STEP.split('setStats(s =>')[0].slice(-600)
  ok(/write_free/.test(statsBlock), "★정답률 집계에서 write_free 를 제외한다")
  const streakBlock = STEP.split('streakRef.current += 1')[0].slice(-400)
  ok(/write_free/.test(streakBlock), '★연속 정답 스트릭에서도 제외한다')
  ok(/activity_type: 'write_free'/.test(STEP), "StepRunner 가 activity_type='write_free' 로 기록한다")
  ok(!/correct_answer:\s*[^,\n]*\n?\s*\}\)\s*\}\)\s*\n\s*onFinish=\{next\}\s*\n\s*\/>\s*\n\s*\)\}\s*\n\s*\{unit\.kind === 'speak'/.test(STEP)
    || !/write_free[\s\S]{0,400}correct_answer:/.test(STEP),
    "★정답이 없으므로 correct_answer 를 만들어 내지 않는다")
}

console.log('── ④ 관제실이 이 기록을 볼 수 있는가 (CONTRACT §14) ──')
{
  ok(/write_free: '✍️자유 작문'/.test(ADMIN),
    "★typeLabel 에 write_free 가 있다 (없으면 아빠 화면에 원문 문자열이 그대로 뜬다)")
  ok(/write_grade_logs/.test(ADMIN), '관제실이 감사 로그를 조회한다')
  ok(/function WritingTab/.test(ADMIN), '작문 감사 탭이 있다')
  ok(/id: 'writing'/.test(ADMIN), '탭 메뉴에 노출된다 (조회할 자리가 실제로 있다)')
  // 조회에 상한·정렬이 없으면 기록이 쌓였을 때 조용히 잘린다(L31).
  const q = ADMIN.match(/get\('작문 채점'[^\n]*/)?.[0] ?? ''
  ok(/order=/.test(q), '작문 조회에 정렬이 있다 (L31)')
  ok(/,\s*\d+\)/.test(q), '작문 조회에 상한이 있다 (L31)')
}

console.log('── ⑤ 채점이 실패해도 아이가 멈추지 않는가 (L47) ──')
{
  // "짧아서 무성의"는 절대 아니다 — §C-3 판정 절차 1이 명시적으로 금지한다.
  ok(W.localFallback('I ate lunch').xp === X.XP.writeFree, '★짧은 글도 성의 있는 시도로 본다')
  ok(W.localFallback('cat').xp === X.XP.writeFree, '★한 단어라도 실제 영단어면 XP를 준다')
  ok(W.localFallback('asdfjkl').xp === 0, '키보드 낙서는 XP 없음')
  ok(W.localFallback('').xp === 0, '빈 글은 XP 없음')
  ok(W.localFallback('I ate lunch').fallback === true, '폴백이었음을 숨기지 않는다')
  ok(!/처벌|틀렸|못 했|안 돼/.test(W.localFallback('asdfjkl').feedback_ko),
    '★무성의 판정에도 질책 문구가 없다 (헌법 1조)')
}

console.log('── ⑥ 단어 세기 (안내 문구·판정이 같은 함수를 쓴다) ──')
{
  ok(W.wordCount('I ate lunch') === 3, '3단어')
  ok(W.wordCount('  I   ate   lunch  ') === 3, '공백이 많아도 3단어')
  ok(W.wordCount("I don't know") === 3, "축약형도 한 단어")
  ok(W.wordCount('') === 0, '빈 글은 0')
  ok(W.wordCount('안녕 hello 반가워') === 1, '한글은 세지 않는다 (영어 작문이므로)')
  ok(W.DEFAULT_MIN_WORDS > 0, '권장 단어 수 기본값이 있다')
}

console.log('── ⑦ 콘텐츠 규격 (있을 때만 — 없으면 개수를 밝힌다) ──')
{
  ok(/write_free/.test(CONTENT_TS) && /WriteFreeItem/.test(CONTENT_TS), 'content.ts 에 타입이 있다')
  const cj = 'public/content.json'
  if (!existsSync(cj)) {
    console.log('  … content.json 없음 — 콘텐츠 검사 건너뜀')
  } else {
    const C = JSON.parse(readFileSync(cj, 'utf8'))
    const items = []
    for (const [mid, m] of Object.entries(C.modules ?? {})) {
      for (const s of m.steps ?? []) {
        if (s.type === 'write_free') for (const it of s.items ?? []) items.push({ mid, it })
      }
    }
    console.log(`  … 자유 작문 문항 ${items.length}개`)
    if (items.length) {
      const ids = items.map(x => x.it.id)
      ok(new Set(ids).size === ids.length, '★문항 id 가 전부 유일하다 (겹치면 기록이 덮인다)')
      ok(items.every(x => typeof x.it.prompt_ko === 'string' && x.it.prompt_ko.trim().length > 0),
        '모든 문항에 미션 문구가 있다')
      ok(items.every(x => (x.it.min_words ?? 8) >= 1 && (x.it.min_words ?? 8) <= 60),
        '권장 단어 수가 상식 범위다')
      // ★지어낸 단어 금지★ — 힌트 칩은 vocab.json 에 실제로 있는 단어만 쓴다(Dio님 지시).
      if (existsSync('public/vocab.json')) {
        const V = JSON.parse(readFileSync('public/vocab.json', 'utf8'))
        const known = new Set()
        for (const p of Object.values(V.packs ?? {})) for (const w of p.words ?? []) known.add(String(w.w).toLowerCase())
        const bad = []
        for (const { mid, it } of items) for (const w of it.words_ko ?? []) {
          if (!known.has(String(w).toLowerCase())) bad.push(`${mid}/${it.id}:${w}`)
        }
        ok(bad.length === 0, '★단어 힌트가 전부 vocab.json 의 실제 단어다 (지어낸 단어 금지)',
          bad.length ? `→ ${bad.slice(0, 6).join(', ')}${bad.length > 6 ? ` 외 ${bad.length - 6}` : ''}` : '')
      }
    }
  }
}

console.log()
if (fail) { console.log(`❌ write_check 실패 ${fail}건`); process.exit(1) }
console.log('✅ write_check 통과')

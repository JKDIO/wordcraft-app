// Edge Function `write-grade` — 자유 작문 채점기 (v1.4.47 신설)
//
// 왜 서버에 두는가:
//   ① API 키가 아이 폰 번들에 들어가면 안 된다.
//   ② 채점 결과(XP·판정)를 클라이언트가 써넣을 수 있으면 위조가 된다 —
//      그래서 write_grade_logs 에는 INSERT 정책이 없고, 이 함수(service role)만 쓴다.
//
// 개인정보 최소화(중요): 채점 모델에게 보내는 것은 **문항 프롬프트와 아이가 쓴 영어 문장뿐**이다.
//   learner_id·닉네임·기기 정보는 외부로 나가지 않는다.
//
// 실패해도 아이 경험을 막지 않는다(L47 — 조용한 실패 금지, 단 아이에게는 조용하게):
//   T2 실패 → T1 폴백 → 둘 다 실패하면 규칙 기반 폴백으로 XP는 주고 fallback=true 로 남긴다.
//   아빠는 관제실에서 fallback 건수를 본다.
import "jsr:@supabase/functions-js/edge-runtime.d.ts"
import { SYSTEM_PROMPT } from "./prompt.ts"

const SUPA_URL = Deno.env.get("SUPABASE_URL")!
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!
const OR_KEY = Deno.env.get("OPENROUTER_API_KEY") ?? ""

/** 채점 레인 — 2026-08-30 실측으로 정한 순서(1건당 약 1.1원 / 0.065원).
 *  glm-4.7-flash 는 한국어가 깨져 후보에서 뺐다(실측 근거: 세션 로그). */
const MODEL_PRIMARY = "deepseek/deepseek-v4-pro"
const MODEL_FALLBACK = "deepseek/deepseek-v4-flash-0731"

const MAX_TEXT = 1200        // 아이 글 길이 상한(글자). 넘으면 자른다.
const DAILY_CALL_CAP = 30    // 한 아이 하루 채점 호출 상한 — 비용 폭주 방지
const XP_WRITE = 15          // xp.ts 의 XP.writeFree 와 반드시 같아야 한다

/* ★D47-6★ 700이었다. 두 모델 다 추론 모델이라 추론 토큰이 이 상한을 같이 먹고,
   flash@700 은 reasoning 700/700 으로 content 가 통째로 사라졌다(서버 실측). 근거는 결함대장 §5. */
const MAX_TOKENS = 2000

interface Grade {
  xp: number
  xp_reason: string
  feedback_ko: string
  confidence_flag: "high" | "medium" | "low"
  parent_queue: string
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    },
  })

/** 호출자가 정말 그 아이의 기기/보호자인가 — 남의 learner_id 로 채점·기록하는 것을 막는다(D46-1). */
async function callerOwnsLearner(authHeader: string, learnerId: string): Promise<boolean> {
  try {
    const res = await fetch(`${SUPA_URL}/rest/v1/rpc/wc_my_learner_ids`, {
      method: "POST",
      headers: { apikey: ANON_KEY, Authorization: authHeader, "Content-Type": "application/json" },
      body: "{}",
    })
    if (!res.ok) return false
    const ids = await res.json()
    return Array.isArray(ids) && ids.some((v: unknown) => String(v) === learnerId)
  } catch { return false }
}

/** 오늘 이 아이가 몇 번 채점을 불렀는가 (KST 기준 하루) */
async function todayCallCount(learnerId: string): Promise<number> {
  const kstNow = new Date(Date.now() + 9 * 3600 * 1000)
  const kstMidnightUtc = new Date(Date.UTC(
    kstNow.getUTCFullYear(), kstNow.getUTCMonth(), kstNow.getUTCDate(), 0, 0, 0,
  ).valueOf() - 9 * 3600 * 1000).toISOString()
  const res = await fetch(
    `${SUPA_URL}/rest/v1/write_grade_logs?learner_id=eq.${learnerId}&created_at=gte.${kstMidnightUtc}&select=id`,
    { headers: { apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}`, Prefer: "count=exact", Range: "0-0" } },
  )
  const cr = res.headers.get("content-range")
  const n = cr ? Number(cr.split("/")[1]) : NaN
  return Number.isFinite(n) ? n : 0
}

/** 모델 호출 1회. 스키마를 지키지 못하면 null 을 돌려준다(추측해서 채우지 않는다). */
async function gradeWith(model: string, promptKo: string, text: string): Promise<Grade | null> {
  const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${OR_KEY}`,
      "Content-Type": "application/json",
      "X-Title": "WordCraft write-grade",
    },
    body: JSON.stringify({
      model,
      max_tokens: MAX_TOKENS,
      temperature: 0.4,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: `문항 프롬프트: ${promptKo}\n\n학생이 쓴 글:\n${text}` },
      ],
    }),
  })
  if (!res.ok) throw new Error(`openrouter ${res.status}: ${(await res.text()).slice(0, 300)}`)
  const body = await res.json()
  const ch = body?.choices?.[0]
  // D47-6: 추론 토큰이 상한을 먹으면 content 가 잘리거나 사라진다. 그때 "형식 위반"이라고
  // 적으면 다음 사람이 프롬프트를 의심한다 — 실제 원인은 상한이다. 그래서 따로 던진다.
  if (ch?.finish_reason === "length") throw new Error(`잘림(max_tokens ${MAX_TOKENS} 소진)`)
  const raw = ch?.message?.content
  if (typeof raw !== "string") return null
  return parseGrade(raw)
}

/** 모델 출력 → Grade. 코드블록·앞뒤 잡소리를 걷어내고, 값이 규격을 벗어나면 null. */
export function parseGrade(raw: string): Grade | null {
  let s = raw.trim()
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/)
  if (fence) s = fence[1].trim()
  const open = s.indexOf("{"), close = s.lastIndexOf("}")
  if (open < 0 || close <= open) return null
  let o: Record<string, unknown>
  try { o = JSON.parse(s.slice(open, close + 1)) } catch { return null }

  const xp = Number(o.xp)
  const fb = typeof o.feedback_ko === "string" ? o.feedback_ko.trim() : ""
  const cf = String(o.confidence_flag ?? "high")
  // XP 는 0 또는 15만 허용한다 — 모델이 7이나 100을 말해도 받지 않는다.
  if (xp !== 0 && xp !== XP_WRITE) return null
  if (!fb) return null
  return {
    xp,
    xp_reason: typeof o.xp_reason === "string" ? o.xp_reason.slice(0, 300) : "",
    feedback_ko: fb.slice(0, 1000),
    confidence_flag: cf === "medium" || cf === "low" ? cf : "high",
    parent_queue: typeof o.parent_queue === "string" ? o.parent_queue.slice(0, 500) : "불필요",
  }
}

/** 채점 API가 전부 실패했을 때. 아이를 세워두지 않는다 — 성의 판정만 하고 XP는 준다. */
export function ruleFallback(text: string): Grade {
  const words = (text.toLowerCase().match(/[a-z']+/g) ?? []).filter(w => w.length > 1)
  /* ★"모음이 있으면 단어"는 틀렸다★ — `asdfjkl` 에도 a 가 있다(2026-08-30 write_check 가 잡음).
     영어 단어는 자음이 다섯 개 연달아 오지 않는다(strength 의 'ngth' 도 넷). 두 조건을 함께 본다.
     앱의 writeGrade.looksLikeWords 와 **같은 규칙**이어야 한다 — 온·오프라인 판정이 갈리면 안 된다. */
  const looksReal = words.some(w => /[aeiouy]/.test(w) && !/[^aeiouy]{5}/.test(w))
  return looksReal
    ? {
      xp: XP_WRITE,
      xp_reason: "채점 도우미가 잠깐 쉬는 중이라 성의만 확인했어",
      feedback_ko: "글 잘 썼어! 지금은 자세한 피드백을 못 만들어 줬는데, 쓴 건 그대로 저장했으니까 아빠가 꼭 읽어볼 거야. 👍",
      confidence_flag: "low",
      parent_queue: "채점 API 실패 — 사람이 직접 읽어주세요",
    }
    : {
      xp: 0,
      xp_reason: "영어 단어가 하나도 없어",
      feedback_ko: "앗, 아직 안 쓴 것 같아! 오늘 있었던 일 중에 하나만 골라서, 짧아도 좋으니까 영어로 한 문장 써볼까?",
      confidence_flag: "low",
      parent_queue: "채점 API 실패 — 사람이 직접 읽어주세요",
    }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return json({}, 200)

  let payload: Record<string, unknown>
  try { payload = await req.json() } catch { return json({ error: "본문이 JSON이 아니야" }, 400) }

  // 설정 점검용 — 키가 꽂혀 있는지만 알려준다(키 값은 절대 내보내지 않는다).
  if (payload.probe === true) {
    return json({
      ok: true,
      openrouter_key: OR_KEY ? "설정됨" : "없음",
      model_primary: MODEL_PRIMARY,
      model_fallback: MODEL_FALLBACK,
    })
  }

  const authHeader = req.headers.get("Authorization") ?? ""
  const learnerId = String(payload.learner_id ?? "")
  const moduleId = String(payload.module_id ?? "")
  const questionId = String(payload.question_id ?? "")
  const promptKo = String(payload.prompt_ko ?? "")
  const text = String(payload.text ?? "").slice(0, MAX_TEXT)

  if (!/^[0-9a-f-]{36}$/i.test(learnerId) || !moduleId || !questionId) {
    return json({ error: "learner_id·module_id·question_id가 필요해" }, 400)
  }
  if (!text.trim()) return json({ error: "쓴 글이 비어 있어" }, 400)
  if (!authHeader) return json({ error: "인증이 없어" }, 401)
  if (!await callerOwnsLearner(authHeader, learnerId)) {
    return json({ error: "이 학습자를 채점할 권한이 없어" }, 403)
  }
  if (await todayCallCount(learnerId) >= DAILY_CALL_CAP) {
    return json({ error: "오늘 채점은 여기까지야. 내일 또 쓰자!", capped: true }, 429)
  }

  let grade: Grade | null = null
  let usedModel = ""
  let fallback = false
  const errors: string[] = []

  if (OR_KEY) {
    for (const m of [MODEL_PRIMARY, MODEL_FALLBACK]) {
      try {
        const g = await gradeWith(m, promptKo, text)
        if (g) { grade = g; usedModel = m; break }
        errors.push(`${m}: 형식 위반`)
      } catch (e) { errors.push(`${m}: ${String(e).slice(0, 200)}`) }
    }
  } else {
    errors.push("OPENROUTER_API_KEY 없음")
  }
  if (!grade) { grade = ruleFallback(text); usedModel = "rule-fallback"; fallback = true }

  // 감사 로그 — service role 로만 쓴다. 실패해도 아이 화면은 진행시킨다.
  let logged = true
  try {
    const res = await fetch(`${SUPA_URL}/rest/v1/write_grade_logs`, {
      method: "POST",
      headers: {
        apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}`,
        "Content-Type": "application/json", Prefer: "return=minimal",
      },
      body: JSON.stringify({
        learner_id: learnerId, module_id: moduleId, question_id: questionId,
        prompt_ko: promptKo.slice(0, 500), student_text: text,
        xp: grade.xp, xp_reason: grade.xp_reason, feedback_ko: grade.feedback_ko,
        confidence_flag: grade.confidence_flag, parent_queue: grade.parent_queue,
        model: usedModel, audit_mode: true, fallback,
      }),
    })
    if (!res.ok) logged = false
  } catch { logged = false }

  // parent_queue 는 아이에게 보내지 않는다 — 보호자 검토용 문구다.
  return json({
    xp: grade.xp,
    feedback_ko: grade.feedback_ko,
    confidence_flag: grade.confidence_flag,
    fallback,
    logged,
    // 진단용. 아이 화면에는 쓰지 않는다.
    errors: errors.length ? errors : undefined,
  })
})

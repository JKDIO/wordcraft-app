// ★뱃지 판정 검사★ — ① 규칙 복사본 부활 감시(L27) ② 모든 뱃지가 실제로 도달 가능한지
//   ③ 정의와 규칙의 id 집합이 어긋나지 않는지 ④ 진행도 함수가 터지지 않는지
import './_b_entry_out.js'
import fs from 'fs'
const B = globalThis.B
const fail = []

// ① 관제실이 규칙을 자기 파일에 복사해 두지 않았는가 (L27)
const adm = fs.readFileSync('src/screens/AdminPage.tsx','utf8')
if (/earnedBadges\.add\(/.test(adm)) fail.push('AdminPage.tsx: 뱃지 규칙을 자기 파일에 복사해 뒀다(L27 위반)')
if (!/earnedFrom\(facts\)/.test(adm)) fail.push('AdminPage.tsx: 공용 판정 earnedFrom()을 쓰지 않는다')

// ② 정의 ↔ 규칙 id 집합 일치 (오타로 영영 못 받는 뱃지 방지)
const zero = { modulesDone:[], perfectModule:false, diagDone:0, streak:0, bossWins:0, reviewCorrect:0,
  balanceDays:0, forgeFound:0, runeChapters:0, vocabPacks:[], vocabPerfect:0, golems:0,  legendWords:0, sortPerfect:0, rapidBest:0 }
const packIds = n => Array.from({length:n},(_,i)=>`V${Math.floor(i/20)+1}-${String(i%20+1).padStart(2,'0')}`)
const MAX = { modulesDone:['A1'], perfectModule:true, diagDone:9, streak:99, bossWins:99, reviewCorrect:9999,
  balanceDays:99, forgeFound:99, runeChapters:99, vocabPacks:packIds(200), vocabPerfect:99, golems:99,
  legendWords:9999, sortPerfect:99, rapidBest:99 }
const all = new Set(B.earnedFrom(MAX))
const defined = Object.keys(B.BADGE_DEFS)
for (const id of defined) if (!all.has(id) && !id.startsWith('world')) fail.push(`정의에는 있는데 규칙이 절대 주지 않는 뱃지: ${id}`)
for (const id of all) if (!defined.includes(id)) fail.push(`규칙이 주는데 정의가 없는 뱃지: ${id}`)
if (B.earnedFrom(zero).length !== 0) fail.push('아무것도 안 했는데 뱃지가 나온다: '+B.earnedFrom(zero))

// ③ 그룹 누락
for (const [id,b] of Object.entries(B.BADGE_DEFS)) {
  if (!B.BADGE_GROUPS.includes(b.group)) fail.push(`${id}: 알 수 없는 그룹 '${b.group}'`)
  for (const k of ['emoji','name','desc','hint']) if (!b[k]) fail.push(`${id}: ${k} 비어 있음`)
}

// ④ 경계값 — 한 칸 모자라면 안 나오고, 딱 맞으면 나온다
const cases = [
  ['vocab_first', {vocabPacks:packIds(1)}, {vocabPacks:[]}],
  ['vocab_10', {vocabPacks:packIds(10)}, {vocabPacks:packIds(9)}],
  ['vocab_200', {vocabPacks:packIds(200)}, {vocabPacks:packIds(199)}],
  ['guardian_first', {vocabPacks:packIds(20)}, {vocabPacks:packIds(19)}],
  ['guardian_5', {vocabPacks:packIds(100)}, {vocabPacks:packIds(99)}],
  ['guardian_all', {vocabPacks:packIds(200)}, {vocabPacks:packIds(180)}],
  ['golem_first', {golems:1}, {golems:0}],
  ['golem_10', {golems:10}, {golems:9}],
  ['golem_all', {golems:40}, {golems:39}],
  ['vocab_perfect_5', {vocabPerfect:5}, {vocabPerfect:4}],
  ['vocab_perfect_25', {vocabPerfect:25}, {vocabPerfect:24}],
  ['wordmon_legend_10', {legendWords:10}, {legendWords:9}],
  ['wordmon_legend_50', {legendWords:50}, {legendWords:49}],
  ['sort_perfect_5', {sortPerfect:5}, {sortPerfect:4}],
  ['rapid_20', {rapidBest:20}, {rapidBest:19}],
  ['rune_5', {runeChapters:5}, {runeChapters:4}],
  ['forge_20', {forgeFound:20}, {forgeFound:19}],
]
for (const [id, on, off] of cases) {
  if (!B.earnedFrom({...zero, ...on}).includes(id)) fail.push(`${id}: 조건을 채웠는데 안 나온다`)
  if (B.earnedFrom({...zero, ...off}).includes(id)) fail.push(`${id}: 조건 미달인데 나온다`)
}

// ⑤ guardiansFrom — 티어 20팩 규칙
if (B.guardiansFrom(packIds(20)) !== 1) fail.push('guardiansFrom: 20팩 = 수호자 1명이어야 한다')
if (B.guardiansFrom(packIds(19)) !== 0) fail.push('guardiansFrom: 19팩이면 0명이어야 한다')
if (B.guardiansFrom(packIds(200)) !== 10) fail.push('guardiansFrom: 200팩 = 10명이어야 한다')

console.log(`뱃지 ${defined.length}개 · 신규 ${defined.length-17}개`)
console.log(fail.length===0 ? '✅ 뱃지 판정 전 항목 통과 (앱 = 관제실 단일 규칙)' : '❌ 뱃지 판정 실패')
fail.forEach(f=>console.log('  -',f))
process.exit(fail.length?1:0)

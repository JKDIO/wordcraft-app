import { chromium } from 'playwright'
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' })
const p = await b.newPage({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 2 })
const errs = []
p.on('pageerror', e => errs.push(String(e)))
p.on('console', m => { if (m.type() === 'error' && !/404|Failed to load resource|ERR_TUNNEL/.test(m.text())) errs.push(m.text()) })
await p.route('**/*', r => {
  const u = r.request().url()
  if (u.includes('supabase.co') && u.includes('/badges')) return r.fulfill({
    status: 200, contentType: 'application/json',
    body: JSON.stringify([{ badge_id: 'vocab_first' }, { badge_id: 'vocab_10' }, { badge_id: 'golem_first' },
      { badge_id: 'first_module' }, { badge_id: 'streak_3' }, { badge_id: 'wordmon_legend_10' },
      { badge_id: 'sort_perfect_5' }, { badge_id: 'rapid_20' }, { badge_id: 'vocab_perfect_5' }]),
  })
  if (u.includes('supabase.co') && u.includes('.mp3')) return r.fulfill({ status: 200, contentType: 'audio/mpeg', body: Buffer.alloc(64) })
  if (u.includes('supabase.co')) return r.fulfill({ status: 200, contentType: 'application/json', body: '[]' })
  return r.continue()
})
const prog = {}
for (let i = 1; i <= 12; i++) { const id = `V1-${String(i).padStart(2, '0')}`; prog[id] = { module_id: id, status: 'completed', best_score: 95, attempts: 1 } }
prog['GOLEM-T1-1'] = { module_id: 'GOLEM-T1-1', status: 'completed', best_score: 83, attempts: 1 }
prog['GOLEM-T1-2'] = { module_id: 'GOLEM-T1-2', status: 'completed', best_score: 75, attempts: 1 }
await p.addInitScript(st => localStorage.setItem('wordcraft_state_v1', st), JSON.stringify({
  learnerId: 'test-learner', nickname: '예한', xp: 27383, level: 14, streak_days: 4, diagDone: ['D1', 'D2', 'D3', 'D4'],
  placement: 'B21a', progress: prog, bossWins: [], attendance: [], reviewTotal: 62,
  legendWords: Array.from({ length: 11 }, (_, i) => 'vocab:w' + i), sortPerfect: 6, rapidBest: 21, forgeFound: [],
}))
await p.goto('http://127.0.0.1:8099/#/profile', { waitUntil: 'networkidle' })
await p.locator('text=건너뛰기').first().click().catch(() => {})
await p.waitForTimeout(1800)
const t = await p.locator('body').innerText()
console.log('뱃지 도감 헤더:', (t.split('\n').find(l => /뱃지 도감/.test(l)) || '?'))
for (const g of ['모험', '꾸준함', '복습·기억', '단어 대륙', '수호자와 보스']) console.log('  분야', g, ':', t.includes(g))
console.log('획득 표시 — 첫 상륙:', /첫 상륙/.test(t), '· 단어 사냥꾼:', /단어 사냥꾼/.test(t),
  '· 전설 조련사:', /전설 조련사/.test(t), '· 분류의 달인:', /분류의 달인/.test(t), '· 속사왕:', /속사왕/.test(t))
console.log('잠긴 뱃지 개수(실루엣):', await p.locator('.badge-card.silhouette').count())
await p.evaluate(() => window.scrollTo(0, 1500)); await p.waitForTimeout(400)
await p.screenshot({ path: 'badge_dex.png' })
const locked = p.locator('.badge-card.silhouette').first()
await locked.scrollIntoViewIfNeeded(); await locked.click(); await p.waitForTimeout(400)
const t2 = await p.locator('body').innerText()
console.log('잠긴 뱃지 탭 → 획득 조건 노출:', /🎯/.test(t2))
await p.screenshot({ path: 'badge_reveal.png' })
await b.close()
console.log('JS 오류:', errs.length); errs.slice(0, 5).forEach(e => console.log(' -', e))

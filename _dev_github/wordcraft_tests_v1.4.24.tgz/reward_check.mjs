// v1.4.22 보상 로드맵 검사 — 규칙 단일화(L27) + 경계값 + 입력 검증
//
// 왜 있나: XP·뱃지에서 같은 규칙이 두 곳에 복사됐다가 한쪽만 고쳐져 조용히 갈라진 사고가 두 번 있었다.
// 보상 판정("도달했는가 / 얼마 남았는가")도 학습자 앱·관제실 두 곳에서 쓰이므로 같은 위험이 있다.
// 이 검사는 ① 복사본이 부활하면 실패하고 ② 경계값을 실제로 재본다.
import fs from 'fs'

let fail = 0
const ok = (cond, msg) => { if (!cond) { console.log('  ❌ ' + msg); fail++ } }

/* ── ① 규칙 복사본 부활 감시 ─────────────────────────────
   threshold_xp 비교(도달 판정)는 lib/rewards.ts 안에서만 일어나야 한다.
   소비자 파일(관제실·학습자 화면)에서 직접 비교하면 규칙이 두 벌이 된다. */
const CONSUMERS = ['src/screens/AdminPage.tsx', 'src/screens/RewardBoard.tsx', 'src/screens/WorldMap.tsx']
const ALLOW = ['src/App.tsx'] // 하단 네비 뱃지 카운트 1곳만 허용(단순 카운트, 표시 전용 — 아래 주석 참조)
for (const f of CONSUMERS) {
  const src = fs.readFileSync(f, 'utf8')
  // "xp >= g.threshold_xp" 류의 도달 판정 복사본 (화살표 함수 `=>`는 제외)
  const copy = /(?<!=)[><]=?\s*[\w.]*threshold_xp/.test(src)
  ok(!copy, `${f} 에 도달 판정 복사본이 생겼다 — buildRewardView()만 쓸 것 (L27)`)
  ok(/buildRewardView/.test(src) || f === 'src/screens/WorldMap.tsx', `${f} 가 buildRewardView를 쓰지 않는다`)
}
for (const f of ALLOW) ok(fs.existsSync(f), `${f} 없음`)

/* ── ② 규칙 함수 실제 동작 ───────────────────────────── */
const R = await import('./_rw_entry_out.js').then(() => globalThis.R)

const goals = [
  { id: 1, threshold_xp: 1000, title: '치킨', emoji: '🍗', granted_at: null },
  { id: 2, threshold_xp: 3000, title: '레고', emoji: '🧱', granted_at: null },
  { id: 3, threshold_xp: 500, title: '아이스크림', emoji: '🍦', granted_at: '2026-08-01T00:00:00Z' },
]

// 정렬: threshold 오름차순으로 재배열되어야 한다 (입력 순서와 무관)
{
  const v = R.buildRewardView(goals, 0)
  ok(v.steps.map(s => s.goal.threshold_xp).join(',') === '500,1000,3000', '보상이 기준 XP 오름차순으로 정렬되지 않는다')
}

// 경계값: 한 칸 모자라면 미달, 딱 맞으면 달성
{
  const a = R.buildRewardView(goals, 999)
  const b = R.buildRewardView(goals, 1000)
  const sa = a.steps.find(s => s.goal.id === 1), sb = b.steps.find(s => s.goal.id === 1)
  ok(sa.reached === false && sa.remaining === 1, '999 XP에서 1000 목표가 달성으로 잡힌다(또는 남은 XP 오류)')
  ok(sb.reached === true && sb.remaining === 0, '1000 XP에서 1000 목표가 달성으로 안 잡힌다')
}

// 구간 진행률: 직전 목표를 기준으로 재야 한다 (0부터 재면 항상 거의 100%로 보인다)
{
  const v = R.buildRewardView(goals, 750)
  const s2 = v.steps.find(s => s.goal.id === 1) // 500 → 1000 구간
  ok(s2.from === 500 && s2.span === 500, `구간 시작/폭 오류 (from=${s2.from}, span=${s2.span})`)
  ok(s2.pct === 50, `구간 진행률 오류 (기대 50, 실제 ${s2.pct})`)
}

// next = 첫 미달성 목표 / pending = 달성했는데 미지급
{
  const v = R.buildRewardView(goals, 1200)
  ok(v.next?.goal.id === 2, 'next가 첫 미달성 목표가 아니다')
  ok(v.reachedCount === 2, `reachedCount 오류 (기대 2, 실제 ${v.reachedCount})`)
  ok(v.pending.length === 1 && v.pending[0].goal.id === 1, 'pending(달성·미지급) 판정 오류')
  const all = R.buildRewardView(goals, 99999)
  ok(all.next === null, '전부 달성했는데 next가 남아 있다')
}

/* ── ③ 입력 검증 ───────────────────────────── */
ok(R.validateGoal(1000, '치킨', goals) !== null, '중복 기준 XP가 통과된다')
ok(R.validateGoal(1000, '치킨', goals, 1) === null, '자기 자신 수정인데 중복으로 막힌다')
ok(R.validateGoal(0, '치킨', []) !== null, '0 XP가 통과된다')
ok(R.validateGoal(1500.5, '치킨', []) !== null, '소수 XP가 통과된다')
ok(R.validateGoal(1500, '   ', []) !== null, '빈 보상 이름이 통과된다')
ok(R.validateGoal(1500, 'x'.repeat(61), []) !== null, '61자 이름이 통과된다')
ok(R.validateGoal(1500, '치킨', []) === null, '정상 입력이 막힌다')
{
  const many = Array.from({ length: R.MAX_GOALS }, (_, i) => ({ id: i + 10, threshold_xp: (i + 1) * 100, title: 't', emoji: '🎁', granted_at: null }))
  ok(R.validateGoal(99999, '초과', many) !== null, `상한 ${R.MAX_GOALS}개를 넘겨도 통과된다`)
}

/* ── ④ 도착 예상일 — 근거 없는 숫자를 말하지 않는다 ───────── */
ok(R.etaDays(1000, 200, 5) === 5, '예상일 계산 오류')
ok(R.etaDays(1000, 200, 2) === null, '표본 3일 미만인데 예상일을 말한다')
ok(R.etaDays(1000, 0, 9) === null, '평균 0인데 예상일을 말한다')
ok(R.etaDays(0, 200, 9) === 0, '이미 도달했는데 0이 아니다')

/* ── ⑤ 일별 평균 — 안 한 날은 세지 않는다 ───────────────── */
{
  const rows = [
    { amount: 100, created_at: new Date(Date.now() - 1 * 86400000).toISOString() },
    { amount: 200, created_at: new Date(Date.now() - 1 * 86400000).toISOString() },
    { amount: 300, created_at: new Date(Date.now() - 3 * 86400000).toISOString() },
    { amount: 999, created_at: new Date(Date.now() - 40 * 86400000).toISOString() }, // 창 밖 — 무시돼야 함
  ]
  const r = R.dailyXpAverage(rows, 14)
  ok(r.sampleDays === 2, `학습한 날 수 오류 (기대 2, 실제 ${r.sampleDays})`)
  ok(r.avg === 300, `하루 평균 오류 (기대 300 = (300+300)/2, 실제 ${r.avg})`)
}

if (fail) { console.log(`\n❌ 보상 검사 실패 ${fail}건`); process.exit(1) }
console.log('✅ 보상 로드맵 검사 전 항목 통과 (규칙 단일화 · 경계값 · 입력 검증)')

// v1.4.22 보상 로드맵 렌더 스모크 — 학습자 앱(보상 창고·월드맵 스트립) + 관제실(보상 탭)
// L16: 마커 grep은 렌더 테스트를 대체하지 못한다. 실제로 그려지는지, JS 오류가 없는지 본다.
import { chromium } from 'playwright'

const GOALS = [
  { id: 1, learner_id: 'L', threshold_xp: 500, title: '아이스크림 한 통', emoji: '🍦', note: null, granted_at: '2026-08-01T00:00:00Z' },
  { id: 2, learner_id: 'L', threshold_xp: 30000, title: '치킨 파티', emoji: '🍗', note: '아빠랑 같이 시켜 먹기!', granted_at: null },
  { id: 3, learner_id: 'L', threshold_xp: 60000, title: '레고 세트', emoji: '🧱', note: null, granted_at: null },
]
const XP_EVENTS = Array.from({ length: 30 }, (_, i) => ({
  amount: 120, created_at: new Date(Date.now() - (i % 10) * 86400000).toISOString(),
}))

const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' })
const p = await b.newPage({ viewport: { width: 412, height: 915 } })
const errs = []
p.on('pageerror', e => errs.push(String(e)))
p.on('console', m => { if (m.type() === 'error' && !/404|Failed to load resource|ERR_TUNNEL/.test(m.text())) errs.push(m.text()) })

// ⚠️ page.route는 나중에 등록한 것이 먼저 매칭된다(L16 보강) → 포괄 패턴 먼저, 구체 패턴 나중.
await p.route('**/*', r => {
  const u = r.request().url()
  if (u.includes('supabase.co')) return r.fulfill({ status: 200, contentType: 'application/json', body: '[]' })
  return r.continue()
})
await p.route('**/rest/v1/reward_goals*', r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(GOALS) }))
await p.route('**/rest/v1/xp_events*', r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(XP_EVENTS) }))
await p.route('**/rest/v1/learners*', r => r.fulfill({
  status: 200, contentType: 'application/json',
  body: JSON.stringify([{ id: 'L', family_code: 'wc-yehan-7351', nickname: '예한', admin_pin: '7351', xp: 27383, level: 14, streak_days: 2, last_active_date: null }]),
}))

const prog = {}
for (let i = 1; i <= 9; i++) prog[`V1-0${i}`] = { module_id: `V1-0${i}`, status: 'completed', best_score: 90, attempts: 1 }
await p.addInitScript(st => {
  localStorage.setItem('wordcraft_state_v1', st)
  sessionStorage.setItem('wc_admin', '1') // 관제실 PIN 게이트 통과
}, JSON.stringify({
  learnerId: 'L', nickname: '예한', xp: 27383, level: 14, streak_days: 2,
  diagDone: ['D1', 'D2', 'D3', 'D4'], placement: 'B21a', progress: prog, bossWins: [], attendance: [],
  dailyXp: { date: new Date().toLocaleDateString('sv', { timeZone: 'Asia/Seoul' }), course: 180, review: 60 },
}))

let fail = 0
const need = (txt, needles, label) => {
  for (const n of needles) {
    if (!txt.includes(n)) { console.log(`  ❌ ${label}: "${n}" 이(가) 화면에 없다`); fail++ }
  }
}

async function open(route) {
  await p.goto('http://127.0.0.1:8099/#/' + route, { waitUntil: 'networkidle' })
  await p.reload({ waitUntil: 'networkidle' })
  await p.waitForTimeout(900)
  const skip = p.locator('button', { hasText: '건너뛰기' })
  if (await skip.count()) { await skip.first().click(); await p.waitForTimeout(500) }
  return (await p.locator('body').innerText()).replace(/\n+/g, ' ')
}

// ① 보상 창고 (아이 화면)
{
  const t = await open('rewards')
  console.log('  /rewards →', t.slice(0, 90))
  need(t, ['보상 창고', '다음 보상', '치킨 파티', '레고 세트', '보상 사다리'], '보상 창고')
  // 남은 XP = 30000 - 27383 = 2617
  need(t, ['2,617'], '남은 XP 표기')
  // 이미 지급된 보상은 '받았다!'로
  need(t, ['받았다'], '지급 완료 표기')
  await p.screenshot({ path: 'rw_board.png', fullPage: true })
}

// ② 월드맵 상단 보상 스트립
{
  const t = await open('')
  console.log('  /(홈) →', t.slice(0, 90))
  need(t, ['다음 보상 · 치킨 파티', '2,617'], '월드맵 보상 스트립')
  await p.screenshot({ path: 'rw_map.png' })
}

// ③ 관제실 보상 탭
{
  await p.goto('http://127.0.0.1:8099/#/admin', { waitUntil: 'networkidle' })
  await p.reload({ waitUntil: 'networkidle' })
  await p.waitForTimeout(1400)
  const skipA = p.locator('button', { hasText: '건너뛰기' })
  if (await skipA.count()) { await skipA.first().click(); await p.waitForTimeout(500) }
  const tab = p.locator('.adm-tab', { hasText: '보상' })
  if (await tab.count()) { await tab.first().click(); await p.waitForTimeout(700) }
  const t = (await p.locator('body').innerText()).replace(/\n+/g, ' ')
  console.log('  /admin(보상) →', t.slice(0, 110))
  need(t, ['보상 로드맵', '치킨 파티', '보상 추가하기'], '관제실 보상 탭')
  if (t.includes('1,000 XP마다')) { console.log('  ❌ 옛 1,000 XP 자동 마일스톤 UI가 남아 있다'); fail++ }
  // 추가 폼이 열리는지
  const add = p.locator('button', { hasText: '보상 추가하기' })
  if (await add.count()) {
    await add.first().click(); await p.waitForTimeout(400)
    const t2 = (await p.locator('body').innerText()).replace(/\n+/g, ' ')
    need(t2, ['보상 이름', '기준 XP'], '보상 추가 폼')
  } else { console.log('  ❌ 보상 추가 버튼이 없다'); fail++ }
  await p.screenshot({ path: 'rw_admin.png', fullPage: true })
}

await b.close()
console.log('\nJS 오류:', errs.length)
errs.slice(0, 8).forEach(e => console.log('  -', e))
if (fail || errs.length) { console.log(`\n❌ 보상 렌더 스모크 실패 (검증 ${fail}건 · JS오류 ${errs.length}건)`); process.exit(1) }
console.log('✅ 보상 렌더 스모크 통과 (아이 화면 · 월드맵 · 관제실)')

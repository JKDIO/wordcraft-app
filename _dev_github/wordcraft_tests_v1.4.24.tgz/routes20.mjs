import { chromium } from 'playwright'
const b = await chromium.launch({ executablePath:'/opt/pw-browsers/chromium' })
const p = await b.newPage({ viewport:{width:412,height:915} })
const errs=[]; p.on('pageerror',e=>errs.push(String(e)))
p.on('console',m=>{ if(m.type()==='error'&&!/404|Failed to load resource|ERR_TUNNEL/.test(m.text()))errs.push(m.text()) })
await p.route('**/*', r=>{ const u=r.request().url()
  if(u.includes('supabase.co')&&u.includes('.mp3')) return r.fulfill({status:200,contentType:'audio/mpeg',body:Buffer.alloc(64)})
  if(u.includes('supabase.co')) return r.fulfill({status:200,contentType:'application/json',body:'[]'})
  return r.continue() })
const prog={}; for(let i=1;i<=9;i++) prog[`V1-0${i}`]={module_id:`V1-0${i}`,status:'completed',best_score:90,attempts:1}
prog['GOLEM-T1-1']={module_id:'GOLEM-T1-1',status:'completed',best_score:83,attempts:1}
await p.addInitScript(st=>localStorage.setItem('wordcraft_state_v1',st), JSON.stringify({
  nickname:'예한',xp:27383,level:14,streak_days:2,diagDone:['D1','D2','D3','D4'],placement:'B21a',progress:prog,bossWins:[],attendance:[]}))
const routes=['','worlds','review','runes','me','info','vocab','dex','forge','listen','family','connect','admin']
for(const r of routes){
  await p.goto('http://127.0.0.1:8099/#/'+r,{waitUntil:'networkidle'}); await p.reload({waitUntil:'networkidle'}); await p.waitForTimeout(700)
  const t=(await p.locator('body').innerText()).replace(/\n+/g,' ').slice(0,60)
  console.log(`  /${r||'(홈)'} → ${t}`)
}
// 지도 스크린샷 (스플래시 건너뛰고)
await p.goto('http://127.0.0.1:8099/#/vocab',{waitUntil:'networkidle'}); await p.reload({waitUntil:'networkidle'}); await p.waitForTimeout(1200)
await p.screenshot({path:'s20_map.png', fullPage:false})
await p.evaluate(()=>window.scrollTo(0,300)); await p.waitForTimeout(300)
await p.screenshot({path:'s20_map2.png'})
await b.close()
console.log('\nJS 오류:', errs.length); errs.slice(0,8).forEach(e=>console.log('  -',e))

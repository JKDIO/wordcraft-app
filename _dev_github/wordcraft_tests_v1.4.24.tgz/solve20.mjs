// 정답을 알고 푸는 스모크 — "정답을 고르면 실제로 정답 처리되는가"까지 검증한다.
import { chromium } from 'playwright'
import fs from 'fs'
const V = JSON.parse(fs.readFileSync('serve/vocab.json','utf8'))
const byWord=new Map(), byKo=new Map(), byEx=new Map()
for(const pid in V.packs) for(const w of V.packs[pid].words){ byWord.set(w.w,w); if(!byKo.has(w.ko))byKo.set(w.ko,w); byEx.set(w.ex.toLowerCase(),w) }

const b = await chromium.launch({ executablePath:'/opt/pw-browsers/chromium' })
const p = await b.newPage({ viewport:{width:412,height:915} })
const errs=[]; p.on('pageerror',e=>errs.push(String(e)))
p.on('console',m=>{ if(m.type()==='error'&&!/404|Failed to load resource|ERR_TUNNEL/.test(m.text()))errs.push(m.text()) })
await p.route('**/*', r=>{ const u=r.request().url()
  if(u.includes('supabase.co')&&u.includes('.mp3')) return r.fulfill({status:200,contentType:'audio/mpeg',body:Buffer.alloc(64)})
  if(u.includes('supabase.co')) return r.fulfill({status:200,contentType:'application/json',body:'[]'})
  return r.continue() })
const prog={}; for(let i=1;i<=5;i++) prog[`V1-0${i}`]={module_id:`V1-0${i}`,status:'completed',best_score:90,attempts:1}
await p.addInitScript(st=>localStorage.setItem('wordcraft_state_v1',st), JSON.stringify({
  nickname:'예한',xp:27383,level:14,streak_days:2,diagDone:['D1','D2','D3','D4'],placement:'B21a',progress:prog,bossWins:[],attendance:[]}))
await p.goto('http://127.0.0.1:8099/#/vocab',{waitUntil:'networkidle'}); await p.waitForTimeout(1200)
await p.locator('text=흙덩이 골렘 출현!').first().click(); await p.waitForTimeout(400)
await p.locator('text=⚔️ 붙는다!').click(); await p.waitForTimeout(500)

let solved=0, wrongByDesign=0, listenRandom=0, armor=0, turns=0
for(let i=0;i<120;i++){
  const t=await p.locator('body').innerText()
  const m=/갑옷 (\d+)\/12/.exec(t); if(m)armor=+m[1]
  if(/격파!/.test(t)) break
  const nx=p.locator('button:has-text("계속 →"), button:has-text("마지막 일격")')
  if(await nx.count()){ await nx.first().click(); await p.waitForTimeout(70); continue }
  const card=p.locator('.center-box > div').nth(2)
  const prompt=(await p.locator('.center-box div[style*="font-weight: 800"]').first().innerText().catch(()=>'')).trim()
  const lines=t.split('\n').map(s=>s.trim()).filter(Boolean)
  // 모드 판별
  const isSpell = await p.locator('button:has-text("↩ 다시")').count()>0 || /빠진 글자를 순서대로/.test(t)
  const opts=p.locator('.center-box button').filter({hasNotText:'나가기'}).filter({hasNotText:'다시 듣기'}).filter({hasNotText:'힌트'}).filter({hasNotText:'↩ 다시'})
  const n=await opts.count(); if(!n) break
  const labels=[]; for(let k=0;k<n;k++) labels.push((await opts.nth(k).innerText()).trim())
  let idx=-1
  if(/빠진 글자를 순서대로/.test(t)){
    // 철자: promptKo "뜻 — 빠진 글자를 순서대로 눌러!" + prompt 마스킹
    const ko=(/(.+?) — 빠진 글자를/.exec(t)||[])[1]
    const masked=lines.find(l=>/_/.test(l)&&l.length<=25)
    const w=byKo.get(ko&&ko.trim())
    if(w&&masked){ const need=[]; for(let j=0;j<w.w.length;j++) if(masked[j]==='_') need.push(w.w[j])
      for(const ch of need){ const bi=labels.findIndex((l,li)=>l===ch&&li>=0); if(bi>=0){ await opts.nth(bi).click(); await p.waitForTimeout(60) } }
      solved++; turns++; await p.waitForTimeout(120); continue }
    idx=0
  } else if(byWord.has(prompt)){                       // 뜻 사냥 → ko
    idx=labels.indexOf(byWord.get(prompt).ko); if(idx>=0) solved++
  } else if(byKo.has(prompt)){                          // 한→영 소환 → w
    idx=labels.indexOf(byKo.get(prompt).w); if(idx>=0) solved++
  } else if(/_____/.test(prompt)){                      // 문장 구멍
    const cand=[...byWord.values()].find(w=>w.ex.replace(new RegExp('\\b'+w.w+'\\b','i'),'_____')===prompt)
    if(cand){ idx=labels.indexOf(cand.w); if(idx>=0) solved++ }
  } else { listenRandom++ }                             // 소리 낚시 — 화면만으로는 알 수 없다
  if(idx<0){ idx=Math.floor(Math.random()*n); wrongByDesign++ }
  await opts.nth(idx).click().catch(()=>{}); turns++; await p.waitForTimeout(70)
}
const t=await p.locator('body').innerText()
console.log('골렘전 결과 — 갑옷', armor, '/12 · 격파:', /격파!/.test(t))
console.log('  정답을 알고 고른 문항:', solved, '· 알 수 없어 무작위(소리 낚시):', listenRandom, '· 총 시도', turns)
console.log('  수호자 각성 대사 노출:', /한 걸음 더 깨어났다/.test(t), '· 격파 서사:', /흙이 우수수/.test(t))
await p.screenshot({path:'s20_golem_win.png'})
if(/격파!/.test(t)){ await p.locator('button:has-text("지도로 돌아가기 →")').click(); await p.waitForTimeout(900)
  const mt=await p.locator('body').innerText()
  console.log('  격파 후 지도 — 골렘 카드 사라짐:', !/흙덩이 골렘 출현/.test(mt), '· 각성 단계 유지:', /눈을 떴다|일어섰다/.test(mt)) }
await b.close()
console.log('JS 오류:', errs.length); errs.slice(0,5).forEach(e=>console.log('  -',e))

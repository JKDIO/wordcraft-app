import { chromium } from 'playwright'
import fs from 'fs'
const V = JSON.parse(fs.readFileSync('serve/vocab.json','utf8'))
const byWord=new Map(), byKo=new Map()
for(const pid in V.packs) for(const w of V.packs[pid].words){ byWord.set(w.w,w); if(!byKo.has(w.ko))byKo.set(w.ko,w) }
const PACK = V.packs['V1-06']
const SORT_ANS = new Map()   // 정답 상자를 미리 계산해 둘 수 없으므로 화면에서 유추 대신 무작위 배치 후 채점만 확인

const b = await chromium.launch({ executablePath:'/opt/pw-browsers/chromium' })
const p = await b.newPage({ viewport:{width:412,height:915} })
const errs=[]; p.on('pageerror',e=>errs.push(String(e)))
p.on('console',m=>{ if(m.type()==='error'&&!/404|Failed to load resource|ERR_TUNNEL/.test(m.text()))errs.push(m.text()) })
await p.route('**/*', r=>{ const u=r.request().url()
  if(u.includes('supabase.co')&&u.includes('.mp3')) return r.fulfill({status:200,contentType:'audio/mpeg',body:Buffer.alloc(64)})
  if(u.includes('supabase.co')) return r.fulfill({status:200,contentType:'application/json',body:'[]'})
  return r.continue() })
const prog={}; for(let i=1;i<=5;i++) prog[`V1-0${i}`]={module_id:`V1-0${i}`,status:'completed',best_score:90,attempts:1}
await p.addInitScript(st=>localStorage.setItem('wordcraft_state_v1',st), JSON.stringify({
  nickname:'예한',xp:27383,level:14,streak_days:2,diagDone:['D1','D2','D3','D4'],placement:'B21a',progress:prog,bossWins:[],attendance:[]}))
const T=()=>p.locator('body').innerText()
const shot=async n=>{await p.waitForTimeout(250); await p.screenshot({path:`s20_${n}.png`})}
const watchdog=setTimeout(()=>{ console.log('⏱ 워치독 — 강제 종료'); process.exit(2) }, 170000)

await p.goto('http://127.0.0.1:8099/#/vocab',{waitUntil:'networkidle'}); await p.waitForTimeout(1100)
await p.locator('text=배고픈 식탁 던전').first().click(); await p.waitForTimeout(500)
let t=await T()
console.log('① 팩 도입 — 제목:', /배고픈 식탁 던전/.test(t), '· intro_ko 노출:', t.includes(PACK.intro_ko.slice(0,12)))
await shot('05_pack_intro')
await p.locator('text=🏹 들어간다').click(); await p.waitForTimeout(350)

for(let i=0;i<13;i++){ const bn=p.locator('text=🤔 몰라요 — 배울래'); if(!await bn.count())break; await bn.click(); await p.waitForTimeout(90) }
console.log('② 사전 스캔 12개 통과 →', (await T()).split('\n').find(l=>/새 단어|분류/.test(l))||'?')
for(let i=0;i<14;i++){ const bn=p.locator('button:has-text("다음 →"), button:has-text("분류 상자로!"), button:has-text("사냥 시작!")')
  if(!await bn.count())break; const t0=await bn.first().innerText(); await bn.first().click(); await p.waitForTimeout(120); if(/분류|사냥/.test(t0))break }
t=await T()
console.log('③ 분류 상자 화면:', /상자/.test(t), '| 규칙:', (t.split('\n').find(l=>/나눠 담아|손뼉/.test(l))||'').slice(0,40))
await shot('06_sort')
const boxes=p.locator('[data-testid=sort-box]'); const nb=await boxes.count()
for(let round=0; round<16; round++){
  const chips=p.locator('[data-testid=sort-pool] button')
  const cn=await chips.count(); if(!cn) break
  await chips.first().click(); await p.waitForTimeout(60)
  await boxes.nth(round%nb).click(); await p.waitForTimeout(60)
  if(await p.locator('button:has-text("✅ 확인!"):not([disabled])').count()) break
}
const ok=p.locator('button:has-text("✅ 확인!")')
console.log('④ 상자', nb, '개 · 12칩 배치 완료 → 확인 활성:', await ok.isEnabled({timeout:3000}).catch(()=>false))
await ok.click(); await p.waitForTimeout(400)
t=await T(); console.log('   채점:', (t.split('\n').find(l=>/제자리/.test(l))||'?'))
await shot('07_sort_done')
await p.locator('button:has-text("⚔️ 사냥 시작! →")').click(); await p.waitForTimeout(450)

let solved=0, qn=0
for(let i=0;i<160;i++){
  t=await T()
  if(/속사 사냥, 해 볼래|정복!/.test(t)) break
  const nx=p.locator('button:has-text("다음 →"), button:has-text("결과 보기 →")')
  if(await nx.count()){ await nx.first().click(); await p.waitForTimeout(70); continue }
  const sp=p.locator('button:has-text("📣 말했어! 다음")')
  if(await sp.count()){ await sp.click(); qn++; await p.waitForTimeout(70); continue }
  const prompt=(await p.locator('.center-box div[style*="font-weight: 800"]').first().innerText().catch(()=>'')).trim()
  const opts=p.locator('.center-box button').filter({hasNotText:'나가기'}).filter({hasNotText:'다시 듣기'}).filter({hasNotText:'힌트'}).filter({hasNotText:'↩ 다시'})
  const n=await opts.count(); if(!n) break
  const labels=[]; for(let k=0;k<n;k++) labels.push((await opts.nth(k).innerText()).trim())
  let idx=-1
  if(/빠진 글자를 순서대로/.test(t)){
    const ko=(/(.+?) — 빠진 글자를/.exec(t)||[])[1]
    const masked=t.split('\n').map(s=>s.trim()).find(l=>/_/.test(l)&&l.length<=25)
    const w=byKo.get(ko&&ko.trim())
    if(w&&masked){ for(let j=0;j<w.w.length;j++) if(masked[j]==='_'){ const bi=labels.indexOf(w.w[j]); if(bi>=0){await opts.nth(bi).click(); await p.waitForTimeout(50)} }
      solved++; qn++; await p.waitForTimeout(120); continue }
  }
  if(byWord.has(prompt)) idx=labels.indexOf(byWord.get(prompt).ko)
  else if(byKo.has(prompt)) idx=labels.indexOf(byKo.get(prompt).w)
  if(idx>=0) solved++; else idx=0
  await opts.nth(idx).click(); qn++; await p.waitForTimeout(70)
}
t=await T()
console.log('⑤ 문항', qn, '개 소화(정답 확신', solved, ') → 속사 제안:', /속사 사냥, 해 볼래/.test(t))
await shot('08_rapid_offer')
if(/해 볼래/.test(t)){
  await p.locator('button:has-text("🔥 간다!")').click(); await p.waitForTimeout(400); await shot('09_rapid')
  for(let i=0;i<26;i++){ const o=p.locator('button:has-text("⭕")'); if(!await o.count())break; await o.click(); await p.waitForTimeout(40) }
  t=await T(); console.log('⑥ 속사 결과:', (t.split('\n').find(l=>/순삭/.test(l))||'?'))
  await shot('10_rapid_done')
  const rb=p.locator('button:has-text("결과 보기 →")'); if(await rb.count()) { await rb.click(); await p.waitForTimeout(500) }
}
t=await T()
console.log('⑦ 결과 — 결말 헤더:', /그래서 어떻게 됐냐면/.test(t), '· outro 일치:', t.includes(PACK.outro_ko.slice(0,14)), '· 수호자 대사:', t.includes(PACK.guardian_ko.slice(0,10)))
await shot('11_result')
clearTimeout(watchdog)
await b.close()
console.log('JS 오류:', errs.length); errs.slice(0,5).forEach(e=>console.log('  -',e))

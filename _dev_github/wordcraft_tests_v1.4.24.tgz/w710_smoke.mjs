// v1.4.23 월드 7~10 — 숨김 스위치 + 렌더 스모크
// 판정 ①: worlds_ready=false면 아이 화면 어디에도 월드 7~10이 없다(가장 중요)
// 판정 ②: worlds_ready=true면 24모듈이 전부 실제로 렌더되고 JS 오류가 0이다
import { chromium } from 'playwright'
import fs from 'fs'

const MODS = ['P1','P2','P3','P4','P5','P6','W1','W2','W3','W4','W5','W6','S1','S2','S3','S4','S5','S6','G1','G2','G3','G4','G5','G6']
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' })
let fail = 0
const errs = []

async function page(worldsReady) {
  const p = await b.newPage({ viewport: { width: 412, height: 915 } })
  p.on('pageerror', e => errs.push(`[ready=${worldsReady}] ${e}`))
  p.on('console', m => { if (m.type() === 'error' && !/404|Failed to load resource|ERR_TUNNEL/.test(m.text())) errs.push(`[ready=${worldsReady}] ${m.text()}`) })
  await p.route('**/*', r => {
    const u = r.request().url()
    if (u.includes('supabase.co') && u.includes('.mp3')) return r.fulfill({ status: 200, contentType: 'audio/mpeg', body: Buffer.alloc(64) })
    if (u.includes('supabase.co')) return r.fulfill({ status: 200, contentType: 'application/json', body: '[]' })
    if (u.includes('/version.json')) return r.fulfill({ status: 200, contentType: 'application/json',
      body: JSON.stringify({ version: '1.4.23', vocab_ready: true, worlds_ready: worldsReady }) })
    return r.continue()
  })
  // 전 모듈 클리어 상태 — 월드 7~10이 잠금 때문이 아니라 '없어서' 안 보이는지 확인하기 위해
  const prog = {}
  for (const id of ['A1','A2','A3','A4','R0','R1','R2','R3','R4','R5','R6','R7','R8','R9','C0','C5','C6','C7','B21a','B21b','B22a','B22b','D1S','D2S','D3S','T1','T2','T3'])
    prog[id] = { module_id: id, status: 'completed', best_score: 95, attempts: 1, completed_at: '2026-08-13T00:00:00Z' }
  await p.addInitScript(st => localStorage.setItem('wordcraft_state_v1', st), JSON.stringify({
    learnerId: 'L', nickname: '예한', xp: 27383, level: 14, streak_days: 2,
    diagDone: ['D1','D2','D3','D4'], placement: 'T3', progress: prog, bossWins: [], attendance: [],
  }))
  return p
}
async function open(p, route) {
  await p.goto('http://127.0.0.1:8099/#/' + route, { waitUntil: 'networkidle' })
  await p.reload({ waitUntil: 'networkidle' })
  await p.waitForTimeout(900)
  const skip = p.locator('button', { hasText: '건너뛰기' })
  if (await skip.count()) { await skip.first().click(); await p.waitForTimeout(400) }
  return (await p.locator('body').innerText()).replace(/\n+/g, ' ')
}

// ── ① 숨김 상태 ───────────────────────────────────────────
{
  const p = await page(false)
  const t = await open(p, '')
  const btn = p.locator('button', { hasText: '전체 펼치기' })
  if (await btn.count()) { await btn.first().click(); await p.waitForTimeout(400) }
  const full = (await p.locator('body').innerText()).replace(/\n+/g, ' ')
  for (const w of ['독해 던전', '어휘 대장간', '회화 아레나', '서술 마스터리', '월드 7', '월드 8', '월드 9', '월드 10']) {
    if (full.includes(w)) { console.log(`  ❌ 숨김 실패: 월드맵에 "${w}" 노출`); fail++ }
  }
  for (const title of ['그림자 문장', '반대의 망치', '표현 인벤토리', '합체 공방'])
    if (full.includes(title)) { console.log(`  ❌ 숨김 실패: 모듈 "${title}" 노출`); fail++ }
  const pr = await open(p, 'profile')
  if (!/클리어[\s\S]{0,20}28/.test(pr) && !pr.includes('/28')) { console.log('  ❌ 내 정보 "클리어 n/28" 분모가 28이 아님 →', (pr.match(/\d+\/\d+/g) || []).join(',')); fail++ }
  if (pr.includes('/52')) { console.log('  ❌ 내 정보 분모가 52로 늘어남(숨김 실패)'); fail++ }
  console.log('  숨김 상태: 월드맵 · 내 정보 확인 완료')
  await p.screenshot({ path: 'w710_hidden.png' })
  await p.close()
}

// ── ② 개방 상태 ───────────────────────────────────────────
{
  const p = await page(true)
  const t = await open(p, '')
  const btn = p.locator('button', { hasText: '전체 펼치기' })
  if (await btn.count()) { await btn.first().click(); await p.waitForTimeout(500) }
  const full = (await p.locator('body').innerText()).replace(/\n+/g, ' ')
  for (const w of ['독해 던전', '어휘 대장간', '회화 아레나', '서술 마스터리'])
    if (!full.includes(w)) { console.log(`  ❌ 개방 실패: 월드맵에 "${w}" 없음`); fail++ }
  const pr = await open(p, 'profile')
  if (!pr.includes('/52')) { console.log('  ❌ 개방 시 "클리어 n/52"가 아님 →', (pr.match(/\d+\/\d+/g) || []).join(',')); fail++ }

  // 24모듈 전부 실제 렌더 (첫 화면이 그려지고 JS 오류가 없는지)
  let ok = 0
  for (const id of MODS) {
    const txt = await open(p, `module/${id}`)
    if (txt.length < 20 || /찾지 못했어|불러오지 못했/.test(txt)) { console.log(`  ❌ ${id} 렌더 실패: ${txt.slice(0,60)}`); fail++ }
    else ok++
  }
  console.log(`  개방 상태: 월드 4개 노출 · 모듈 렌더 ${ok}/${MODS.length}`)
  await p.screenshot({ path: 'w710_open.png', fullPage: true })
  await p.close()
}

await b.close()
console.log('\nJS 오류:', errs.length)
errs.slice(0, 10).forEach(e => console.log('  -', e))
if (fail || errs.length) { console.log(`\n❌ 월드 7~10 스모크 실패 (검증 ${fail}건 · JS오류 ${errs.length}건)`); process.exit(1) }
console.log('✅ 월드 7~10 스모크 통과 — 숨김 완전 · 개방 시 24모듈 렌더 · JS 오류 0')

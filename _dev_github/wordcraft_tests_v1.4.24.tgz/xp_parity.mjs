// ★L12·L27 재발 방지 검사★ — 배포 전 반드시 통과해야 한다.
// 앱이 실제로 주는 XP(App.tsx recordXp) 와 관제실·기기병합이 파생하는 XP가 1원이라도 다르면 실패.
import './_xp_entry_out.js'; import './_measure_entry_out.js'
import fs from 'fs'
const X = globalThis.X, V = globalThis.V, XP = X.XP
const fail = []
const eq = (a,b,m)=>{ if(a!==b) fail.push(`${m}: ${a} ≠ ${b}`) }

// 1) 단일 정의가 실제로 단일인가 — 다른 파일이 산식을 복사해 두지 않았는지 소스에서 확인
for (const f of ['src/screens/AdminPage.tsx','src/lib/store.ts']) {
  const s = fs.readFileSync(f,'utf8')
  if (/case '(vocab|review|game_match)':\s*return/.test(s)) fail.push(`${f}: activity_type 산식을 자기 파일에 복사해 뒀다(L27 위반)`)
  if (/XP\.moduleClear\s*\/\/|:\s*XP\.moduleClear\b/.test(s) && !/moduleBonusOf/.test(s)) fail.push(`${f}: 모듈 보너스 산식을 복사해 뒀다`)
}
// 2) App.tsx가 부여하는 상수 = xp.ts 정의
const app = fs.readFileSync('src/App.tsx','utf8')
for (const [call, want] of [['XP.vocabCorrect','vocabCorrect'],['XP.vocabPack','vocabPack'],['XP.vocabPerfect','vocabPerfect'],['XP.vocabGolem','vocabGolem']])
  if (!app.includes(call)) fail.push(`App.tsx가 ${call}를 부여하지 않는다`)

// 3) 산식 값 대조
eq(X.answerXpOf('vocab',true), XP.vocabCorrect, '어휘 정답')
eq(X.answerXpOf('vocab',false), 0, '어휘 오답')
eq(X.answerXpOf('quiz',true), XP.correct, '일반 정답')
eq(X.answerXpOf('review',true), XP.reviewCorrect, '복습 정답')
eq(X.moduleBonusOf('V3-07',95), XP.vocabPack+XP.vocabPerfect, '어휘 팩 ★★★')
eq(X.moduleBonusOf('V10-20',71), XP.vocabPack, '어휘 팩 ★★')
eq(X.moduleBonusOf('GOLEM-T3-2',null), XP.vocabGolem, '단어 골렘')
eq(X.moduleBonusOf('DIAG-1',null), 30, '진단')
eq(X.moduleBonusOf('B21a',88), XP.moduleClear, '일반 모듈')

// 4) 실전 시뮬레이션 — 한 팩을 통째로 플레이한 뒤 앱 XP vs 관제실 파생 XP
const data = JSON.parse(fs.readFileSync('public/vocab.json','utf8'))
for (const [pid, cleared, acc] of [['V1-01',0,1.0],['V4-07',65,0.75],['V9-11',170,0.5]]) {
  const p = data.packs[pid]
  const sort = V.hasFeature(cleared,'sort') ? V.buildSortTask(p) : null
  const qs = V.buildSession(p,[],cleared, sort?V.MAX_QUESTIONS_WITH_SORT:V.MAX_QUESTIONS)
  const events = []
  qs.forEach((q,i)=>events.push({activity_type:'vocab', is_correct: (i%100)/100 < acc}))
  if (sort) sort.items.forEach((s,i)=>events.push({activity_type:'vocab', is_correct:(i%100)/100 < acc}))
  const correct = events.filter(e=>e.is_correct).length
  const pct = Math.round(correct/events.length*100)
  // 앱: 정답당 vocabCorrect + 팩 30 + (★★★이면 15)
  const appXp = correct*XP.vocabCorrect + XP.vocabPack + (pct>=90?XP.vocabPerfect:0)
  // 관제실: answerXpOf 합 + moduleBonusOf
  const admXp = events.reduce((a,e)=>a+X.answerXpOf(e.activity_type,e.is_correct),0) + X.moduleBonusOf(pid,pct)
  eq(appXp, admXp, `${pid} 팩 완주(정답률 ${pct}%)`)
}
// 5) 골렘 한 판
{
  const t = data.tiers[2], packs = V.golemPackIds(t,2).map(id=>data.packs[id])
  const qs = V.buildGolemSession(packs, 50, 302)
  // 12칸 중 9개를 한 번에, 3개는 두 번 만에 → 시도 15회, 정답 12
  const tries = 15, correct = 12
  const appXp = correct*XP.vocabCorrect + XP.vocabGolem
  const evs = [...Array(correct).fill(true), ...Array(tries-correct).fill(false)]
  const admXp = evs.reduce((a,ok)=>a+X.answerXpOf('vocab',ok),0) + X.moduleBonusOf(V.golemId(3,2), Math.round(9/12*100))
  eq(appXp, admXp, `골렘 T3#2 (문항 ${qs.length})`)
}
console.log(fail.length===0 ? '✅ XP 패리티 전 항목 통과 (앱 = 관제실 = 기기병합)' : '❌ XP 패리티 실패')
fail.forEach(f=>console.log('  -',f))
process.exit(fail.length?1:0)

// v1.4.27 뱃지 카테고리 UI 스모크 — 접기/펴기가 실제로 동작하는가
import { chromium } from 'playwright'
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' })
const p = await b.newPage({ viewport: { width: 412, height: 915 } })
const errs = []
p.on('pageerror', e => errs.push(String(e)))
p.on('console', m => { if (m.type()==='error' && !/404|Failed to load|supabase/i.test(m.text())) errs.push(m.text()) })
await p.route('**/*', r => {
  const u = r.request().url()
  if (u.includes('supabase.co') && u.includes('/badges')) {
    // 정복 3개 + 읽기 2개만 획득한 상태 — 기본 펼침 규칙을 확인하려고
    return r.fulfill({ status:200, contentType:'application/json',
      body: JSON.stringify([{badge_id:'first_module'},{badge_id:'world1_clear'},{badge_id:'world2_clear'},{badge_id:'read_chunk'},{badge_id:'read_backward'}]) })
  }
  if (u.includes('supabase.co')) return r.fulfill({ status:200, contentType:'application/json', body:'[]' })
  if (u.includes('/version.json')) return r.fulfill({ status:200, contentType:'application/json', body: JSON.stringify({version:'1.4.27',vocab_ready:true,worlds_ready:true}) })
  return r.continue()
})
const prog = {}
for (const id of ['A1','A2','A3','A4','C0','C5','C6','C7','P1','P2']) prog[id] = { module_id:id, status:'completed', best_score:95 }
await p.addInitScript(st => localStorage.setItem('wordcraft_state_v1', st), JSON.stringify({
  learnerId:'L', nickname:'예한', xp:37679, level:16, streak_days:3, diagDone:['D1'], placement:'C0',
  progress: prog, bossWins:[], attendance:[], reviewTotal:120, balanceDays:[], forgeFound:[], legendWords:[], sortPerfect:0, rapidBest:0,
}))
await p.goto('http://127.0.0.1:8099/#/profile', { waitUntil:'networkidle' })
await p.waitForTimeout(1200)

const groups = await p.evaluate(() => {
  const btns = [...document.querySelectorAll('button')].filter(b => /▲|▼/.test(b.innerText))
  return btns.map(b => ({ text: b.innerText.replace(/\s+/g,' ').trim(), open: b.innerText.includes('▲') }))
})
console.log('카테고리 버튼:', groups.length)
groups.forEach(g => console.log(`  ${g.open?'열림':'닫힘'}  ${g.text}`))

const cardsBefore = await p.locator('.badge-card').count()
// 닫힌 카테고리 하나를 연다
const closed = p.locator('button', { hasText: '▼' }).first()
await closed.click(); await p.waitForTimeout(300)
const cardsAfter = await p.locator('.badge-card').count()
// 전체 접기
const toggle = p.locator('button', { hasText: /전체 접기|전체 펼치기/ }).first()
await toggle.click(); await p.waitForTimeout(300)
const cardsCollapsed = await p.locator('.badge-card').count()
await toggle.click(); await p.waitForTimeout(400)
const cardsExpanded = await p.locator('.badge-card').count()

const okGroups = groups.length === 11
const okDefault = groups.filter(g=>g.open).map(g=>g.text.split(' ')[1])
console.log('\n결과')
console.log(` 카테고리 11개: ${okGroups?'OK':'FAIL('+groups.length+')'}`)
console.log(` 기본 펼침(획득 있는 곳만): ${okDefault.join(', ')}`)
console.log(` 카드 수  기본 ${cardsBefore} → 하나 더 펼침 ${cardsAfter} → 전체 접기 ${cardsCollapsed} → 전체 펼치기 ${cardsExpanded}`)
// ⚔️ 룬 장비창
const lo = await p.evaluate(() => {
  const el = document.querySelector('.loadout'); if (!el) return null
  return {
    stage: el.getAttribute('data-stage'),
    title: el.querySelector('.loadout-name b').innerText,
    slots: el.querySelectorAll('.loadout-slot').length,
    heroPixels: (getComputedStyle(el.querySelector('.loadout-hero > i')).boxShadow.match(/rgb/g)||[]).length,
    bar: el.querySelector('.loadout-bar em').innerText,
  }
})
console.log(` 장비창: 슬롯 ${lo?.slots} · 단계 ${lo?.stage} "${lo?.title}" · ${lo?.bar} · 영웅 픽셀 ${lo?.heroPixels}`)
// 슬롯을 누르면 그 카테고리만 펼쳐지는가
const before = await p.locator('.badge-card').count()
await p.locator('.loadout-slot').nth(3).click(); await p.waitForTimeout(500)
const openAfter = await p.evaluate(()=>[...document.querySelectorAll('button')].filter(b=>/▲/.test(b.innerText)).map(b=>b.innerText.replace(/\s+/g,' ').trim()))
console.log(` 슬롯4(장갑) 클릭 → 펼쳐진 카테고리: ${openAfter.join(', ')} (이전 카드 ${before}개)`)
const loOK = lo && lo.slots === 11 && lo.heroPixels > 80 && openAfter.length === 1 && openAfter[0].includes('단어 조립')
console.log(` 장비창 판정: ${loOK ? 'OK' : 'FAIL'}`)
console.log(` JS 에러 ${errs.length}`)
const pass = okGroups && cardsAfter > cardsBefore && cardsCollapsed === 0 && cardsExpanded === 71 && loOK && errs.length === 0
console.log(pass ? '\n✅ 뱃지 카테고리 UI 통과' : '\n❌ 실패')
await b.close()
process.exit(pass?0:1)

import { chromium } from 'playwright'
// 5단계를 한 장에 — 뱃지를 0 / 12 / 25 / 38 / 59개 가진 상태를 각각 렌더
const ALL = JSON.parse(process.env.ALLIDS)
const SETS = [0, 3, 14, 30, 55, ALL.length]
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' })
const shots = []
for (const n of SETS) {
  const p = await b.newPage({ viewport: { width: 412, height: 700 }, deviceScaleFactor: 2 })
  await p.route('**/*', r => {
    const u = r.request().url()
    if (u.includes('supabase.co') && u.includes('/badges')) return r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(ALL.slice(0,n).map(id=>({badge_id:id})))})
    if (u.includes('supabase.co')) return r.fulfill({status:200,contentType:'application/json',body:'[]'})
    if (u.includes('/version.json')) return r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({version:'1.4.28',vocab_ready:true,worlds_ready:true})})
    return r.continue()
  })
  await p.addInitScript(st=>localStorage.setItem('wordcraft_state_v1',st), JSON.stringify({learnerId:'L',nickname:'예한',xp:37679,level:16,streak_days:3,diagDone:[],placement:'C0',progress:{},bossWins:[],attendance:[],reviewTotal:0,balanceDays:[],forgeFound:[],legendWords:[],sortPerfect:0,rapidBest:0}))
  await p.goto('http://127.0.0.1:8099/#/profile',{waitUntil:'networkidle'}); await p.waitForTimeout(900)
  const el = await p.locator('.loadout').first()
  await el.screenshot({ path:`/tmp/lo_${n}.png` })
  const info = await p.evaluate(()=>{
    const el=document.querySelector('.loadout')
    return { stage: el.getAttribute('data-stage'), title: el.querySelector('.loadout-name b').innerText,
             bar: el.querySelector('.loadout-bar em').innerText,
             slots: [...el.querySelectorAll('.loadout-slot')].map(s=>s.className.match(/t\d/)[0]).join(' ') }
  })
  console.log(`뱃지 ${String(n).padStart(2)}개 → 단계 ${info.stage} "${info.title}" · ${info.bar} · 슬롯 ${info.slots}`)
  shots.push(`/tmp/lo_${n}.png`)
  await p.close()
}
await b.close()

import { chromium } from 'playwright'
const ALL = JSON.parse(process.env.ALLIDS)
const SETS = [0, 3, 14, 30, 55, ALL.length]
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' })
for (const n of SETS) {
  const p = await b.newPage({ viewport: { width: 412, height: 900 }, deviceScaleFactor: 2 })
  await p.route('**/*', r => {
    const u = r.request().url()
    if (u.includes('supabase.co') && u.includes('/badges')) return r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(ALL.slice(0,n).map(id=>({badge_id:id})))})
    if (u.includes('supabase.co')) return r.fulfill({status:200,contentType:'application/json',body:'[]'})
    if (u.includes('/version.json')) return r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({version:'1.4.28',vocab_ready:true,worlds_ready:true})})
    return r.continue()
  })
  await p.addInitScript(st=>localStorage.setItem('wordcraft_state_v1',st), JSON.stringify({learnerId:'L',nickname:'예한',xp:37679,level:16,streak_days:3,diagDone:[],placement:'C0',progress:{},bossWins:[],attendance:[],reviewTotal:0,balanceDays:[],forgeFound:[],legendWords:[],sortPerfect:0,rapidBest:0}))
  await p.goto('http://127.0.0.1:8099/#/profile',{waitUntil:'networkidle'})
  // 스플래시가 사라질 때까지 기다린다
  for (let k=0;k<40;k++){ if (await p.locator('.loadout').isVisible().catch(()=>false)) { const box = await p.locator('.loadout').boundingBox(); if (box && box.width>100) break } await p.waitForTimeout(250) }
  await p.waitForTimeout(1500)
  await p.locator('.loadout').scrollIntoViewIfNeeded()
  await p.waitForTimeout(400)
  await p.locator('.loadout').screenshot({ path:`/tmp/L_${n}.png` })
  await p.close()
  console.log('shot', n)
}
await b.close()

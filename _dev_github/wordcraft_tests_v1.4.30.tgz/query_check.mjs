// 서버 조회 안전 검사 — "조용히 잘리는 목록"을 앱 전체에서 원천 차단한다 (v1.4.29 신설)
//
// ★2026-08-14 사고의 일반화★
// 복습 광산은 카드를 `limit=500`으로, 정렬 없이 받아왔다. 카드가 685장이 되자
// 오늘 캘 40장이 통째로 사라졌고, 아무 에러도 나지 않았다. **틀린 답이 조용히 나온 것**이다.
// 이 검사는 그 조건 두 개를 앱의 모든 조회에 대해 금지한다.
//   ① 상한(limit)이 없다  → 서버 기본 상한에 언제 잘릴지 모른다 (에러 없이 잘린다)
//   ② 정렬(order)이 없는데 상한이 있다 → "어느 행이 올지"가 서버 마음이다
// 데이터는 계속 자란다. 오늘 500장이 안 넘는다는 것은 내일의 안전을 보장하지 않는다.
//
// 사용: node query_check.mjs
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join } from 'node:path'

const files = []
;(function walk(d) {
  for (const n of readdirSync(d)) {
    const p = join(d, n)
    if (statSync(p).isDirectory()) walk(p)
    else if (/\.tsx?$/.test(n)) files.push(p)
  }
})('src')

let fail = 0
const rows = []

// ── 1. 쿼리 빌더 함수(…Query)가 스스로 안전한가 ────────────────
const builders = new Map()
for (const f of files) {
  const src = readFileSync(f, 'utf8')
  const re = /export function (\w*Query)\s*\([^)]*\)[^{]*\{([\s\S]*?)\n\}/g
  let m
  while ((m = re.exec(src))) builders.set(m[1], { file: f, body: m[2] })
}
for (const [name, b] of builders) {
  const hasLimit = /limit=\$\{?\w/.test(b.body) || /limit=\d/.test(b.body)
  const hasOrder = /order=/.test(b.body)
  if (!hasLimit) { console.log(`  ✗ ${name}() — limit이 없다 (${b.file})`); fail++ }
  if (!hasOrder) { console.log(`  ✗ ${name}() — order가 없다 (${b.file})`); fail++ }
  if (hasLimit && hasOrder) rows.push([`${name}()`, b.file.replace('src/', ''), 'builder', 'ok'])
}

// ── 2. 모든 db.select 호출 ────────────────────────────────────
for (const f of files) {
  const src = readFileSync(f, 'utf8')
  const lines = src.split('\n')
  lines.forEach((line, i) => {
    const call = line.match(/db\.select\(\s*'(\w+)'\s*,\s*(.+)$/)
    if (!call) return
    const [, table, argRaw] = call
    const at = `${f.replace('src/', '')}:${i + 1}`
    // 허용 ①: 빌더 함수를 넘긴 경우 (빌더는 위에서 이미 검사했다)
    const byBuilder = argRaw.match(/^(\w*Query)\(/)
    if (byBuilder) {
      if (!builders.has(byBuilder[1])) { console.log(`  ✗ ${at} — 알 수 없는 빌더 ${byBuilder[1]}()`); fail++ }
      else rows.push([table, at, byBuilder[1] + '()', 'ok'])
      return
    }
    // 허용 ②: 템플릿 리터럴 — limit 필수, limit>1이면 order 필수
    const q = argRaw.match(/`([^`]*)`/)
    if (!q) { console.log(`  ✗ ${at} — 조회 문자열을 읽을 수 없다(동적 조립?). 빌더 함수로 빼라.`); fail++; return }
    const query = q[1]
    const lim = query.match(/limit=(\d+)/)
    if (!lim) {
      console.log(`  ✗ ${at} (${table}) — ★limit이 없다★ 서버 기본 상한에 조용히 잘린다`)
      fail++; return
    }
    const n = Number(lim[1])
    if (n > 1 && !/order=/.test(query)) {
      console.log(`  ✗ ${at} (${table}) — limit=${n}인데 ★order가 없다★ 어떤 행이 올지 서버 마음이다`)
      fail++; return
    }
    rows.push([table, at, `limit=${n}`, n === 1 ? '단건' : 'ok'])
  })
}

console.log('=== 서버 조회 안전 검사 ===')
console.log(`  조회 지점 ${rows.length}개 — 전부 상한·정렬 확인`)
const byTable = {}
for (const r of rows) byTable[r[0]] = (byTable[r[0]] || 0) + 1
console.log('  ' + Object.entries(byTable).map(([t, c]) => `${t}:${c}`).join(' · '))
console.log(`\n=== 결함 ${fail} ===`)
if (fail) { console.log('✗ 조회 안전 검사 실패 — 위 지점에 limit/order를 붙여라'); process.exit(1) }
console.log('✅ 모든 서버 조회에 상한·정렬이 있다 (조용히 잘리는 목록 없음)')

// 복습 광산 due 정합 검사 (v1.4.29 신설)
//
// ★왜 이 검사가 생겼나 — 2026-08-14 P0★
// 하단 네비 뱃지는 "40", 복습 광산은 "오늘 캘 카드 0"이었다. 두 화면이 같은 질문에
// 서로 다르게 답한 것이다. 원인은 광산이 카드 전체를 정렬 없이 limit=500으로 받아
// 그 안에서 due를 골랐기 때문 — 카드가 685장이 되자 due 40장이 창 밖으로 밀렸다.
//
// 이 검사는 **가짜 PostgREST**를 세워 실제 쿼리 문자열을 태워 본다. 쿼리가 잘못되면
// 픽스처에서 곧바로 숫자가 어긋난다. (L27④ — 결함을 되살려 잡히는 것까지 확인했다)
//
// 사용: node review_check.mjs
import { readFileSync } from 'node:fs'

let fail = 0
const ok = (cond, msg) => { if (cond) { console.log(`  ✓ ${msg}`) } else { console.log(`  ✗ ${msg}`); fail++ } }

// ── 0. localStorage 셔밍 (node에는 없다) ──────────────────────
const store = new Map()
globalThis.localStorage = {
  getItem: k => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: k => store.delete(k),
}

const R = await import('./_review_entry_out.js').then(() => globalThis.RV)
const today = R.todayStr()

console.log('=== 복습 광산 due 정합 ===')

// ── 1. 규칙 복사본 부활 감시 ──────────────────────────────────
// 소비자 화면이 review_cards 쿼리를 직접 문자열로 짜면 실패. lib/review.ts만 짤 수 있다.
console.log('\n[1] 쿼리 단일 원천')
for (const f of ['src/screens/ReviewMine.tsx', 'src/App.tsx']) {
  const src = readFileSync(f, 'utf8')
  const inline = /db\.select\(\s*'review_cards'\s*,\s*`/.test(src)
  ok(!inline, `${f} — review_cards 쿼리를 직접 짜지 않는다`)
}
ok(/from '\.\.\/lib\/review'/.test(readFileSync('src/screens/ReviewMine.tsx', 'utf8')), 'ReviewMine이 lib/review를 쓴다')
ok(/from '\.\/lib\/review'/.test(readFileSync('src/App.tsx', 'utf8')), 'App(뱃지)이 lib/review를 쓴다')

// ── 2. 쿼리 자체의 필수 조건 ──────────────────────────────────
console.log('\n[2] due 쿼리 형태')
const q = R.dueCardsQuery('LID', today)
ok(q.includes(`due_date=lte.${today}`), '서버에서 due를 거른다 (화면에서 거르지 않는다)')
ok(/[?&]order=/.test('&' + q), '정렬이 있다 — 정렬 없는 limit은 "어떤 행이 올지 서버 마음"이다')
const lim = Number((q.match(/limit=(\d+)/) || [])[1] || 0)
ok(lim >= 1000, `limit이 넉넉하다 (${lim} ≥ 1000)`)
ok(R.boxTotalsQuery('LID').includes('select=box'), '층별 집계는 box 한 컬럼만 받는다')

// ── 3. 가짜 PostgREST — 사고 당일 예한이 데이터 재현 ──────────
// 685장 중 40장이 오늘 due, 그리고 그 40장은 **저장 순서상 맨 뒤(537~685번째)**에 있다.
function makeFixture() {
  const rows = []
  for (let i = 1; i <= 685; i++) {
    const dueToday = i >= 646            // 뒤쪽 40장만 오늘 due
    rows.push({
      id: i, card_id: `W:C6:Q${i}`, card_front: `q${i}`, card_back: `a${i}`,
      box: dueToday ? 1 : (i % 4) + 2,
      due_date: dueToday ? today : '2099-01-01',
      review_count: 0,
    })
  }
  return rows                            // ← 삽입 순서 그대로 (정렬 없으면 이 순서로 온다)
}
/** PostgREST 흉내: eq/lte 필터 → (order) → limit */
function fakeRest(rows, query) {
  const p = new URLSearchParams(query)
  let out = rows.slice()
  for (const [k, v] of p) {
    if (['select', 'order', 'limit', 'offset'].includes(k)) continue
    const [op, val] = String(v).split(/\.(.+)/)
    if (op === 'eq') out = out.filter(r => String(r[k]) === val)
    else if (op === 'lte') out = out.filter(r => String(r[k]) <= val)
    else if (op === 'gte') out = out.filter(r => String(r[k]) >= val)
  }
  const ord = p.get('order')
  if (ord) {
    const keys = ord.split(',').map(s => s.split('.'))
    out.sort((a, b) => {
      for (const [k, dir] of keys) {
        const x = a[k], y = b[k]
        if (x !== y) return (x > y ? 1 : -1) * (dir === 'desc' ? -1 : 1)
      }
      return 0
    })
  }
  const l = Number(p.get('limit') || 0)
  return l ? out.slice(0, l) : out
}

console.log('\n[3] 사고 당일 재현 (685장 · due 40장이 뒤쪽에)')
const fx = makeFixture().map(r => ({ ...r, learner_id: 'LID' }))
store.clear()
const mineRows = fakeRest(fx, R.dueCardsQuery('LID', today))
const mine = R.minableCards(mineRows, today).length
const badgeRows = fakeRest(fx, R.dueCardsQuery('LID', today))
const badge = R.minableCards(badgeRows, today).length
ok(mine === 40, `광산 "오늘 캘 카드" = 40 (실제 ${mine})`)
ok(badge === 40, `하단 뱃지 = 40 (실제 ${badge})`)
ok(mine === badge, '★뱃지 숫자 = 광산 숫자★')
const totals = R.tallyBoxes(fakeRest(fx, R.boxTotalsQuery('LID')))
ok(totals.reduce((a, b) => a + b, 0) === 685, `층별 보유량 합 = 685 (실제 ${totals.reduce((a, b) => a + b, 0)})`)

// ── 4. 옛 쿼리를 되살리면 잡히는가 (검사가 진짜 작동하는지) ────
console.log('\n[4] 옛 결함 재현 — 검사가 실제로 잡는지')
const OLD = `learner_id=eq.LID&select=id,card_id,card_front,card_back,box,due_date,review_count&limit=500`
const oldMine = R.minableCards(fakeRest(fx, OLD).filter(c => c.due_date <= today), today).length
ok(oldMine === 0, `옛 쿼리(정렬 없는 limit=500)는 0장을 준다 — 이 검사가 잡아낸다 (실제 ${oldMine})`)

// ── 5. 오늘 이미 맞힌 카드는 양쪽에서 똑같이 빠진다 ───────────
console.log('\n[5] 오늘 캔 카드 제외 (재채굴·XP 파밍 차단, v1.4.4)')
store.clear()
for (let i = 646; i <= 650; i++) R.addReviewDone(`W:C6:Q${i}`)
const mine2 = R.minableCards(fakeRest(fx, R.dueCardsQuery('LID', today)), today).length
ok(mine2 === 35, `5장 채굴 후 광산 = 35 (실제 ${mine2})`)
const badge2 = R.minableCards(fakeRest(fx, R.dueCardsQuery('LID', today)), today).length
ok(badge2 === 35, `5장 채굴 후 뱃지 = 35 (실제 ${badge2})`)
ok(mine2 === badge2, '★채굴 도중에도 두 숫자가 같다★')

// 날짜가 바뀌면 기록은 무효 (어제 캔 카드가 오늘을 막지 않는다)
store.set('wordcraft_review_done_v1', JSON.stringify({ date: '2000-01-01', ids: ['W:C6:Q646'] }))
ok(R.getReviewDone().size === 0, '어제 기록은 오늘 카드를 막지 않는다')

// ── 6. 경계 ───────────────────────────────────────────────────
console.log('\n[6] 경계')
store.clear()
ok(R.minableCards([], today).length === 0, '카드 0장이면 0')
ok(R.layerOf(0) === 1 && R.layerOf(9) === 5 && R.layerOf(3) === 3, 'box 범위 밖 값도 1~5층으로 고정')

console.log(`\n=== 결함 ${fail} ===`)
if (fail) { console.log('✗ 복습 광산 정합 검사 실패'); process.exit(1) }
console.log('✅ 복습 광산 due 정합 검사 통과')

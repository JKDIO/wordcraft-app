// v1.4.29 복습 광산 렌더 스모크 — "뱃지 숫자 = 광산 숫자"를 **실제 화면에서** 확인한다.
// L16: 마커 grep은 렌더 테스트를 대체하지 못한다. 2026-08-14 사고가 정확히 이 지점에서 났다.
//
// 픽스처 = 사고 당일 예한이 데이터 재현: 카드 685장, 그중 40장만 오늘 due,
// 그리고 그 40장은 **저장 순서상 맨 뒤**에 있다(정렬 없는 limit=500이면 통째로 사라지는 배치).
import { chromium } from 'playwright'

const TODAY = new Date().toLocaleDateString('sv', { timeZone: 'Asia/Seoul' })
const CARDS = []
for (let i = 1; i <= 685; i++) {
  const dueToday = i >= 646
  CARDS.push({
    id: i, learner_id: 'L', card_id: `W:C6:Q${i}`,
    card_front: `question ${i}`, card_back: `answer ${i}`,
    box: dueToday ? 1 : (i % 4) + 2,
    due_date: dueToday ? TODAY : '2099-01-01',
    last_result: null, review_count: 0,
  })
}

/** 진짜 PostgREST처럼 필터·정렬·상한을 적용한다 (정렬이 없으면 삽입 순서 그대로 = 실제 서버 거동) */
function restQuery(rows, search) {
  const p = new URLSearchParams(search)
  let out = rows.slice()
  for (const [k, v] of p) {
    if (['select', 'order', 'limit', 'offset'].includes(k)) continue
    const [op, val] = String(v).split(/\.(.+)/)
    if (op === 'eq') out = out.filter(r => String(r[k]) === val)
    else if (op === 'lte') out = out.filter(r => String(r[k]) <= val)
    else if (op === 'gte') out = out.filter(r => String(r[k]) >= val)
    else if (op === 'like') out = out.filter(r => new RegExp('^' + val.replace(/\*/g, '.*') + '$').test(String(r[k])))
  }
  const ord = p.get('order')
  if (ord) {
    const keys = ord.split(',').map(s => s.split('.'))
    out.sort((a, b) => {
      for (const [k, dir] of keys) { if (a[k] !== b[k]) return (a[k] > b[k] ? 1 : -1) * (dir === 'desc' ? -1 : 1) }
      return 0
    })
  }
  const lim = Number(p.get('limit') || 0)
  if (lim) out = out.slice(0, lim)
  const sel = p.get('select')
  if (sel) { const cols = sel.split(','); out = out.map(r => Object.fromEntries(cols.map(c => [c, r[c]]))) }
  return out
}

const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' })
const p = await b.newPage({ viewport: { width: 412, height: 915 } })
const errs = []
p.on('pageerror', e => errs.push(String(e)))
p.on('console', m => { if (m.type() === 'error' && !/404|Failed to load resource|ERR_TUNNEL/.test(m.text())) errs.push(m.text()) })

// ⚠️ 나중에 등록한 route가 먼저 매칭된다 → 포괄 먼저, 구체 나중 (L16)
await p.route('**/*', r => {
  const u = r.request().url()
  if (u.includes('supabase.co')) return r.fulfill({ status: 200, contentType: 'application/json', body: '[]' })
  return r.continue()
})
await p.route('**/rest/v1/learners*', r => r.fulfill({
  status: 200, contentType: 'application/json',
  body: JSON.stringify([{ id: 'L', family_code: 'wc-yehan-7351', nickname: '예한', admin_pin: '7351', xp: 27383, level: 14, streak_days: 2, last_active_date: null }]),
}))
let cardCalls = 0
await p.route('**/rest/v1/review_cards*', r => {
  const method = r.request().method()
  if (method !== 'GET') return r.fulfill({ status: 200, contentType: 'application/json', body: '[]' })
  cardCalls++
  const search = new URL(r.request().url()).search.slice(1)
  return r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(restQuery(CARDS, search)) })
})

await p.addInitScript(st => { localStorage.setItem('wordcraft_state_v1', st) }, JSON.stringify({
  learnerId: 'L', nickname: '예한', xp: 27383, level: 14, streak_days: 2,
  diagDone: ['D1', 'D2', 'D3', 'D4'], placement: 'B21a', progress: {}, bossWins: [], attendance: [],
}))

let fail = 0
const ok = (cond, msg) => { console.log(`  ${cond ? '✓' : '✗'} ${msg}`); if (!cond) fail++ }

async function open(route) {
  await p.goto('http://127.0.0.1:8099/#/' + route, { waitUntil: 'networkidle' })
  await p.reload({ waitUntil: 'networkidle' })
  await p.waitForTimeout(1200)
  const skip = p.locator('button', { hasText: '건너뛰기' })
  if (await skip.count()) { await skip.first().click(); await p.waitForTimeout(600) }
  return (await p.locator('body').innerText()).replace(/\n+/g, ' ')
}

console.log('=== 복습 광산 렌더 스모크 (685장 · 오늘 due 40장) ===')
const txt = await open('review')

ok(/오늘 캘 카드\s*40/.test(txt), '광산 헤더: "오늘 캘 카드 40"')
ok(!/오늘 캘 카드가 없어/.test(txt), '"오늘 캘 카드가 없어" 문구가 뜨지 않는다')
ok(/채굴 시작!\s*\(40장\)/.test(txt), '채굴 시작 버튼이 40장으로 활성')
ok(await p.locator('button.wc-go').isEnabled(), '채굴 시작 버튼이 실제로 눌린다')

// 층별 총 보유량 합 = 685 (500에서 잘리지 않는다)
const layerTotals = await p.locator('.wc-layer .cnt').allInnerTexts()
const sum = layerTotals.reduce((a, s) => a + Number((s.match(/(\d+)장/) || [0, 0])[1]), 0)
ok(sum === 685, `층별 보유량 합 = 685 (실제 ${sum} — 화면: ${layerTotals.join(' / ')})`)
ok(/흙 층.*40|오늘 40/.test(txt.replace(/\s+/g, ' ')), '흙 층에 "오늘 40" 표시')

// 하단 네비 뱃지
const navBadge = await p.locator('.bottomnav button', { hasText: '복습 광산' }).locator('.nav-badge').first().innerText().catch(() => '')
ok(navBadge.trim() === '40', `하단 네비 뱃지 = 40 (실제 "${navBadge.trim()}")`)
ok(navBadge.trim() === '40' && /오늘 캘 카드\s*40/.test(txt), '★뱃지 숫자 = 광산 숫자★')

// 실제로 채굴이 시작되는가 (0장이라 못 들어가는 사고의 반대 증명)
await p.locator('button.wc-go').click()
await p.waitForTimeout(700)
const mining = (await p.locator('body').innerText()).replace(/\n+/g, ' ')
ok(/question 6\d\d|알아|헷갈려/.test(mining), '채굴 화면(플래시카드)에 진입한다')

ok(cardCalls >= 2, `review_cards 조회 ${cardCalls}회 (due 목록 + 층별 집계)`)
ok(errs.length === 0, `JS 오류 0 (실제 ${errs.length}${errs.length ? ' — ' + errs.slice(0, 2).join(' | ') : ''})`)

await b.close()
console.log(`\n=== 결함 ${fail} ===`)
if (fail) { console.log('✗ 복습 광산 스모크 실패'); process.exit(1) }
console.log('✅ 복습 광산 렌더 스모크 통과')
